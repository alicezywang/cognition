#include "uto_task/uto_task.h"
#include "swarm_master_cmd/swarm_master_cmd_api.h"

// Default suspend duration is 2*60 seconds
#define DEFAULT_SUSPEND_DURATION 60

UTOTask::UTOTask(ActorScheduler *aPActorScheduler, int64_t aPlatformID) {
    this->_pActorScheduler = aPActorScheduler;
    _platformID = aPlatformID;
}

UTOTask::~UTOTask() {
    if(_pEventProcessThread) {
        _pEventProcessThread->join();
        _pEventProcessThread->interrupt();
        _pEventProcessThread.reset();
    }
#ifndef EVENT_BARRIER_SYNC
    if(_pSyncQueueThread) {
        _pSyncQueueThread->join();
        _pSyncQueueThread->interrupt();
        _pSyncQueueThread.reset();
    }
#endif
    if(_poolPtr){
        _poolPtr->join();
        _poolPtr.reset();
    }
    if(_pActorScheduler) delete _pActorScheduler;
#ifdef EVENT_GS_RTPS_COMM
    if(_rtpEventPub) {
        delete _rtpEventPub;
    }
    if(_rtpEventSub) {
        delete _rtpEventSub;
    }
#endif
    if(_rtpEventGSSub) {
        delete _rtpEventGSSub;
    }
}


void UTOTask::start() {
    ros::NodeHandle nh;

    // Subscribe msgs from plugins, including response to receive params and requirement for event transition.
    _eventSub = nh.subscribe("uto_event_msg", 10000, &UTOTask::eventCallback, this);

    // Subscribe msgs from GS through FastRTPS: 1. active actors; 2. transimit actors.
    _rtpEventGSSub = new RTPSSubscriber<UTOEventWithGStation>("/uto_event_msg", &UTOTask::eventGSCallback, this);
    
    // Timer is used to multiple publish params
    // _pubTimer = nh.createTimer(ros::Duration(0.1), &UTOTask::pubParams, this);
    // _pubTimer.stop();
    // Publish params to plugins which is started
    // _paramPub = nh.advertise<actor_msgs::UtoActorParams>("uto_actor_params", 10000);

#ifdef EVENT_GS_RTPS_COMM
    // Initial FastRTPS pub＆sub to communicate with gstation/Qt
    _rtpEventPub = new RTPSPublisher<UTOEventTransition>("/uto_event_transition");
    _rtpEventSub = new RTPSSubscriber<UTOEventTransition>("/uto_event_sync", &UTOTask::eventRTPSCallback, this);
#else
    // Publish event to gstation in order to event synchronization
    _eventSyncPub = nh.advertise<actor_msgs::UTOEventTransition>("/uto_event_transition", 10000);
    // Subscribe msgs from gstation for event transition cmd
    _eventSyncSub = nh.subscribe("/uto_event_sync", 10000, &UTOTask::eventSyncCallback, this);
#endif

    // Create a thread to monitor event message queue and handle event transition
    _pEventProcessThread = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&UTOTask::eventProcessing, this)));
    _pEventProcessThread->detach();

#ifndef EVENT_BARRIER_SYNC
    // Create a thread to monitor event synchronize message queue
    _pSyncQueueThread = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&UTOTask::eventSyncTimeoutDetection, this)));
    _pSyncQueueThread->detach();
#endif

    _poolPtr = boost::shared_ptr<boost::executors::basic_thread_pool>(new boost::executors::basic_thread_pool(4));
}

void UTOTask::eventProcessing() {
    actor_msgs::UTOEvent eventMsg;
    while(true) {
        {
            // Wait and hang-up the thread when _eventMsgQueue is empty.
            boost::unique_lock<boost::mutex> lock(_qMutex);
            if(_eventMsgQueue.empty()) {
                _cv.wait(lock);
            }
            eventMsg = _eventMsgQueue.front();
            _eventMsgQueue.pop();
        }
        // ROS_INFO("[uto_task] _eventMsgQueue loop %d, actor:%s, event:%s, type:%d", i, eventMsg.currentActor.c_str(), eventMsg.eventName.c_str(),eventMsg.type);                
        if(eventMsg.type == EVENT_MSG) 
        {
            time_t stamp = time(NULL);
        #if defined(EVENT_GS_RTPS_COMM)
            // Publish event transition message to gstation on FastRTPS
            UTOEventTransition transition;
            transition.currentActor(eventMsg.currentActor);
            transition.eventName(eventMsg.eventName);
            transition.syncStatus(-1);
            transition.timestamp(stamp);
            transition.robotId(_platformID);
            _rtpEventPub->publish(transition);
            ROS_INFO("[uto_task] publish event transition msg to gstation on FastRTPS");
        #else
            // Publish event transition message to gstation on ros
            actor_msgs::UTOEventTransition event;
            event.currentActor = eventMsg.currentActor;
            event.eventName = eventMsg.eventName;
            event.syncStatus = -1;
            event.timestamp = stamp;
            event.robotId = _platformID;
            _eventSyncPub.publish(event);
            ROS_INFO("[uto_task] publish event transition msg to gstation on ros");
        #endif

        #ifndef EVENT_BARRIER_SYNC
            // Synchronization depends on gstation control
            UTOSuspendEvent se;
            se._eventMsg = eventMsg;
            se._suspendTime = stamp;
            se._suspendDuration = DEFAULT_SUSPEND_DURATION;
            boost::unique_lock<boost::mutex> lock(_msgSyncMutex);
            _msgSyncList.push_back(se);
            _msgSyncCV.notify_one();
            continue;
        #else
            // Master controls synchronization
            eventMsg.type = READY_EVENT_MSG;
        #endif
        }

        // ROS_INFO("[uto_task] handle event on %d, actor %s, event %s", _platformID, eventMsg.currentActor.c_str(), eventMsg.eventName.c_str());
        // Use thread pool to handle events
        _poolPtr->submit(boost::bind(&UTOTask::handleEventTransition, this, eventMsg));
    }
}

/* Event synchronization from gstation/Qt */
void UTOTask::eventSyncTimeoutDetection() {
    UTOSuspendEvent susEvent;
    time_t ctime;
    bool flag;
    while(true) {
        flag = false;
        // Wait and hang-up the thread when _msgSyncList is empty.
        {
            boost::unique_lock<boost::mutex> lock(_msgSyncMutex);
            if(_msgSyncList.empty()) {
                _msgSyncCV.wait(lock);
            }
            susEvent = _msgSyncList.front();
            ctime = time(NULL);
            if((ctime-susEvent._suspendTime) >= susEvent._suspendDuration) {
                flag = true;
                _msgSyncList.erase(_msgSyncList.begin());
                ROS_INFO("[uto_task] duration over time : %d", susEvent._suspendDuration);
            }
        }

        // If a timeout occurred while event waiting for gstation response, event will be moved to _eventMsgQueue to be handled
        if(flag) {
            susEvent._eventMsg.type = READY_EVENT_MSG;
            boost::unique_lock<boost::mutex> lock(_qMutex);
            _eventMsgQueue.push(susEvent._eventMsg);
            _cv.notify_one();
        } else {
            usleep(100000);
        }
    }
}

// void UTOTask::pubParams(const ros::TimerEvent& event) {
//     boost::lock_guard<boost::shared_mutex> lock(_pubMutex);
//     for(std::vector<actor_msgs::UtoActorParams>::iterator it = _pendingParamsList.begin(); it != _pendingParamsList.end(); it++) {
//         _paramPub.publish(*it);
//         ROS_INFO("[uto_task] publish params to actor %s", it->actorName.c_str());
//     }
// }

#if defined(EVENT_GS_RTPS_COMM)
// Event transition callback from gstation/Qt on FastRTPS
void UTOTask::eventRTPSCallback(UTOEventTransition &msg)
{
    boost::unique_lock<boost::mutex> lock(_msgSyncMutex);
    for(std::vector<UTOSuspendEvent>::iterator it=_msgSyncList.begin(); it!=_msgSyncList.end(); it++) {
        if(msg.timestamp() == it->_suspendTime && msg.currentActor() == it->_eventMsg.currentActor) {
            if(msg.syncStatus() == EVENT_SYNC_READY) {
                // When event's suspend duration is zero, the event transition will be handled
                it->_suspendDuration = 0;
                ROS_INFO("[uto_task] Receive 'Agree to state transition' from g_station, currentActor:%s, eventName:%s", msg.currentActor().c_str(), msg.eventName().c_str());            
            } else if(msg.syncStatus() == EVENT_SYNC_BLOCK) {
                // Waiting longer for message synchronization
                it->_suspendDuration = 3 * it->_suspendDuration;
                ROS_INFO("[uto_task] Receive 'Waiting' from g_station, currentActor:%s, eventName:%s", msg.currentActor().c_str(), msg.eventName().c_str());
            }
            break;
        }
    }
}
#else

/* Event transition synchronization callback from gstation/Qt on ros topic */
void UTOTask::eventSyncCallback(const actor_msgs::UTOEventTransition &msg)
{
    boost::unique_lock<boost::mutex> lock(_msgSyncMutex);
    for(std::vector<UTOSuspendEvent>::iterator it=_msgSyncList.begin(); it!=_msgSyncList.end(); it++) {
        if(msg.timestamp == it->_suspendTime && msg.currentActor == it->_eventMsg.currentActor) {
            if(msg.syncStatus == EVENT_SYNC_READY) {
                // When event's suspend duration is zero, the event transition will be handled
                it->_suspendDuration = 0;
                ROS_INFO("[uto_task] Receive 'Agree to state transition' from g_station, currentActor:%s, eventName:%s", msg.currentActor.c_str(), msg.eventName.c_str());            
            } else if(msg.syncStatus == EVENT_SYNC_BLOCK) {
                // Waiting longer for message synchronization
                it->_suspendDuration = 3 * it->_suspendDuration;
                ROS_INFO("[uto_task] Receive 'Waiting' from g_station, currentActor:%s, eventName:%s", msg.currentActor.c_str(), msg.eventName.c_str());
            }
            break;
        }
    }
}
#endif

void UTOTask::eventCallback(const actor_msgs::UTOEvent::ConstPtr &msg) {
    ROS_INFO("[uto_task] receive event transition request from plugins: currentActor:%s eventName:%s", msg->currentActor.c_str(), msg->eventName.c_str());
    // Wakeup monitor loop to handle event
    boost::unique_lock<boost::mutex> lock(_qMutex);
    _eventMsgQueue.push(*msg);
    _cv.notify_one();
}

// Event transition/activation callback from GS through FastRTPS
void UTOTask::eventGSCallback(UTOEventWithGStation &eventGSMsg)
{
    actor_msgs::UTOEvent eventMsg;
    eventMsg.currentActor = eventGSMsg.currentActor();
    eventMsg.eventName = eventGSMsg.eventName();  
    eventMsg.type = eventGSMsg.type();  
    ROS_INFO("[uto_task] receive event transition request from GS: currentActor:%s eventName:%s", eventGSMsg.currentActor().c_str(), eventGSMsg.eventName().c_str());

    boost::unique_lock<boost::mutex> lock(_qMutex);
    _eventMsgQueue.push(eventMsg);
    _cv.notify_one();
}

void UTOTask::setUTOList(const std::vector<UTOActorNode> &aUTOList)
{    
    boost::lock_guard<boost::shared_mutex> wlk(_utoListMutex);
    _utoList = aUTOList;
}

void UTOTask::setInitialActors(const std::string &aSwarmName, const std::vector<std::string> &aInitialActors)
{   
    {
        boost::lock_guard<boost::shared_mutex> wlock(_utoListMutex);
        _swarmNameToInitialActors[aSwarmName] = aInitialActors;
        _swarmName = aSwarmName;
    }
    boost::lock_guard<boost::shared_mutex> lock(_runMutex);
    _utoRunningActorsList.clear();
}

void UTOTask::handleEventTransition(actor_msgs::UTOEvent &eventMsg) {
    // if(eventMsg.type == MSG_RESPONSE) {
    //     ROS_INFO("[uto_task] receive params response from plugins");
    //     // Receive response for publishing params
    //     boost::lock_guard<boost::shared_mutex> lock(_pubMutex);
    //     for(std::vector<actor_msgs::UtoActorParams>::iterator it = _pendingParamsList.begin(); it != _pendingParamsList.end(); it++) {
    //         if(it->actorName == eventMsg.currentActor) {
    //             _pendingParamsList.erase(it);
    //             break;
    //         }
    //     }
    //     if(_pendingParamsList.empty()) _pubTimer.stop();
    // } else 
    if(eventMsg.type == READY_EVENT_MSG) {
        // Receive event transition request from plugins and gstation
        // Check whether the request actor is running
        {
            boost::shared_lock<boost::shared_mutex> lock(_runMutex);
            std::vector<std::string>::iterator runit = find(_utoRunningActorsList.begin(), _utoRunningActorsList.end(), eventMsg.currentActor);
            if(runit == _utoRunningActorsList.end()) {
                return;
            }
        }
        
        //Get next actor name
        std::string nextActor;
    #ifdef EVENT_BARRIER_SYNC
        int32_t participant = -1;
        short cnt = 0;
        // High 6 bit respresent event index and low 10 bit respresent number of execution circularly
        short key = -1;
    #endif
        
        {
            boost::lock_guard<boost::shared_mutex> wlock(_utoListMutex);
            for(std::vector<UTOActorNode>::iterator it = _utoList.begin(); it != _utoList.end(); it++) {
                if(it->_actorName == eventMsg.currentActor) {
                    for(std::vector<UTOTransition>::iterator vit = it->_eventList.begin(); vit != it->_eventList.end(); vit++) {
                        if(vit->_eventName == eventMsg.eventName) {
                            nextActor = vit->_nextActor;
                        #ifdef EVENT_BARRIER_SYNC
                            participant = vit->_participants;
                            if(vit->_barrierKey > -1) {
                                key = vit->_barrierKey;
                                key = key << 10;
                                cnt = (vit->_exeCount)++;
                                cnt &= 0x3FF;
                                key += cnt;
                            }
                        #endif
                            break;
                        }
                    }
                    break;
                }
            }
        }
        
    #ifdef EVENT_BARRIER_SYNC
        if(key > -1) {
            ROS_INFO("[uto_task] actor synchronization num is %d, key is %d", participant, key);
            // Master controls synchronization
            GlobalBarrierKey barrier = GlobalBarrierKey(key);
            BarrierResult result = actorBarrierApi(barrier, participant, DEFAULT_SUSPEND_DURATION);
            if(result == YES){
                ROS_INFO("[uto_task] actor %s completes synchronization on platform %ld, key is %d", eventMsg.currentActor.c_str(), _platformID, key);
            } else if(result == TIMEOUT){
                ROS_INFO("[uto_task] actor %s waits timeout on platform %ld, key is %d", eventMsg.currentActor.c_str(), _platformID, key);
            } else if(result == OPTIONALYES){
                ROS_INFO("[uto_task] actor %s gets optinal YES on platform %ld, key is %d", eventMsg.currentActor.c_str(), _platformID, key);
                return;
            } else{
                ROS_INFO("[uto_task] actor %s result %d on platform %ld, key is %d", eventMsg.currentActor.c_str(), result, _platformID, key);
                return;
            }
        }
    #endif

        if(!nextActor.empty())
        {
            bool flag = false;
            {
                boost::shared_lock<boost::shared_mutex> rlock(_utoListMutex);
                //Get next actor parameters and switch
                for(std::vector<UTOActorNode>::iterator it = _utoList.begin(); it != _utoList.end(); it++) {
                    if(it->_actorName == nextActor) {
                        //Set actor's params
                        _pActorScheduler->setActorParams(_swarmName, nextActor, it->_paramMap);
                        _pActorScheduler->switchToActor(_swarmName, eventMsg.currentActor, nextActor);
                        flag = true;
                        // // Store params for sending
                        // actor_msgs::UtoActorParams params;
                        // params.actorName = it->_actorName;
                        // for(std::map<std::string, std::string>::iterator mit = it->_paramMap.begin(); mit != it->_paramMap.end(); mit++) {
                        //     // ROS_INFO("===========store params in UtoActorParams: %s %s", mit->first.c_str(), mit->second.c_str());
                        //     params.paramKeys.push_back(mit->first);
                        //     params.paramValues.push_back(mit->second);
                        // }
                        // boost::lock_guard<boost::shared_mutex> lock(_pubMutex);
                        // _pendingParamsList.push_back(params);
                        // // Start publish timer
                        // _pubTimer.start();
                        break;
                    }
                }
            }

            if(flag) {
                UTOEventTransition transition;
                transition.currentActor(nextActor);
                transition.eventName("I am starting...");
                transition.syncStatus(-1);
                transition.timestamp(time(NULL));
                transition.robotId(_platformID);
                _rtpEventPub->publish(transition);

                // Set uto running actor list
                boost::lock_guard<boost::shared_mutex> lock(_runMutex);
                std::vector<std::string>::iterator runit = find(_utoRunningActorsList.begin(), _utoRunningActorsList.end(), eventMsg.currentActor);
                if(runit != _utoRunningActorsList.end()){
                    _utoRunningActorsList.erase(runit);
                }
                _utoRunningActorsList.push_back(nextActor);
            }
        }
    }
    else if (eventMsg.type == ACTIVE_EVENT_MSG) {
        std::string nextActor;
        {
            boost::shared_lock<boost::shared_mutex> rlock(_utoListMutex);
            for(std::vector<UTOActorNode>::iterator it = _utoList.begin(); it != _utoList.end(); it++) {
                if(it->_actorName == eventMsg.currentActor) {
                    for(std::vector<UTOTransition>::iterator vit = it->_eventList.begin(); vit != it->_eventList.end(); vit++) {
                        if(vit->_eventName == eventMsg.eventName) {
                            nextActor = vit->_nextActor;
                            break;
                        }
                    }
                    break;
                }
            }
        }
        if(!nextActor.empty())
        {
            bool flag = false;
            {
                boost::shared_lock<boost::shared_mutex> rlock(_utoListMutex);
                //Get next actor parameters and switch
                for(std::vector<UTOActorNode>::iterator it = _utoList.begin(); it != _utoList.end(); it++) {
                    if(it->_actorName == nextActor) {
                        //Set actor's params
                        _pActorScheduler->setActorParams(_swarmName, nextActor, it->_paramMap);
                        _pActorScheduler->activateActor(_swarmName, nextActor);
                        flag = true;
                        break;
                    }
                }
            }

            if(flag) {
                UTOEventTransition transition;
                transition.currentActor(nextActor);
                transition.eventName("I am starting...");
                transition.syncStatus(-1);
                transition.timestamp(time(NULL));
                transition.robotId(_platformID);
                _rtpEventPub->publish(transition);

                // Set uto running actor list
                boost::lock_guard<boost::shared_mutex> lock(_runMutex);
                //_utoRunningActorsList.erase(runit);
                _utoRunningActorsList.push_back(nextActor);
            }
        }
    }
    else if (eventMsg.type == START_EVENT_MSG) {
        _swarmName = eventMsg.currentActor;
        bool flag;
        boost::shared_lock<boost::shared_mutex> rlock(_utoListMutex);
        for (std::vector<std::string>::iterator vit = _swarmNameToInitialActors[_swarmName].begin(); vit != _swarmNameToInitialActors[_swarmName].end(); vit++) {
            flag = false;

            //Get actor parameters and switch
            for(std::vector<UTOActorNode>::iterator it = _utoList.begin(); it != _utoList.end(); it++) {
                if(it->_actorName == *vit) {
                    //Set actor's params
                    _pActorScheduler->setActorParams(_swarmName, *vit, it->_paramMap);
                    _pActorScheduler->activateActor(_swarmName, *vit);
                    flag = true;
                    break;
                }
            }

            if(flag) {
                rlock.unlock();
                UTOEventTransition transition;
                transition.currentActor(*vit);
                transition.eventName("I am starting...");
                transition.syncStatus(-1);
                transition.timestamp(time(NULL));
                transition.robotId(_platformID);
                _rtpEventPub->publish(transition);
                {
                    // Set uto running actor list
                    boost::lock_guard<boost::shared_mutex> lock(_runMutex);
                    //_utoRunningActorsList.erase(runit);
                    _utoRunningActorsList.push_back(*vit);
                }
                rlock.lock();
            }
        }
    }
}
