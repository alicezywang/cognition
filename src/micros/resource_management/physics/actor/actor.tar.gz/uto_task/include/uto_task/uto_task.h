#ifndef __UTO_TASK__
#define __UTO_TASK__

#include "actor_schedule/actor_schedule.h"
#include "actor_msgs/UTOEvent.h"
#include "actor_msgs/UtoActorParams.h"
#include "actor_msgs/UTOEventTransition.h"
#include "std_msgs/String.h"
#include <ros/ros.h>
#include <tinyxml.h>
#include <boost/thread/thread_pool.hpp>
#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"
#include "UTOEventTransition.h"
#include "UTOEventWithGStation.h"
#include "StringMsg.h"

// Compiler toggle for FastRTPS and ROS communication between UTO and gstation/Qt
#define EVENT_GS_RTPS_COMM

// Compiler toggle for master barrier synchronization and gstation/Qt synchronization
#define EVENT_BARRIER_SYNC

// Interact with gstation for event synchronization status
enum EEventSyncStatus {
    // Representing uto event transition message has not yet been synchronized
    EVENT_SYNC_BLOCK = 1,
    // Representing uto event transition message has been synchronized
    EVENT_SYNC_READY
};

// Interact with plugins for event status
enum EEventStatus {
    // Representing plugins have received param msgs, this type should contain running actor name.
    // MSG_RESPONSE = 1,
    // Representing event transition from plugins, this type should contain running actor name and event name.
    EVENT_MSG = 2,
    // Representing a suspend event is ready to be handled (3)
    READY_EVENT_MSG,
    // Representing a event to start the initialized the actors (TakeOff) from UTO (4)
    START_EVENT_MSG,
    // Representing a event to active an actor (5)
    ACTIVE_EVENT_MSG
};

// Save event data into UTOTransition struct from UTO xml
struct UTOTransition {
    std::string _eventName;
    std::string _nextActor;
    int32_t _participants;
    int16_t _barrierKey;   // Key value for barrier settings
    // Number of event transition execution circularly 
    short _exeCount;
    void clear() {
        _eventName.clear();
        _nextActor.clear();
        _participants = 0;
        _exeCount = 0;
    }
};

// Save actor data into UTOTransition struct from UTO xml
struct UTOActorNode {
    std::string _actorName;
    std::map<std::string, std::string> _paramMap;
    std::vector<UTOTransition> _eventList;
    void clear() {
        _actorName.clear();
        _paramMap.clear();
        _eventList.clear();
    }
};

// Package event msg with timer and waiting duration 
struct UTOSuspendEvent {
    actor_msgs::UTOEvent _eventMsg;
    // Event transition message start suspending time
    time_t _suspendTime;
    int32_t _suspendDuration;
};

class UTOTask {
public:
    UTOTask(ActorScheduler *aPActorScheduler, int64_t aPlatformID);
    ~UTOTask();
    void start();

    void setUTOList(const std::vector<UTOActorNode>& aUTOList);    
    void setInitialActors(const std::string& aSwarmName, const std::vector<std::string>& aInitialActors);

private:
    /* UTO initial */
    int64_t _platformID;
    std::string _swarmName;
    ActorScheduler *_pActorScheduler;

    /* UTO Event communication between UTO and gstation */
    RTPSSubscriber<UTOEventWithGStation> *_rtpEventGSSub;
    void eventGSCallback(UTOEventWithGStation &eventGSMsg); 
    
    /* UTO task list */
    boost::shared_mutex _utoListMutex;
    std::vector<UTOActorNode> _utoList;
    std::map<std::string, std::vector<std::string> > _swarmNameToInitialActors;

    /* Message communication between UTO and plugins */
    ros::Subscriber _eventSub;
    // Event msg callback from plugins
    void eventCallback(const actor_msgs::UTOEvent::ConstPtr &msg);
    
    /* Event message communication for synchronization between UTO and gstation/Qt */
#if defined(EVENT_GS_RTPS_COMM)
    // FastRTPS communication with Qt/gstation
    RTPSPublisher<UTOEventTransition> *_rtpEventPub;
    RTPSSubscriber<UTOEventTransition> *_rtpEventSub;
    // Event transition callback from gstation/Qt on FastRTPS
    void eventRTPSCallback(UTOEventTransition &msg);
#else
    ros::Publisher _eventSyncPub;
    ros::Subscriber _eventSyncSub;
    // Event transition synchronization callback from gstation/Qt on ros topic
    void eventSyncCallback(const actor_msgs::UTOEventTransition &msg);
#endif
    // Event message synchronization with gstation/Qt
    boost::mutex _msgSyncMutex;
    boost::condition_variable _msgSyncCV;
    std::vector<UTOSuspendEvent> _msgSyncList;
    boost::shared_ptr<boost::thread> _pSyncQueueThread;
    // Detection whether event msg time out occurred while waiting for Qt/gstation synchronization
    void eventSyncTimeoutDetection();
    
    /* UTO event transition handling */
    boost::mutex _qMutex;
    boost::condition_variable _cv;
    std::queue<actor_msgs::UTOEvent> _eventMsgQueue;
    boost::shared_ptr<boost::thread> _pEventProcessThread;
    // Current running actors' list
    boost::shared_mutex _runMutex;
    std::vector<std::string> _utoRunningActorsList;
    // _pEventProcessThread bind eventProcessing method to process event in _eventMsgQueue
    void eventProcessing();
    // hanle actor transition
    void handleEventTransition(actor_msgs::UTOEvent &eventMsg);

    /* UTO event synchronization with actor barrier */
    // Use thread pool to run event
    boost::shared_ptr<boost::executors::basic_thread_pool> _poolPtr;

    /* UTO communicate parameters with plugins in ros topic */
    // ros::Publisher _paramPub;
    // boost::shared_mutex _pubMutex;
    // ros::Timer _pubTimer;
    // std::vector<actor_msgs::UtoActorParams> _pendingParamsList;
    // void pubParams(const ros::TimerEvent& event);
};

#endif
