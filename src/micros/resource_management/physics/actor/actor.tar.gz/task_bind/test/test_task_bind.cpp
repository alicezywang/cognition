#include "actor_core/ACB.h"
#include "actor_core/actor_core.h"
#include "actor_core/actor_types.h"
#include "task_bind/task_bind.h"
#include "ros/ros.h"
#include <gtest/gtest.h>

/*
TEST(TaskBind, initTaskFromXML) {
	const char *buffer="<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\
		      <Basic id=\"1234\" actorName=\"attacker\" > \
		      </Basic> \
      		      <OODAConfig> \
		      <Bus name=\"observe_bus\"> \
		      	<Plugin name=\"example1_plugin\"> \
			</Plugin> \
		      </Bus> \
		      <Bus name=\"act_bus\"> \
		      	<Plugin name=\"example2_plugin\"> \
			</Plugin> \
		      </Bus> \
		      </OODAConfig>";
	ROS_WARN("using debug task XML string: %s",buffer);
	TaskInfo taskInfo;
	TaskBinder taskBinder(NULL,NULL);
    taskBinder.initTaskFromXML(std::string(buffer),&taskInfo);
	EXPECT_EQ(taskInfo.taskID,1234);
	EXPECT_EQ(strcmp(taskInfo.actorName.c_str(),"attacker"),0);
	EXPECT_EQ(taskInfo.plugins.size(),2);
	EXPECT_EQ(strcmp(taskInfo.plugins[0].name.c_str(),"example1_plugin"),0);
	EXPECT_EQ(strcmp(taskInfo.plugins[0].busName.c_str(),"observe_bus"),0);
	EXPECT_EQ(strcmp(taskInfo.plugins[1].name.c_str(),"example2_plugin"),0);
	EXPECT_EQ(strcmp(taskInfo.plugins[1].busName.c_str(),"act_bus"),0);
}
*/

int main(int argc,char **argv) {
	testing::InitGoogleTest(&argc, argv);  
	ros::init(argc, argv, "task_bind_test");
	return RUN_ALL_TESTS();
}
