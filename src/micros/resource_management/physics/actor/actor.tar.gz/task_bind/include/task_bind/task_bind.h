#ifndef __TASK_BINDER__
#define __TASK_BINDER__

#include <tinyxml.h>
#include <stdlib.h>
#include <string>
#include <sstream>
#include "actor_match/actor_match.h"
#include "actor_schedule/actor_schedule.h"
#include "uto_task/uto_task.h"
#include "actor_msgs/swarm_task.h"
#include "ros/ros.h"
#include "actor_msgs/task_bind.h"
#include "actor_core/ACB.h"
#include "actor_core/actor_types.h"
#include "actor_core/actor_constant.h"

#include "task_bind/SwarmTask.h"
#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

using namespace std;

const int8_t MODE_GSTATION = 0;
const int8_t MODE_PLATFORM = 1;

class TaskBinder {
public:
	TaskBinder(ActorMatcher* aPActorMatcher, ActorScheduler* aPActorScheduler);	
	TaskBinder(ActorMatcher *aPActorMatcher, ActorScheduler *aPActorScheduler, int64_t aPlatformID);
	TaskBinder(ActorMatcher *aPActorMatcher, ActorScheduler *aPActorScheduler, UTOTask* aUTOTask, int64_t aPlatformID);
	TaskBinder(int64_t aPlatformID);
	~TaskBinder();
	void startService();

	bool initTaskFromXML(const std::string aTaskXMLStr,TaskInfo* pTask);	//deprecated
	bool decodeXML(const std::string aTaskXMLStr);							//deprecated
	
	ActorMatcher* _pActorMatcher;
	ActorScheduler* _pActorScheduler;
	UTOTask* _pUTOTask;
	// only for testing ground station
	int initPrior = 10;
	struct LocalTaskAssignment {
		std::vector<string> actorName;
		std::vector<int64_t> platformID;
	};
	struct LocalTaskAssignment _localTaskAssignment;
	int64_t _platformID;
	std::string _curSwarmMatchXmlStr;
	std::string _curSwarmTaskXmlStr;
	
	void start();
	void swarmMatchCallback(const actor_msgs::swarm_task& msg);
	void swarmTaskCallback(const actor_msgs::swarm_task& msg);
	bool pushSwarmTaskAcbs(const std::string aTaskXMLStr);	
	// Based on FAST-RTPS
	void start0();
	void subscribeRequirement();
	void subscriberAssignment();
	void publishResponse();
	void publishConfirmation();
	void swarmMatchCallback0(SwarmTask& msg);
	void swarmTaskCallback0(SwarmTask& msg);
	// 20180821
	void processActors(TiXmlElement* aPActors, ACB& anACB, TaskInfo& aTaskInfo);
	void processSensorActuatorInfo(TiXmlElement* aPSensorActuator, SensorActuatorInfo& aSAInfo);
	void processTaskInfo(TiXmlElement* aPAct, TaskInfo& aTaskInfo);
	void processSwarmInfo(TiXmlElement* aPEle, SwarmInfo& aSwarmInfo);
	// 20181113 for GStation Daemon Node
	TaskBinder(ActorScheduler* aPActorScheduler, string aGStationInitXmlFilePath);
	string _gstationInitXmlFilePath;
	bool startGStation();

	// --------------add by gjl
private:
	void splitString(const std::string& aStr, const char aSep, std::vector<std::string>& aRet);
	void processActorConfigInXml(TiXmlElement* pEle, const SwarmInfo& aSwarmInfo, std::vector<ACB>& aACBList);
	void processUTOConfigInXml(TiXmlElement* pEle, std::vector<UTOActorNode>& aUTOList);
	void processPlatformActorConfigInxml(TiXmlElement* pEle, std::vector<std::string>& aInitialActors);
	void gStationSwarmTaskCallback(StringMsg& msg);

private:
	RTPSSubscriber<StringMsg>* _pSubTaskXml; // 
	RTPSPublisher<StringMsg>* _pPubTaskXmlResponse;
	std::vector<std::string> _receivedSwarmTask;// <swarmname> 
	//-- add end

private:
	ros::NodeHandle _nh;
	ros::ServiceServer _task_bind_server;
	bool bindCallback(actor_msgs::task_bind::Request  &aReq, actor_msgs::task_bind::Response &aRes);
	bool _newTaskArrived;
	RTPSSubscriber<SwarmTask> *_pSubReq;
	RTPSSubscriber<SwarmTask> *_pSubAssign;
	RTPSPublisher<SwarmTask> *_pPubResp;
	RTPSPublisher<SwarmTask> *_pPubConfirm;
	int8_t _workMode;
};

#endif

