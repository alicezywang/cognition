#include <string>
#include "actor_core/actor_types.h"
#include "actor_schedule/actor_schedule.h"
#include "task_bind/task_bind.h"
#include "ros/ros.h"
#include "actor_tools/xml_tool.h"
#include "tinyxml.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

using namespace std;

class GStationInterface {
    virtual void startService()=0;
};

class DaemonGStationApp: public GStationInterface{
public:
    DaemonGStationApp(ros::NodeHandle& nh, std::vector<boost::shared_ptr<general_bus::GeneralBus>> aBusVec, std::string aGStationInitXmlFilePath) {
        this->_nh = nh;
        _pActorScheduler = new ActorScheduler(aBusVec);
        _pTaskBinder = new TaskBinder(_pActorScheduler, aGStationInitXmlFilePath);
    }

    ~DaemonGStationApp() {
        if (_pTaskBinder) {
            delete _pTaskBinder;
            _pTaskBinder=NULL;
        }
        if (_pActorScheduler) {
            delete _pActorScheduler;
            _pActorScheduler=NULL;
        }
    }

    void startService() {
        _pActorScheduler->start();
        if ( !(_pTaskBinder->startGStation()) ) {
            cout << "[GStation Daemon Node] Could not start GStation Actor!" << endl;
        }
    }

    ros::NodeHandle _nh;
    ActorScheduler* _pActorScheduler;
    TaskBinder* _pTaskBinder;

};

int main(int argc,char** argv) {

    micROS::init();

    ros::init(argc,argv,"Ground_Station");
    ros::NodeHandle nh;

    string gstationInitXmlFilePath;
    if (nh.hasParam("GStationInitXmlFilePath")) {
        nh.getParam("GStationInitXmlFilePath",gstationInitXmlFilePath); 
    } else {
        //ROS_WARN("cannot find PlatformResourcesFile in the parameter server");
       cout << "[GStation Daemon Node] Cannot find Ground Station Initialization File in the parameter server! Please input file path through argv params!" << endl;
       if (argc != 2) {
           cout << "[GStation Daemon Node] Usage: rosrun gstation_daemon_node gstation_daemon_node YOUR_FILE_PATH" << endl;
           return -1;
       }      
       gstationInitXmlFilePath = argv[1];
    }
       
    boost::shared_ptr<general_bus::GeneralBus> pGStationBus(new general_bus::GeneralBus("gstation_bus"));
    std::vector<boost::shared_ptr<general_bus::GeneralBus>> busVec;
    busVec.push_back(pGStationBus);

    DaemonGStationApp DaemonGStationApp(nh, busVec, gstationInitXmlFilePath);
    
    DaemonGStationApp.startService();
    
    ros::spin();

    micROS::finish();
    return 0;
}
