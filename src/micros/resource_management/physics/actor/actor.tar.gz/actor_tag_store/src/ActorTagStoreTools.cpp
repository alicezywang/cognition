#include "actor_tag_store/ActorTagStoreTools.h"


bool interpretTagXML(TiXmlDocument& aDoc,ACTOR_STR2TAG_TYPE& anActorName2Tag,
		SWARM_STR2TAG_TYPE& aSwarmName2Tag, PLUGIN_STR2TAG_TYPE& aPluginName2Tag) {
	for (TiXmlElement *pActor=aDoc.RootElement();pActor!=NULL;pActor=pActor->NextSiblingElement()) {
		bool nameFound=false;
		bool tagFound=false;
		std::string nameStr,tagStr;
		{
			TiXmlElement *iter=pActor->FirstChildElement("name");
			if (iter!=NULL) {
				nameFound=true;
				nameStr=iter->GetText();
			}
		}
		{
			TiXmlElement *iter=pActor->FirstChildElement("tag");
			if (iter!=NULL) {
				tagFound=true;
				tagStr=iter->GetText();
			}
		}
		int32_t tag;
		if (nameFound && tagFound && (tagStr!="") && (sscanf(tagStr.c_str(),"%d",&tag)>0))  {

			if (std::string(pActor->Value())=="actor") {
				if (anActorName2Tag.find(nameStr)==anActorName2Tag.end()) {
					anActorName2Tag[nameStr]=(ACTOR_TAG_TYPE)tag;
				}
				else {
					printf("ERROR: duplicate setting of tag for the same actor %s\n",nameStr.c_str());
					return false;
				}
			}
			else if (std::string(pActor->Value())=="swarm") {
				if (aSwarmName2Tag.find(nameStr)==aSwarmName2Tag.end())
					aSwarmName2Tag[nameStr]=(SWARM_TAG_TYPE)tag;
				else {
					printf("ERROR: duplicate setting of tag for the same swarm %s\n",nameStr.c_str());
					return false;
				}
			}
			else if (std::string(pActor->Value())=="plugin") {
				if (aPluginName2Tag.find(nameStr)==aPluginName2Tag.end())
					aPluginName2Tag[nameStr]=(PLUGIN_TAG_TYPE)tag;
				else {
					printf("ERROR: duplicate setting of tag for the same plugin %s\n",nameStr.c_str());
					return false;
				}
			}
		}
	}	
	return true;
}
