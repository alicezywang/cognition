#include "actor_tag_store/ActorTagStore.h"
#include <iostream>
#include "micROSRTPSExt.h"
#include <unistd.h>
#include <ros/ros.h>

int main(int argc,char** argv) {
	ros::init(argc,argv,"test_actor_tag_store");
	micROS::init();
	if (!gActorTagStore.init()) {
		std::cout<<"FATAL: unable to get the actorName to tag mapping!"<<std::endl;
		return 1;
	}
	std::cout<<"tag for actor observer is "<<(int)gActorTagStore.actorName2Tag("observer")<<std::endl;
	std::cout<<"tag for actor leader is "<<(int)gActorTagStore.actorName2Tag("leader")<<std::endl;
	std::cout<<"tag for actor attacker is "<<(int)gActorTagStore.actorName2Tag("attacker")<<std::endl;
	std::cout<<"tag for swarm leader is "<<(int)gActorTagStore.swarmName2Tag("leader")<<std::endl;
	std::cout<<"tag for swarm attacker is "<<(int)gActorTagStore.swarmName2Tag("attacker")<<std::endl;


	micROS::finish();
	return 0;
}
