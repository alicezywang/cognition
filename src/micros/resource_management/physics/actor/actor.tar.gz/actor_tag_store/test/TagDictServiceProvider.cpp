#include "TagDictServiceProvider.h"

TagDictServiceProvider::TagDictServiceProvider() {
	_count=0;
}

//broadcast once when receiving a TagListReq, limited frequency 1Hz
void TagDictServiceProvider::tagListRequestCallback(TagListRequest& aMsg) {
	//calc time interval between last bcast and the current req in microsec
	double now = time(NULL);
	double duration=difftime(now,_lasttime);
	if (duration>=1) {
		_count++;
		printf("INFO: publishing the taglist for %d times\n",count);
		TagList tagList;
		tagList.data(gTagListStr.c_str());
		gPPub->publish(tagList);
		lasttime=now;
	}
}

void init() {
	gTagListStr="\
<actor><name>observer</name><tag>1</tag></actor>\
<actor><name>leader</name><tag>2</tag></actor>\
<actor><name>follower</name><tag>3</tag></actor>\
<actor><name>attacker</name><tag>4</tag></actor>\
		";
	std::string filePath;
	ros::NodeHandle nh;
	if (nh.getParam("taglistdict", filePath)) {
		TiXmlDocument doc(filePath);
		printf("try to get taglistdict from %s\n",filePath.c_str());
		if (doc.LoadFile()) {
			TiXmlPrinter printer;
			//printer.SetIndent( "    " );
			doc.Accept( &printer );
			gTagListStr = printer.CStr();
		}
	}
}

int main(int argc, char** argv)
{
	ros::init(argc,argv,"taglist_service_provider");
	micROS::init();
	
	init();

	gPPub=new RTPSPublisher<TagList>("TagList");
	gPPub->init();
	lasttime=time(NULL);
	RTPSSubscriber<TagListRequest> mysub("TagListRequest",tagListRequestCallback);
	mysub.init();
	while (true) {
		usleep(1000);
	}
	delete gPPub;

	micROS::finish();
	return 0;
}
