#ifndef __TAG_DICT_SERVICE_PROVIDER__
#define __TAG_DICT_SERVICE_PROVIDER__

#include "TagListRequest.h"
#include "TagList.h"
#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"

#include "micROSRTPSExt.h"
#include "tinyxml.h"
#include <time.h>
#include "ros/ros.h"


class TagDictServiceProvider {
public:
	void init();
	void start();
private:
	void tagListRequestCallback(TagListRequest& aReq);
	RTPSPublisher<TagList>* _pPub;
	std::string _tagListStr;
	double  _lasttime;
	int _count;
};

#endif
