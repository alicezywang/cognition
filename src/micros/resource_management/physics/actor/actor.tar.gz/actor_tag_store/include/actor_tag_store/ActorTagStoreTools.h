#include <map>
#include <string>
#include <stdint.h>
#include "tinyxml.h"
#include "actor_tag_store/actor_tag_store_options.h"

//typedef std::map<ACTOR_TAG_TYPE,std::string> ACTOR_TAG2STR_TYPE;
typedef std::map<std::string,ACTOR_TAG_TYPE> ACTOR_STR2TAG_TYPE;
//typedef std::map<SWARM_TAG_TYPE,std::string> SWARM_TAG2STR_TYPE;
typedef std::map<std::string,SWARM_TAG_TYPE> SWARM_STR2TAG_TYPE;

typedef std::map<std::string,PLUGIN_TAG_TYPE> PLUGIN_STR2TAG_TYPE;

bool interpretTagXML(TiXmlDocument& aDoc,ACTOR_STR2TAG_TYPE& anActorName2Tag,
		SWARM_STR2TAG_TYPE& aSwarmName2Tag, PLUGIN_STR2TAG_TYPE& aPluginName2Tag);


