//#define USING_XML_TAGDICT
#define USING_BINARY_TAGDICT
#define ACTOR_TAG_TYPE uint8_t
#define SWARM_TAG_TYPE uint8_t
#define PLUGIN_TAG_TYPE uint8_t


