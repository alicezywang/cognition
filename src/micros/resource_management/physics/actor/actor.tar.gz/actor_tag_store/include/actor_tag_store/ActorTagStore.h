#ifndef __ACTOR_DATA_STORE__
#define __ACTOR_DATA_STORE__

#include <map>
#include <string>
#include <stdint.h>
#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "TagList.h"
#include "TagListRequest.h"
#include "TagListBinary.h"
#include "tinyxml.h"
#include "actor_tag_store/actor_tag_store_options.h"

//note:
// member functions for ActorTagStore are not multi-thread safe
// data is initialized during the startup of actor_daemon_node and readonly thereafter


class ActorTagStore {
public:
	ActorTagStore();
	~ActorTagStore();
	bool init(std::string aFilePath="");

	ACTOR_TAG_TYPE actorName2Tag(const std::string& aName);
	std::string actorTag2Name(ACTOR_TAG_TYPE aTag);

	SWARM_TAG_TYPE swarmName2Tag(const std::string& aName);
	std::string swarmTag2Name(SWARM_TAG_TYPE aTag);

	PLUGIN_TAG_TYPE pluginName2Tag(const std::string& aName);
	std::string pluginTag2Name(PLUGIN_TAG_TYPE aTag);

private:
	bool doTagDictConflictTest();
	bool interpretXML(TiXmlDocument& aDoc);
	bool interpretBinary(TagListBinary& binary);
	void tagListCallback(TagList& aTagList);
	void tagListBinaryCallback(TagListBinary& aTagListBinary);

	std::map<ACTOR_TAG_TYPE,std::string> _actorTag2Name;
	std::map<std::string,ACTOR_TAG_TYPE> _actorName2Tag;
	std::map<SWARM_TAG_TYPE,std::string> _swarmTag2Name;
	std::map<std::string,SWARM_TAG_TYPE> _swarmName2Tag;
	std::map<std::string,PLUGIN_TAG_TYPE> _pluginName2Tag;
	bool _tagListReady;

#ifndef USING_BINARY_TAGDICT
	RTPSSubscriber<TagList> *_pSub;
#else
	RTPSSubscriber<TagListBinary> *_pSub;
#endif
	RTPSPublisher<TagListRequest> *_pPub;

};

extern ActorTagStore gActorTagStore;

#endif
