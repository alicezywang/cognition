#ifndef __MICROS_RTPS_EXT__
#define __MICROS_RTPS_EXT__


#include "micROSRTPS.h"
#include "MyPubSubTypes.h"

namespace micROS {

	template<class MsgType> 
	void registerType() {
		//todo: add rw-mutex
		boost::mutex::scoped_lock lock(gTopicDataTypeMutex);
		if (gTopicDataTypeDict.find(MsgType::getName())!=gTopicDataTypeDict.end()) {
			//std::cout<<"topic data type: "<<MsgType::getName()<<" is already registered!"<<std::endl;
			return;
		}
		TopicDataType* pMyType=new MyPubSubType<MsgType>();
		gTopicDataTypeDict[MsgType::getName()]=pMyType;
		pMyType->setName(MsgType::getName().c_str());
		Domain::registerType(gPParticipant,(TopicDataType*) pMyType);
	}
}

#endif
