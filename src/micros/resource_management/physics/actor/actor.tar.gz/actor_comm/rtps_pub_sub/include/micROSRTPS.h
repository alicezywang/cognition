#ifndef __MICROS_RTPS__
#define __MICROS_RTPS__

#include <fastrtps/fastrtps_fwd.h>
#include <map>
#include <fastrtps/Domain.h>
#include <fastrtps/participant/Participant.h>
#include <boost/thread/mutex.hpp>

#define ONE_PARTICIPANT

using namespace eprosima::fastrtps;
	
namespace micROS {
	extern Participant *gPParticipant;
	extern std::map<std::string,TopicDataType*> gTopicDataTypeDict;
	extern boost::mutex gTopicDataTypeMutex;

	extern bool init(std::string strRobotListFile="");

	extern void finish();
}
#endif
