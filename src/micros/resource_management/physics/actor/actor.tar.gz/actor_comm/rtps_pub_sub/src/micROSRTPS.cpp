#include "micROSRTPS.h"
#include <fastrtps/utils/IPFinder.h>
#include <iostream>
#include <string>
#include <fstream>
using namespace eprosima::fastrtps;

namespace micROS {

	Participant *gPParticipant=NULL;
	std::map<std::string,TopicDataType*> gTopicDataTypeDict;
	boost::mutex gTopicDataTypeMutex;

	bool init(std::string strRobotListFile) {
#ifdef ONE_PARTICIPANT
		if(gPParticipant == NULL){
			gTopicDataTypeDict.clear();

			// Create RTPSParticipant
			ParticipantAttributes PParam;
			PParam.rtps.builtin.domainId = 0;
			PParam.rtps.builtin.leaseDuration = c_TimeInfinite;
			//PParam.rtps.builtin.leaseDuration.seconds = 10;
			PParam.rtps.builtin.leaseDuration_announcementperiod.seconds = 10;
			PParam.rtps.setName("Participant_publisher");  //You can put here the name you want

			// discovery participant by user defined locator list
			if (!strRobotListFile.empty()) {
				std::fstream fs;
				fs.open(strRobotListFile.c_str(),std::fstream::in);
				if(fs.is_open()){
					// get local IPv4 addresses
					LocatorList_t loclist;
        			IPFinder::getIP4Address(&loclist);

					// read locator from file, and init initialPeersList.
					std::string addr;
					while(getline(fs, addr)){
						if(addr.empty() || addr[0] == '#') continue;
						
						eprosima::fastrtps::rtps::Locator_t locator;
						int pos = addr.find(":");
						locator.set_IP4_address(addr.substr(0, pos));
						locator.port = atoi(addr.substr(pos+1).c_str());
						PParam.rtps.builtin.initialPeersList.push_back(locator);

						locator.port = 0;
						if(loclist.contains(locator) && PParam.rtps.builtin.metatrafficUnicastLocatorList.size() == 0){
							locator.port = atoi(addr.substr(pos+1).c_str());
							PParam.rtps.builtin.metatrafficUnicastLocatorList.push_back(locator);
						}
					}
				}
				fs.close();

				std::cout<<"Use Static Participant Discovery:initialPeersList:"<<PParam.rtps.builtin.initialPeersList<<std::endl
				<<"metatrafficUnicastLocatorList:"<<PParam.rtps.builtin.metatrafficUnicastLocatorList<<std::endl;
			} 
			
			gPParticipant = Domain::createParticipant(PParam);
			if(gPParticipant == nullptr)
				return false;
		}
		return true;
#endif
	}

	void finish() {
#ifdef ONE_PARTICIPANT
		if (gPParticipant != nullptr)
			Domain::removeParticipant(gPParticipant);
		std::map<std::string,TopicDataType*>::iterator it;
		it=gTopicDataTypeDict.begin();
		while (it!=gTopicDataTypeDict.end()) {
			delete it->second;
			it++;
		}
#endif
	}
}

