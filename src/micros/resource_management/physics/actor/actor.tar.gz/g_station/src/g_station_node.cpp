#include "g_station/g_station.h"
#include "ros/ros.h"
#include <string>

using namespace std;

int main(int argc, char** argv) {

    //micROS::init();

    string swarmMatchFilePath;
    string swarmTaskFilePath;
    string utoTaskFilePath;
    bool getArgvFlag = true;
    if (argc != 3 || argc != 4)
    {
        //ROS_INFO("usage: rosrun g_station g_station_node YOUR_MATCH_FILE_PATH YOUR_TASK_FILE_PATH");
        cout << "usage: rosrun g_station g_station_node YOUR_MATCH_FILE_PATH YOUR_TASK_FILE_PATH" << endl;
        getArgvFlag = false;
    }
    else {
        swarmMatchFilePath = argv[1];
        swarmTaskFilePath = argv[2];
        utoTaskFilePath = argv[3];
    }

    ros::init(argc, argv, "ground_station");
    ros::NodeHandle nh;

    bool getParamFlag = false;
    // get swarm match file path from param server
    if (nh.hasParam("/swarm_match_file_path")) {
        nh.getParam("/swarm_match_file_path",swarmMatchFilePath); 
        getParamFlag = true;
    } else {
        // ROS_WARN("Cannot find swarm_match_file_path in the parameter server!");
        cout << "[Ground Station] Warning: Cannot find swarm_match_file_path in the parameter server!" << endl;
        getParamFlag = false;
    }
    // get swarm task file path from param server
    if (nh.hasParam("/swarm_task_file_path")) {
        nh.getParam("/swarm_task_file_path",swarmTaskFilePath); 
        getParamFlag = getParamFlag && true;
    } else {
        // ROS_WARN("Cannot find swarm_task_file_path in the parameter server!");
        cout << "[Ground Station] Warning: Cannot find swarm_task_file_path in the parameter server!" << endl;
        getParamFlag = false;
    }

    // Get uto task xml from param server
    if(nh.hasParam("/uto_task_file_path") && getParamFlag) {
        nh.getParam("/uto_task_file_path", utoTaskFilePath);
    }

    if (!getArgvFlag && !getParamFlag)
    {
        //ROS_ERROR("Could not get init file path from param server or command line! Please revise launch file or command line!");
        cout << "[Ground Station] ERROR: Could not get init file path from param server or command line! Please revise launch file or command line!" << endl;
        return 0;
    }

    cout << "swarm_match_file_path is " << swarmMatchFilePath << ", and swarm_task_file_path is " << swarmTaskFilePath << endl;
    cout << "uto_task_file_path is " << utoTaskFilePath << endl;

    // fastrtps participant discovery list 
    std::string strRobotListFile="";
    if (nh.hasParam("/robotListFile")) {
        nh.getParam("/robotListFile",strRobotListFile); 
    } else {
        ROS_WARN("cannot find robotListFile in the parameter server");
    }
    
    micROS::init(strRobotListFile);

    GStation* pStation = new GStation(swarmMatchFilePath, swarmTaskFilePath, utoTaskFilePath, 5, 5);
    //pStation->start();
    int sel = -1;
    std::string tmpStr = "";
    while(sel != 0){
        cout<<"##################################################"<<endl;
        cout<<"# 1. publish task \t\t 2.start task "<<endl;
        cout<<"# 3. publish uto event \t\t 0.exit "<<endl;
        cout<<"##################################################"<<endl;
        cout<<"choose your operation:";
        cin>>tmpStr;
        if(tmpStr.size() != 1 || !isdigit(tmpStr[0])){
            cout<<"error selection!"<<endl;
            continue;
        }
        sel = atoi(tmpStr.c_str());
        switch(sel){
            case 1:{
                cout<<"please input task xml file path:";
                string filePath = "";
                cin>>filePath;
                cout<<"please input robot number:";
                int robotNum = 0;
                cin>>robotNum;
                pStation->pubSwarmTask(filePath, robotNum);
                break;
            }
            case 2:{
                cout<<"please input task name to start:";
                string taskName = "";
                cin>>taskName;
                pStation->pubUTOEventToStartupTask(taskName);
                break;
            }
            case 3:{
                cout<<"please input actor name and event name, split by space:";
                string actorName = "", eventName = "";
                cin>>actorName>>eventName;
                pStation->pubUTOEventToSwitchActor(actorName, eventName);
                break;
            }
            default: break;
        }
        sleep(1);
    }

    
   // ros::spin();

    micROS::finish();

    return 1;
}
