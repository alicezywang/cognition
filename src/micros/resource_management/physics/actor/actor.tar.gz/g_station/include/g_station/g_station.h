#ifndef __G_STATION__
#define __G_STATION__

#include "ros/ros.h"
#include <string>
#include <iostream>
#include <tinyxml.h>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <sys/time.h>
#include <time.h>

#include "actor_core/actor_core.h"
#include "actor_msgs/swarm_task.h"
#include "actor_msgs/gstation_remote_cmds.h"
#include "g_station/SwarmTask.h"
#include "g_station/CtrlMsg.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"
#include "UTOEventWithGStation.h"
#include "UTOEventTransition.h"
#include "StringMsg.h"

using namespace std;

#define GET_CUR_SEC  \
	timeval temp_timeV;\
	gettimeofday(&temp_timeV,NULL);\
	string curSecStr;\
	stringstream temp_ss;\
	temp_ss.clear();\
	temp_ss << temp_timeV.tv_sec;\
	temp_ss >> curSecStr;

class GStation {
public:
	GStation(string aMatchFilePath, string aTaskFilePath, string anUtoFilePath, int aTimeDurationSingle, int aTimeDurationSwarm);
	~GStation();
	struct SwarmTaskResponse {
		int64_t platformID;
		std::vector<string> actorNameVec;
		std::vector<int> bidActorVec;
	};
	struct ActorArchitecture {
		std::vector<string> generalActors;
		std::vector<string> exclusiveActors;
		std::vector<string> dynamicActors;
	};
	struct SwarmArchitecture {
		struct ActorArchitecture actors;
		std::vector<int64_t> platformID;
	};
	struct SwarmArchitecture swarmArchitectureInfo;		// swarm size (or actor numbers) is considered, e.g. Observer1, Obsserver2, ...
	vector<string> swarmTaskActorList;					// compared to swarmArchitectureInfo, this variable does not consider swarm size, e.g. the vector may be like Observer, Leader, Follower, Transmitter, ...
	std::vector<struct SwarmTaskResponse> responseVec;
	std::vector<int64_t> confirmedPlatformID;
	ros::NodeHandle _nh;
	string _matchFilePath;
	string _taskFilePath;
	int _timeDurationSingle;
	int _timeDurationSwarm;
	string _swarmMatchXmlStr;
	string _swarmTaskXmlStr;
	string _swarmName;

	bool _taskAssignFlag;		// true: OK to assign task; false: not OK to assign task
	bool _confirmAssignFlag;		// true: task assignment confirmed; false: not confirmed
	bool _subRespOvertimeFlag;	// true: overtime while subscribing match responses; false: not overtime
	bool _subConfOvertimeFlag;	// true: overtime while subscribing task assignment confirmation; false: not overtime

	bool init();
	bool confirmSwarmTaskAssignment();

	//----------------------- Based on FAST-RTPS -----------------------//
	void pubRequirements();
	void pubAssignments();
	void pubFormationCtrlMsg();
	bool initSwarmArchitecture(string aXmlStr);
	void subscribeResponses();
	void subResponseCallback(SwarmTask& msg);
	void subscribeConfirmation();
	void subConfirmationCallback(SwarmTask& msg);
	void start();

	//-------------------------- Based on ROS --------------------------//
	void pubRequirements0();
	void pubAssignments0();
	void subscribeResponses0();
	void subResponseCallback0(const actor_msgs::swarm_task& msg);
	void subscribeConfirmation0();
	void subConfirmationCallback0(const actor_msgs::swarm_task& msg);
	void start0();

	void subRemoteCmdsCallback0(const actor_msgs::gstation_remote_cmds& msg);

	//------------------------------begin gstation new version---------------//
	// publish swarm task to all robots in the swarm, and wait for reply
	// @param taskFilePath taskxml file
	bool pubSwarmTask(const string& aTaskFilePath, const int aRobotNum);
	void subSwarmTaskXmlResponseCallback(StringMsg& msg);
	// notify all robots to switch state
	// @param currentActorName current actor which is running
	// @param eventName defined in task xml, this event will lead to actor switch
	bool pubUTOEventToStartupTask(const string& aSwarmName);
	bool pubUTOEventToSwitchActor(const string& aCurrentActorName, const string& aEventName);

private:
	bool pubUTOEvent(UTOEventWithGStation& aEvent);
	
private:
	RTPSPublisher<StringMsg> *_pPubTaskXml;	
	boost::mutex _pPubTaskXmlMutex;
	boost::condition_variable _pubCond;
	RTPSSubscriber<StringMsg> *_pSubTaskXmlResponse;

	RTPSPublisher<UTOEventWithGStation> *_pPubUTOEvent;
	boost::mutex _pPubUTOEventMutex;

	std::map<int64_t, std::vector<int32_t> > _cmdNoToResponseList;
	boost::shared_mutex _cmdNoToResponseListMutex;

	int64_t _curCmdNo;
	//------------------------------end gstation new version---------------//
private:
	RTPSPublisher<SwarmTask>  *_pPubReq;
	RTPSSubscriber<SwarmTask> *_pSubResp;
	RTPSPublisher<SwarmTask>  *_pPubAssign;
	RTPSSubscriber<SwarmTask> *_pSubConfirm;
	RTPSPublisher<CtrlMsg>  *_pPubCommand;
	ros::Subscriber _subRemoteCmds;

	// Uto
	string _utoFilePath;
	string _utoTaskXmlStr;
	RTPSPublisher<StringMsg>  *_utoPub;
	RTPSPublisher<UTOEventTransition>  *_utoSyncPub;
	RTPSSubscriber<UTOEventTransition> *_utoSyncSub;
	void subUTOEventCallback(UTOEventTransition &msg);
};

#endif
