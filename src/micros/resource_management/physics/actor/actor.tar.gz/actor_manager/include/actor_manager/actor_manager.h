#ifndef __ACTOR_MANAGER__
#define __ACTOR_MANAGER__

#include <tinyxml.h>
#include <stdlib.h>
#include <string>
#include <sstream>
#include <algorithm>
#include "actor_schedule/actor_schedule.h"
//#include "actor_election/actor_election.h"
#include "ros/ros.h"
#include "actor_core/ACB.h"
#include "actor_core/actor_types.h"
#include "actor_core/actor_constant.h"
// //consensus
// #include "micros_swarm/micros_swarm.h"//vs only needed
// #include "micros_swarm/serialize.h"
// #include "micros_swarm/singleton.h"
// #include "micros_swarm/runtime_handle.h"//rth 
// #include "micros_swarm/runtime_core.h"

#include "actor_manager/CtrlMsg.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

#define ACTOR_MANAGER_DEBUG

using namespace std;

const int8_t MODE_ELECTION_ON = 1;
const int8_t MODE_ELECTION_OFF = 2;

class ActorManager {
public:
	ActorManager(ActorScheduler *aPActorScheduler);
	// ActorManager(ActorScheduler *aPActorScheduler, int64_t aPlatformID);
	// ActorManager(ActorScheduler *aPActorScheduler, ActorElection *aPActorElection, int64_t aPlatformID);	
	~ActorManager();
	
	// Based on FAST-RTPS
	std::string _curSwarmTaskXmlStr;
	std::string _curSwarmCommandStr;
	int64_t _platformID;
	string _swarmName, _actorName, _platformIdListStr, _dataStr;
	std::vector<string> _platformIdList;
	std::vector<string> _formationTypeList;
	std::vector<string> _formationPosList;
	void start();
	void handleMasterDataCmdCallback(CtrlMsg &aMsg);
	bool decomposeCtrlMsg();

private:
	ros::NodeHandle _nh;
	RTPSSubscriber<CtrlMsg> *_pSubCommand;
	ActorScheduler *_pActorScheduler;
	//ActorElection *_pActorElection;
	int8_t _workMode;
};

#endif

