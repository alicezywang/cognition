#ifndef __SWARM_INFO_H__
#define __SWARM_INFO_H__
#include <boost/thread/shared_mutex.hpp>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#define ACTOR_SWARM_LOG_OUT
#define INVALID_ROBOTID -1
#define INVALID_ROBOTPOS -1

// Enums Rotot State
enum ESwarmRobotState{
    KEEPING,    // robot is liveliness 
    LEAVE,      // robot has left the swarm
    VOTING     // robot is waiting for master election(used for local robot)
};

struct RobotInfoDyn{
    ESwarmRobotState _state = KEEPING;
    std::string _sSwarmName = "";
    std::string _sActorName = "";
    std::string _sFormationType = "";
    int _iFormationPos = INVALID_ROBOTPOS;
    std::vector<std::string> _vSwarmActors;
};

struct RobotHBLatencyStatistic{
    double _mean = 0.0f;           // mean value
    double _stddev = 0.0f;         // standard deviation
    double _confidence = 0.0f;   // confidence intervals of the standard deviation for normal distribution
    double _quantile = 0.0f;       // quantile for normal distribution computed by _confidence
};

// compare with task.xml
enum ESwarmActorType{
    GENERAL,
    EXCLUDE,
    DYNAMIC
};

struct ActorGroupInfo{
    ESwarmActorType _type = GENERAL;
    std::string _sActorName = "";
    int _iActorMaxCount = 0;
    int _iActorPriority = 0; 
};

// Class SwarmDataStorage, this is a singleton class which is used for save robots information in the same swarm,
// and provides interfaces to get these information.
class SwarmDataStorage{
public:
    ~SwarmDataStorage();
    static SwarmDataStorage* instance();

     // this method should be called once the application start up
     // @param aRobotID  the local robot id
     // @param logFilePath this file will be used to log robot operations,you can set ACTOR_SWARM_LOG_OUT to disable it
     // @note  this method will add local robot to the swarm and set self as the master,this will be useful when the robot start up alone.
    void init(const int aRobotID, std::string aLogFilePath="");

    int getLocalRobotID();

    // robotstate
    void setLocalRobotState(const ESwarmRobotState aState);
    ESwarmRobotState getLocalRobotState();
    ESwarmRobotState getRobotStateByID(const int aRobotID);

    // masterid
    // the master in the swarm is used to control all the robots. 
    void setMasterID(const int aMasterID);
    int getMasterID();

    // get all liveliness robots id in the swarm
    void getRobotIDs(std::vector<int>& vRobotIDs);

    // get liveliness robots count in the swarm 
    int getRobotCount();

    // this method will be called when a new robot join in the swarm
    // @note when robot joinin, it's state will be set to KEEPING
    void addRobotToLocalSwarm(const int aRobotID);

    // this method will be called when a robot leave the swarm
    // @note when robot left, it's state will be set to LEAVE
    void removeRobotFromLocalSwarm(const int aRobotID);

    // running actors
    // @return if not exists, return empty string
    std::string getSwarmNameByID(const int aRobotID);
    void getRobotActorsByID(const int aRobotID, std::string& aSwarmName, std::vector<std::string>& aSwarmActors);

    // this method will be called when actors running on the robot is changed, or deceted other robot's actors changed.
    void setRobotActors(const int aRobotID, const std::string aSwarmName, const std::vector<std::string>& aSwarmActors);

    // formation
    // @return if not exists, then return INVALID_ROBOTPOS
    int getRobotPosByID(const int aRobotID);
    bool getRobotPosByID(const int aRobotID,std::string &aSwarmName,std::string &aActorName,std::string &aFormationType,int &aFormationPos);
    
    // @return if not exists, then return INVALID_ROBOTID
    int getRobotIDByPos(const int aRobotPos);

    // get all liveliness robot pos with vector 
    // @param aMapRobotPos pos->robotID
    void getAllRobotPos(std::map<int, int>& aMapRobotPos);
    void setRobotPos(const int aRobotID, const int aRobotPos);
    void setRobotPos(const int aRobotID, const int aRobotPos, const std::string aSwarmName, const std::string aActorName, const std::string aFormationType);
    
    // this method will be called when the swarm formation reassiged
    // @param aMapRobotPos pos->robotID
    void resetRobotPos(std::map<int,int>& aMapRobotPos);

    // heartbeat value, 0~1, means the weight of liveliness
    float getRobotHeartbeatValueByID(const int aRobotID);
    void setRobotHeartbeatValue(const int aRobotID, float aValue);

    // heartbeat latency statistic
    const boost::shared_ptr<RobotHBLatencyStatistic> getRobotHBLatencyStatistic(const int aRobotID);
    void setRobotHBLatencyStatistic(const int aRobotID, const double aMean, const double aStddev, const double aQuantile);
    double getRobotHBLatencyStatisticConfidence(const int aRobotID);
    void setRobotHBLatencyStatisticConfidence(const int aRobotID, const double aConfidence);
    double getMaxRobotHBLatency(const int aRobotID = INVALID_ROBOTID);
    double getMeanRobotHBLatency(const int aRobotID = INVALID_ROBOTID);

    // task actors,set when task bind
    void setSwarmTaskActorInfo(const std::string aSwarmName, const std::string aActorName, const ESwarmActorType aType, const int aNum, const int aPriority);
    
    // check if has robot running the actor
    bool isActorExist(const std::string aSwarmName, const std::string aActorName);

    // get the robot count, which is running the actor
    int getSwarmActorCount(const std::string aSwarmName, const std::string aActorName);

    // get the max actor count allowed by the swarm task.
    int getSwarmActorMaxCount(const std::string aSwarmName, const std::string aActorName);

    void printInformation();

    //write masterID/swarmsize/votestate/events to log file
    void logOut2File(std::string aItem, std::string aData);
    //write member heart beat to log file
    void logOutHB2File(int32_t aMemberID,int32_t aData);

private:
    SwarmDataStorage();
 
private:
    class MapValueFinder{
    public:
        MapValueFinder(const int &val):_val(val){}
        bool operator ()(const std::map<int, boost::shared_ptr<RobotInfoDyn> >::value_type &pair){
            return pair.second->_iFormationPos == _val;
        }
    private:
        const int &_val;                    
    };
    
    // instance and gc
    static SwarmDataStorage* _instance;
    class GC{
    public: ~GC(){
            if(_instance){
                delete _instance;
                _instance = NULL;
            }
        }
    }_gc;

    // robotID
    int _localRobotID;
    boost::shared_mutex _localRobotIDMutex;

    // masterID
    int _localMasterID;
    boost::shared_mutex _localMasterIDMutex;

    // swarm actor infos,set when gstation pub swarm task.
    typedef std::map<std::string, boost::shared_ptr<ActorGroupInfo> > ACTORGROUPMAP;
    typedef std::map<std::string, ACTORGROUPMAP> SWARMACTORGROUPMAP;
    SWARMACTORGROUPMAP _swarmName2InfoFromTask;
    boost::shared_mutex _swarmName2InfoFromTaskMutex;
    
    // swarm robot infos, contains all robot information in the swarm
    typedef std::map<int, boost::shared_ptr<RobotInfoDyn> > ROBOTINFOMAP;
    ROBOTINFOMAP _robotID2Info;//robotID--SwarmActors
    boost::shared_mutex _robotID2InfoMutex;

    // calculate based on heartbeat count before robot join. 0 means robot is leave, 1 means robot is keeping
    // saved by SwarmRobotHeartbeatStrategySimple object
    std::map<int, float> _robotID2HeartbeatValue;
    boost::shared_mutex _robotID2HeartbeatValueMutex;

    // calculate based on heartbeat latency data, and saved by SwarmRobotHeartbeatStrategyLatency object.
    std::map<int, boost::shared_ptr<RobotHBLatencyStatistic> > _robotID2HBLatencyStatistic;
    boost::shared_mutex _robotID2HBLatencyStatisticMutex;

    //dibin add, log file 
    //fstream for test data log
    std::fstream _fs;
    boost::mutex _fsMutex;

};
#endif
