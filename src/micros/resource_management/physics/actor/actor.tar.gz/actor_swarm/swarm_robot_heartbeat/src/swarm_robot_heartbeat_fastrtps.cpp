#include "swarm_robot_heartbeat/swarm_robot_heartbeat_fastrtps.h"
SwarmRobotHeartbeat_RTPS::SwarmRobotHeartbeat_RTPS(){
    _hbCount = 0;
    _pPubHeartbeat = new RTPSPublisher<Heartbeat>("/heartbeat");
    _pSubHeartbeat = new RTPSSubscriber<Heartbeat>("/heartbeat", &SwarmRobotHeartbeat_RTPS::heartbeatCallback, this);
}

SwarmRobotHeartbeat_RTPS::~SwarmRobotHeartbeat_RTPS(){
    if(_pPubHeartbeat){
        delete _pPubHeartbeat;
        _pPubHeartbeat = NULL;
    }
    if(_pSubHeartbeat){
        delete _pSubHeartbeat;
        _pSubHeartbeat = NULL;
    }
}

void SwarmRobotHeartbeat_RTPS::run(){
    Heartbeat hb;
    hb.sendID(_robotID);
    while(1){
        hb.hbCount(_hbCount++);
        _pPubHeartbeat->publish(hb);
        usleep(_hbPeriod*1000);
    }
}


void SwarmRobotHeartbeat_RTPS::heartbeatCallback(Heartbeat& aHB){
    processHeartbeatMsg(aHB.sendID());
}

