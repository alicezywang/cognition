#ifndef __SWARM_ROBOT_HEARTBEAT_STIGMERGY_LATENCY_H__
#define __SWARM_ROBOT_HEARTBEAT_STIGMERGY_LATENCY_H__
#include "swarm_robot_heartbeat_strategy.h"
#include <boost/accumulators/accumulators.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/rolling_window.hpp>
#include <boost/accumulators/statistics/rolling_variance.hpp>
#include <boost/accumulators/statistics/rolling_mean.hpp>
#include <boost/math/distributions/normal.hpp>
#include <boost/math/distributions/exponential.hpp>
#include <boost/date_time/posix_time/posix_time.hpp> 
using namespace boost::accumulators;

//  heart beat stragety,compute latency data by rolling window
class SwarmRobotHeartbeatStrategyLatency: public SwarmRobotHeartbeatStrategy{
public:
	SwarmRobotHeartbeatStrategyLatency();
	~SwarmRobotHeartbeatStrategyLatency();
	virtual void processHeartbeatMsg(const int aRobotID);

protected:
	void checkRobotStateLoop();

private:
    // thread to check robot state
	boost::shared_ptr<boost::thread> _pthCheckRobotState;

	// struct contains heartbeat data and statistic objects
	typedef accumulator_set<double, stats<tag::rolling_mean, tag::rolling_variance, tag::rolling_count, tag::rolling_sum > > ROLLINGSET;
	struct HBLatencyDistribution{
		int32_t _state;					
		boost::posix_time::ptime _lastHBTime; 
		ROLLINGSET* _acc = NULL;
		boost::math::normal_distribution<>* _normal = NULL;
		boost::math::exponential_distribution<>* _exponential = NULL;
		void release(){
			if(_acc){
				delete _acc;
				_acc = NULL;
			}
			if(_normal){
				delete _normal;
				_normal = NULL;
			}
			if(_exponential){
				delete _exponential;
				_exponential = NULL;
			}
		}
	};

	// contains all robots hearbeat latency data in the swarm
    std::map<int32_t, HBLatencyDistribution> _robotID2HBLatency;
    boost::mutex _robotID2HBLatencyMutex;
};
#endif
