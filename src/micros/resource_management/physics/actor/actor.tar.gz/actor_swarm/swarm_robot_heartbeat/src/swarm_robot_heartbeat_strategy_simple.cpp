#include "swarm_robot_heartbeat/swarm_robot_heartbeat_strategy_simple.h"
#include "swarm_data_storage/swarm_data_storage.h"

SwarmRobotHeartbeatStrategySimple::SwarmRobotHeartbeatStrategySimple(){
    //calculate heart beat time out count
    _hbTimeOutCount = _hbTimeOut*1000/HB_CHECK_PERIOD;
    if(_hbTimeOutCount <= 0){
        ROS_FATAL("[SwarmRobotHeartbeatStrategySimple] heart beat time out <=0");
        return;
    }
    
    _robotJoinTimeOutCount = _robotJoinTimeOut*1000/HB_CHECK_PERIOD;
    if(_robotJoinTimeOutCount <= 0){
        ROS_FATAL("[SwarmRobotHeartbeatStrategySimple] robot join heart beat time out <=0");
        return;
    }
    //start the robot state check loop
    _pthCheckRobotState = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&SwarmRobotHeartbeatStrategySimple::checkRobotStateLoop, this)));    
}

SwarmRobotHeartbeatStrategySimple::~SwarmRobotHeartbeatStrategySimple(){
    if(_pthCheckRobotState){
        _pthCheckRobotState->join();
        _pthCheckRobotState->interrupt();
        _pthCheckRobotState.reset();
    }
}

void SwarmRobotHeartbeatStrategySimple::processHeartbeatMsg(const int32_t aRobotID){
    boost::unique_lock<boost::mutex> rscLock(_robotID2StateCountMutex);
    //if receive heart beat from new robot, set its state to ROBOT_STATE_JOIN
    if (_robotID2StateCount.count(aRobotID) == 0) {
        RobotStateCount joinCount;
        joinCount._state = ROBOT_STATE_JOIN;
        joinCount._count = 1;
        joinCount._timeOut = _robotJoinTimeOutCount;
        _robotID2StateCount[aRobotID] = joinCount;

        ROS_INFO("[SwarmRobotHeartbeatStrategySimple] new heartbeat[%d]", aRobotID);
        #ifdef ACTOR_SWARM_LOG_OUT
        std::string eventStr = "newHB:" + std::to_string(aRobotID);
        SwarmDataStorage::instance()->logOut2File("event", eventStr);
        #endif
    } else {
        switch (_robotID2StateCount[aRobotID]._state) {
        case ROBOT_STATE_JOIN:
            _robotID2StateCount[aRobotID]._count++;
            break;
        case ROBOT_STATE_STAY:
            _robotID2StateCount[aRobotID]._count = 0;
            break;
        default:
            break;
        }
    }
    rscLock.unlock();
    #ifdef ACTOR_SWARM_LOG_OUT
    SwarmDataStorage::instance()->logOutHB2File(aRobotID,1);
    #endif
}

void SwarmRobotHeartbeatStrategySimple::checkRobotStateLoop(){
    
    while (true){
        {
        boost::unique_lock<boost::mutex> rscLock(_robotID2StateCountMutex);
        for (std::map<int32_t, RobotStateCount>::iterator it = _robotID2StateCount.begin(); it != _robotID2StateCount.end();) {
            bool eraseRobot = false;
            //hbValue indicates the degree/probability a robot is in the group, [0,1]
            float hbValue = -1;
            switch (it->second._state) {
            case ROBOT_STATE_JOIN:
                hbValue = float(it->second._count)/float(_robotJoinHBCount);
                if(hbValue>1) hbValue = 1;
                SwarmDataStorage::instance()->setRobotHeartbeatValue(it->first, hbValue);
                it->second._timeOut--;

                //if receive more than _robotJoinHBCount hb in _robotJoinTimeOut, set the state to ROBOT_STATE_STAY
                if(it->second._timeOut >= 0){
                    if(it->second._count >= _robotJoinHBCount) {
                        it->second._state = ROBOT_STATE_STAY;
                        it->second._count = 0;
                        //send robot join msg
                        sendRobotJoinMsg(it->first);
                    }
                } else {// else remove
                    #ifdef ACTOR_SWARM_LOG_OUT
                    std::string eventStr = "newHB failed:" + std::to_string(it->first);
                    SwarmDataStorage::instance()->logOut2File("event", eventStr);
                    #endif
                    
                    eraseRobot = true;
                    SwarmDataStorage::instance()->setRobotHeartbeatValue(it->first, 0);
                    it = _robotID2StateCount.erase(it);
                }
                break;
            case ROBOT_STATE_STAY:
                hbValue = 1.0 - float(it->second._count)/float(_hbTimeOutCount);
                if(hbValue<0) hbValue = 0;
                SwarmDataStorage::instance()->setRobotHeartbeatValue(it->first, hbValue);
                it->second._count++; //lose count++

                //if time out,erase the robot
                if (it->second._count >= _hbTimeOutCount) {
                    eraseRobot = true;
                    sendRobotLeaveMsg(it->first);
                    it = _robotID2StateCount.erase(it);
                }
                break;
            default:
                break;
            }
            //if didnot erase robot, it++
            if (!eraseRobot)
                it++;
        }
        }
        usleep(HB_CHECK_PERIOD * 1000);
    }
}	