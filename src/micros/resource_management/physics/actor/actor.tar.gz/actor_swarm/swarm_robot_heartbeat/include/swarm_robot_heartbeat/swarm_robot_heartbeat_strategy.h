#ifndef __SWARM_ROBOT_HEARTBEAT_STRATEGY_H__
#define __SWARM_ROBOT_HEARTBEAT_STRATEGY_H__
#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler.h"

#define HB_CHECK_PERIOD 100   //check the robot state in HB_CHECK_PERIOD (ms)
//robot is JOINing the group
const int32_t ROBOT_STATE_JOIN = 1;
//robot STAY in the group
const int32_t ROBOT_STATE_STAY = 2;

//base class for heart beat handling strategy
class SwarmRobotHeartbeatStrategy{
public:
	SwarmRobotHeartbeatStrategy();
    virtual ~SwarmRobotHeartbeatStrategy();
	virtual void processHeartbeatMsg(const int aRobotID)=0;
	void initHeatbeatHandler(SwarmRobotHeartbeatHandler* aHandler){
		_pHandler = aHandler;
	}

protected:
	//strategy judge if a robot is join/leave, and send a join/leave msg to handler
	void sendRobotJoinMsg(const int aRobotID);
	void sendRobotLeaveMsg(const int aRobotID);

protected:
	//variables which may be useful in most strategies
	//heartbeat time out(robot leave), 
	//a robot is considered to leave the group if cannot receive its heart beat msg in _hbTimeOut(s) 
	int32_t _hbTimeOut;
	//heart beat counting when robot joining the group
	//a robot is consider to join the group if _robotJoinHBCount heart beats were received in _robotJoinTimeOut (s)
	int32_t _robotJoinHBCount;
	int32_t _robotJoinTimeOut;
private:
	//handler to process robot join/leave msg
	SwarmRobotHeartbeatHandler* _pHandler;
};
#endif
