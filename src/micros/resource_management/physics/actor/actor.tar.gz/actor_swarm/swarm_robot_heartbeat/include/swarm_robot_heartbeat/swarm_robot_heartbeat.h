#ifndef __SWARM_ROBOT_HEARTBEAT_H__
#define __SWARM_ROBOT_HEARTBEAT_H__
#include "swarm_robot_heartbeat_strategy.h"
//base class for robot heart beat
class SwarmRobotHeartbeat{
public:
    SwarmRobotHeartbeat();
    virtual ~SwarmRobotHeartbeat();
	virtual void run()=0;

	void initHeartbeatStrategy(SwarmRobotHeartbeatStrategy* aStrategy){
		_pHeartbeatStrategy = aStrategy;
	}
protected:
	void processHeartbeatMsg(const int aRobotID);
	int _robotID;
    int32_t _hbPeriod; //heart beat period, robots send heart beat msg every _hbPeriod ms
	
private:
	//pointer to heart beat strategy
	SwarmRobotHeartbeatStrategy* _pHeartbeatStrategy;
};


#endif