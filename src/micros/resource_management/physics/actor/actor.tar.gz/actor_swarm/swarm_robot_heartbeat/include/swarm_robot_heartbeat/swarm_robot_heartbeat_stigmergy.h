#ifndef __SWARM_ROBOT_HEARTBEAT_STIGMERGY_H__
#define __SWARM_ROBOT_HEARTBEAT_STIGMERGY_H__
#include "swarm_robot_heartbeat.h"
#include "micros_swarm/micros_swarm.h"
#include <map>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
//robot heart beat send/receive through stigmergy
class SwarmRobotHeartbeat_Stigmergy:public SwarmRobotHeartbeat{
public:
	SwarmRobotHeartbeat_Stigmergy();
	virtual ~SwarmRobotHeartbeat_Stigmergy();
	virtual void run();

private:
	void checkHeartBeatLoop();
	void checkHeartBeat();

	void updateHeartBeatLoop();
	void updateHeartBeat();

private:
	

	//vs for swarm members
    micros_swarm::VirtualStigmergy _vs;
    boost::mutex _vsMutex;

	//robotID-->lamport_clock
	std::map<int32_t, int32_t> _robotID2Clock;
	boost::mutex _rcMutex;

	// thread for put heartbeat and receive heartbeat
	boost::shared_ptr<boost::thread> _pthUpdateHeartBeat;
	boost::shared_ptr<boost::thread> _pthCheckHeartBeat;
};


#endif