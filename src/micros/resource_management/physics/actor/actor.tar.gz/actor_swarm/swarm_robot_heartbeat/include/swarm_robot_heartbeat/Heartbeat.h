#ifndef __HEARTBEAT_H__
#define __HEARTBEAT_H__

#include <stdint.h>
#include <string>
#include <fastcdr/Cdr.h>
namespace eprosima
{
    namespace fastcdr
    {
        class Cdr;
    }
}
// fastrtps heartbeat msg
class Heartbeat{
public:
    Heartbeat(){
        _sendID = 0;
        _hbCount = 0; 
    }

    ~Heartbeat(){}

    void sendID(int16_t aSendID){
        _sendID = aSendID; 
    }

    int16_t sendID(){ 
        return _sendID; 
    }

    void hbCount(uint64_t aHbCount){ 
        _hbCount = aHbCount; 
    } 

    uint64_t hbCount(){
        return _hbCount;
    }

    static size_t getMaxCdrSerializedSize(size_t current_alignment = 0){
        size_t initial_alignment = current_alignment;
        current_alignment += 2 + eprosima::fastcdr::Cdr::alignment(current_alignment, 2);
        current_alignment += 8 + eprosima::fastcdr::Cdr::alignment(current_alignment, 8);
        return current_alignment - initial_alignment;
    }

    static size_t getCdrSerializedSize(const Heartbeat& data, size_t current_alignment = 0){
        size_t initial_alignment = current_alignment;    
        current_alignment += 2 + eprosima::fastcdr::Cdr::alignment(current_alignment, 2);
        current_alignment += 8 + eprosima::fastcdr::Cdr::alignment(current_alignment, 8);
        return current_alignment - initial_alignment;
    }

    void serialize(eprosima::fastcdr::Cdr &cdr) const{
        cdr<<_sendID;
        cdr<<_hbCount;
    }

    void deserialize(eprosima::fastcdr::Cdr &cdr){
        cdr>>_sendID;
        cdr>>_hbCount;
    }

    static size_t getKeyMaxCdrSerializedSize(size_t current_alignment = 0){
        return current_alignment;
    }

    static bool isKeyDefined(){
        return false;
    }

    void serializeKey(eprosima::fastcdr::Cdr &cdr) const{}

    static std::string getName() { return "Heartbeat"; } 
private:
    int16_t _sendID;
    uint64_t _hbCount;
};

#endif