#include "swarm_robot_heartbeat/swarm_robot_heartbeat.h"
#include "swarm_robot_heartbeat/swarm_robot_heartbeat_strategy_simple.h"
#include "swarm_data_storage/swarm_data_storage.h"

#define HB_PERIOD 500 //heart beat period,default 500ms

SwarmRobotHeartbeat::SwarmRobotHeartbeat(){
    ros::NodeHandle nh;
    if (nh.hasParam("/HeartBeatPeroid")) {
        nh.getParam("/HeartBeatPeroid", _hbPeriod); 
    } else {
        _hbPeriod = HB_PERIOD;
    }

    _robotID = SwarmDataStorage::instance()->getLocalRobotID();
    
}

SwarmRobotHeartbeat::~SwarmRobotHeartbeat(){
    if(_pHeartbeatStrategy){
        delete _pHeartbeatStrategy;
        _pHeartbeatStrategy = NULL;
    }
}

void SwarmRobotHeartbeat::processHeartbeatMsg(const int32_t aRobotID){
    if(_robotID != aRobotID) // ignore local heartbeat
        _pHeartbeatStrategy->processHeartbeatMsg(aRobotID);//handle the heart beat from aRobotID according to the strategy
}