#include "swarm_robot_heartbeat/swarm_robot_heartbeat_strategy.h"
#include "ros/ros.h"

//default parameters for robot heart beat
#define HB_TIME_OUT 5           // heart beat time out, (s)
#define ROBOT_JOIN_HB_COUNT 3   // heartbeat count before robot join
#define ROBOT_JOIN_TIME_OUT 3   // robot join time out, (s)

SwarmRobotHeartbeatStrategy::SwarmRobotHeartbeatStrategy(){
    ros::NodeHandle nh;
    if (nh.hasParam("/HeartBeatTimeOut")) {
        nh.getParam("/HeartBeatTimeOut", _hbTimeOut); 
    } else {
        _hbTimeOut = HB_TIME_OUT;
    }

    if (nh.hasParam("/RobotJoinHBCount")) {
        nh.getParam("/RobotJoinHBCount", _robotJoinHBCount); 
    } else {
        _robotJoinHBCount = ROBOT_JOIN_HB_COUNT;
    }

    if (nh.hasParam("/RobotJoinTimeout")) {
        nh.getParam("/RobotJoinTimeout", _robotJoinTimeOut); 
    } else {
        _robotJoinTimeOut = ROBOT_JOIN_TIME_OUT;
    }
    ROS_INFO("[SwarmRobotHeartbeatStrategy] _hbTimeOut=%d, _robotJoinHBCount=%d, _robotJoinTimeOut=%d", _hbTimeOut, _robotJoinHBCount, _robotJoinTimeOut);
}

SwarmRobotHeartbeatStrategy::~SwarmRobotHeartbeatStrategy(){
    if(_pHandler){
        delete _pHandler;
        _pHandler = NULL;
    }
}

void SwarmRobotHeartbeatStrategy::sendRobotJoinMsg(const int aRobotID){
    ROS_INFO("[SwarmRobotHeartbeatStrategy] sendRobotJoinMsg,%d", aRobotID);
    _pHandler->processRobotJoinMsg(aRobotID);
}

void SwarmRobotHeartbeatStrategy::sendRobotLeaveMsg(const int aRobotID){
    ROS_INFO("[SwarmRobotHeartbeatStrategy] sendRobotLeaveMsg,%d", aRobotID);
    _pHandler->processRobotLeaveMsg(aRobotID);
}