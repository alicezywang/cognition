#ifndef __SWARM_ROBOT_HEARTBEAT_FASTRTPS_H__
#define __SWARM_ROBOT_HEARTBEAT_FASTRTPS_H__
#include "swarm_robot_heartbeat.h"
#include "Heartbeat.h"
//robot heart beat send/receive through fast-rtps, didnot implement yet
class SwarmRobotHeartbeat_RTPS:public SwarmRobotHeartbeat{
public:
	SwarmRobotHeartbeat_RTPS();
	virtual ~SwarmRobotHeartbeat_RTPS();
	virtual void run();

private:
	void heartbeatCallback(Heartbeat& aHB);

private:
	unsigned long long _hbCount;
	RTPSPublisher<Heartbeat>* _pPubHeartbeat;
    RTPSSubscriber<Heartbeat>* _pSubHeartbeat;
	
};

#endif