#ifndef __SWARM_ROBOT_HEARTBEAT_STIGMERGY_SIMPLE_H__
#define __SWARM_ROBOT_HEARTBEAT_STIGMERGY_SIMPLE_H__
#include "swarm_robot_heartbeat_strategy.h"
#include <map>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>

struct RobotStateCount{
	int32_t _state;//ROBOT_STATE_JOIN or ROBOT_STATE_STAY
	int32_t _count;
	int32_t _timeOut;
};
//a simple heart beat stragety
//a robot is considered to leave the group if cannot receive its heart beat msg in _hbTimeOut(s) 
//a robot is consider to join the group if _robotJoinHBCount heart beats were received in _robotJoinTimeOut (s)
class SwarmRobotHeartbeatStrategySimple: public SwarmRobotHeartbeatStrategy{
public:
	SwarmRobotHeartbeatStrategySimple();
	~SwarmRobotHeartbeatStrategySimple();
	virtual void processHeartbeatMsg(const int aRobotID);

protected:
	void checkRobotStateLoop();

private:
    int32_t _hbTimeOutCount; //counter for robot leave time out
	int32_t _robotJoinTimeOutCount;//counter for robot join time out
	boost::shared_ptr<boost::thread> _pthCheckRobotState;

	//map stores robot state count info, robotID-->RobotStateCount
	std::map<int32_t, RobotStateCount> _robotID2StateCount;
	boost::mutex _robotID2StateCountMutex;
};
#endif
