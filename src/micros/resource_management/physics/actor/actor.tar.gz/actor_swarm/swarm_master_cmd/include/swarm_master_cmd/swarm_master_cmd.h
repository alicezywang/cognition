#ifndef __SWARM_MASTER_CMD_H__
#define __SWARM_MASTER_CMD_H__
#include <map>
#include <vector>
#include "actor_schedule/actor_schedule.h"
#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "MasterCmd.h"
#include "ros/time.h"
#include "actor_core/barrier.h"

//receID received by all members, used by destRobotID
const int32_t RECE_ID_ALL_MEMBER = -1;

//request actor from master type defination
const int32_t REQUEST_ACTOR_TYPE_ACTIVATE = 1;  // just need activate the request actor
const int32_t REQUEST_ACTOR_TYPE_SWITCH = 2;    // stop current actor and activate the request actor

//swarm master cmd msg channel, send/receive master cmd to/from swarm members and g_statioin through fastrtps
class SwarmMasterCmd{
public:
    SwarmMasterCmd(boost::shared_ptr<ActorScheduler> pScheduler);
    ~SwarmMasterCmd();

    // this method will be called when robot join, the master will add it to swarm formation
    void addRobotToFormation(const int32_t aRobotID);

    // this method will be called when robot join or leave, the master should reassign swarm formation
    void reassignFormation();

    // called when local robot becomes the master, to notify other member robots
    // or when a robot join, the master should notify it.
    void sendIamMasterCmd(const int32_t aOldMasterID, const int32_t aDestRobotID = RECE_ID_ALL_MEMBER);
    
    // called when a robot join, the master should share all robots information to it.
    // currently just share the swarm formation infomation.
    void sendInfo2RobotNewJoin(const int32_t aRootID);
    
    // called when the robot need a actor, this method will send a request to the master.
    // @param aSendActorName the actor which call this method
    // @param aActorName request actor
    // @param aType REQUEST_ACTOR_TYPE_ACTIVATE / REQUEST_ACTOR_TYPE_SWITCH
    void sendSwarmActorRequestCmd(const std::string aSendActorName, const std::string aActorName, int aType);

    // called when the master receive actor request
    // @note if multi robots request the same actor within 10s, the master will handle it as a same command
    bool handleSwarmActorRequest(int32_t aSendID, int aType, std::string aSwarmName, std::string aSendActorName,std::string aActorName);
        
    // called when plugin reached to the barrier point, it will send barrier request to the master
    BarrierResult sendBarrierRequestCmd(GlobalBarrierKey& aBarrierKey, int aWaitCount, const short aTimeout);

    // called when the master received barrier request, when received robots count >= aWaitCount, the master will reply to these robots with yes result
    // @param aCalledByLocal false-master receive barrier request and call this method, true-master call this method to process local barrier request
    // @return true-if aCalledByLocal and notify local barrier condition, false-else
    BarrierResult handleBarrierRequest(GlobalBarrierKey& aBarrierKey, const int aWaitCount, const int aRobotID, bool aCalledByLocal = false);

    // called when a robot leave,then clear all master cmds that will send to it
    void clearMasterCmdsForRobot(const int32_t aRobotID);
    
    // called when switch master, and this robot change to member, then clearAllMasterCmds
    void clearAllMasterCmds();
private:
    //send master cmd and master cmd call back
    bool sendMasterCmdAndGetReply(MasterCmd* pCmd);
    void sendMasterCmd(MasterCmd* pCmd);
    void masterCmdCallback(MasterCmd& aCmd);
    void gsMasterCmdCallBack(MasterCmd& aGSCmd);

    //resend master cmd until recv reply, config periodic time by RESEND_DURATION_CMD_RTPS
    void resendTimeoutMasterCmdLoop();
    void resendTimeoutMasterCmd();

private:
    int _robotID;

    //pointer to scheduler
    boost::shared_ptr<ActorScheduler> _pActorScheduler;

    //rtps sub pub master cmd from ground station
    RTPSPublisher<MasterCmd>* _pPubGSMasterCmd;
    RTPSSubscriber<MasterCmd>* _pSubGSMasterCmd;

    //rtps sub pub master cmd with swarm members
    RTPSPublisher<MasterCmd>* _pPubMasterCmd;
    RTPSSubscriber<MasterCmd>* _pSubMasterCmd;
    boost::mutex _pubMutex;

    //send cmdNo map, cmdNo-->map(robotID-->reply), 
    //reply init RESEND_NUM_CMD_RTPS, and decrease it when receive reply
    std::map<int32_t,std::map<int32_t,int32_t> > _cmdNo2RobotReplyCount;
    boost::shared_mutex _cmdNo2RobotReplyCountMutex;

    // increased by 1, when create a new cmd
    int32_t _masterCmdNo;

    // contains received master cmdNo, robotID-->cmdNo (used by member robots)
    std::map<int32_t,int32_t> _robotID2ReceivedCmdNo; 

    // contains msg which is timeout and should be resend by _pthResendTimeoutMsgs thread
    std::map<int, std::map<int, MasterCmd*> > _robotID2TimeoutMsg; // receID-->(cmdNo->cmd)
    boost::shared_mutex _robotID2TimeoutMsgMutex;
    boost::shared_ptr<boost::thread> _pthResendTimeoutMsgs;

    // store actor request cmd result, actorName->(time, allowed robotIDs)
    // only for master
    std::map<std::string, std::pair<ros::Time, std::vector<int> > >_actorName2RequestResult;
    boost::shared_mutex _actorName2RequestResultMutex;

    // store barrier list,<barrier key, received robotsIDs>
    // only for master
    struct BarrierRequestList{
        bool _isReplyed;
        ros::Time _firstRequestTime;
        ros::Time _firstReplyTime;
        std::set<int> _requestRobots;
        BarrierRequestList():_isReplyed(false){}
    };
    std::map<GlobalBarrierKey, BarrierRequestList> _barrierKey2BarrierRequestList;
    boost::shared_mutex _barrierKey2BarrierRequestListMutex;

    // store barrier condition signal,when receive barrier response from master, it will send this signal
    // only for member robot
    std::map<GlobalBarrierKey, std::pair<boost::shared_ptr<boost::condition_variable>, BarrierResult> > _barrierKey2ConditionAndResult;
    boost::shared_mutex _barrierKey2ConditionAndResultMutex;
};
#endif