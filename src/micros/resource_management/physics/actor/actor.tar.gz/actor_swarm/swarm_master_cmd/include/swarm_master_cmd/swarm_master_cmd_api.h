#ifndef __SWARM_MASTER_CMD_API_H__
#define __SWARM_MASTER_CMD_API_H__
#include <string>
#include "actor_core/barrier.h"
class SwarmMasterCmd;
extern SwarmMasterCmd *gSwarmMasterCmd;
// request actor from master
// deprecated
extern void requestSwarmActorFromMaster(const std::string& anActorName);

extern void requestActivateActorFromMaster(const std::string& aSendActorName,const std::string& anActorName);
extern void requestSwitchActorFromMaster(const std::string& aSendActorName,const std::string& anActorName);

// actor barrier api
// @param aBarrierKey   barrierKey, should be unique in the actor control process
// @param aWaitCount    when the number of robots reached to the barrier >= aWaitCount, the caller will go on.
// @param aTimeout      seconds,default 5s
extern BarrierResult actorBarrierApi(GlobalBarrierKey& aBarrierKey, int aWaitCount,  const short aTimeout = 5);

// plugin barrier api,
// @param aBarrierKey   barrierKey, should be unique in the same plugin
// @param aWaitCount    when the number of robots reached to the barrier >= aWaitCount, the caller will go on. 
// @param aTimeout      seconds,default 5s
extern BarrierResult pluginBarrierApi(GlobalBarrierKey& aBarrierKey, int aWaitCount,  const short aTimeout = 5);


#endif