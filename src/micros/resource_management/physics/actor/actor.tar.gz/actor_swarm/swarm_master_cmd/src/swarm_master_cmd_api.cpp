#include "swarm_master_cmd/swarm_master_cmd_api.h"
#include "swarm_master_cmd/swarm_master_cmd.h"
SwarmMasterCmd* gSwarmMasterCmd = NULL;

//deprecated
void requestSwarmActorFromMaster(const std::string& anActorName){
    ROS_INFO("reqeustSwarmActorFromMaster api");
    if(gSwarmMasterCmd){
        //gSwarmMasterCmd->sendSwarmActorRequestCmd(anActorName);
    }
}

void requestActivateActorFromMaster(const std::string& aSendActorName,const std::string& anActorName){
    ROS_INFO("request activate actor from master api called");
    if(gSwarmMasterCmd){
        gSwarmMasterCmd->sendSwarmActorRequestCmd(aSendActorName,anActorName,REQUEST_ACTOR_TYPE_ACTIVATE);
    }
}

void requestSwitchActorFromMaster(const std::string& aSendActorName,const std::string& anActorName){
    ROS_INFO("request switch actor from master api called");
    if(gSwarmMasterCmd){
        gSwarmMasterCmd->sendSwarmActorRequestCmd(aSendActorName,anActorName,REQUEST_ACTOR_TYPE_SWITCH);
    }
}

BarrierResult actorBarrierApi(GlobalBarrierKey& aBarrierKey, int aWaitCount,  const short aTimeout){
    if(gSwarmMasterCmd){
        //if(aBarrierKey._actorName.empty() || aBarrierKey._barrierKey == -1){
        if(aWaitCount < 0 || aBarrierKey._barrierKey == -1){
            ROS_WARN("actorBarrierApi: invalid param!");
            return BarrierResult::NO;
        }
        //aBarrierKey._pluginName.clear();
        return gSwarmMasterCmd->sendBarrierRequestCmd(aBarrierKey, aWaitCount, aTimeout);
    }
    return BarrierResult::NO;
}

BarrierResult pluginBarrierApi(GlobalBarrierKey& aBarrierKey, int aWaitCount, const short aTimeout){
    if(gSwarmMasterCmd){
        //if(aBarrierKey._actorName.empty() || aBarrierKey._pluginName.empty() || aBarrierKey._barrierKey == -1){
        if(aWaitCount < 0 || aBarrierKey._barrierKey < 0){
            ROS_WARN("pluginBarrierApi: invalid param!");
            return BarrierResult::NO;
        }

        return gSwarmMasterCmd->sendBarrierRequestCmd(aBarrierKey, aWaitCount, aTimeout);
    }
    return BarrierResult::NO;
}