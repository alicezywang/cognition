#include "swarm_master_cmd/swarm_master_cmd.h"
#include "swarm_data_storage/swarm_data_storage.h"
#include "actor_tag_store/ActorTagStore.h"
#include "ros/ros.h"
#include <vector>
#include <algorithm>

//resend num and duration for master cmd with rtps
#define RESEND_NUM_CMD_RTPS 3
#define RESEND_DURATION_CMD_RTPS 100 // ms

//cmd type defination
const int32_t CMD_TYPE_REPLY = 0;               // reply msg
const int32_t CMD_TYPE_ACTIVATE_ACTOR = 1;      // master->member
const int32_t CMD_TYPE_YIELD_ACTOR = 2;         // master->member
const int32_t CMD_TYPE_SWITCH_ACTOR = 3;        // master->member
const int32_t CMD_TYPE_SET_FORMATION = 4;       // master->member
const int32_t CMD_TYPE_GET_FORMATION = 5;       // master->member
const int32_t CMD_TYPE_SET_SAVE_FORMATION = 6;  // master->member,to notify all member robots save reassigned position
const int32_t CMD_TYPE_SET_FORMATION_SWITCH = 7;// master->member,to notify member robot change position
const int32_t CMD_TYPE_SWITCH_MASTER = 8;       // master->member,used for switch master,new master send this cmd

const int32_t CMD_TYPE_REQUEST_ACTOR = 9;       // member->master,request actor
const int32_t CMD_TYPE_REQUEST_ACTOR_RSP = 10;  // master->member,response actor

const int32_t CMD_TYPE_BARRIER_REQUEST = 11;    // member->master
const int32_t CMD_TYPE_BARRIER_RESPONSE = 12;        // master->member

SwarmMasterCmd::SwarmMasterCmd(boost::shared_ptr<ActorScheduler> pScheduler):_masterCmdNo(0){
    _robotID = SwarmDataStorage::instance()->getLocalRobotID();
    _pActorScheduler = pScheduler;

    _pPubMasterCmd = new RTPSPublisher<MasterCmd>("/master_cmd");
    _pSubMasterCmd = new RTPSSubscriber<MasterCmd>("/master_cmd",&SwarmMasterCmd::masterCmdCallback,this); 

    _pPubGSMasterCmd = new RTPSPublisher<MasterCmd>("/gs_swarm_master_cmd");
    _pSubGSMasterCmd = new RTPSSubscriber<MasterCmd>("/gs_swarm_master_cmd",&SwarmMasterCmd::masterCmdCallback,this);

    _pthResendTimeoutMsgs = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&SwarmMasterCmd::resendTimeoutMasterCmdLoop,this)));
    _pthResendTimeoutMsgs->detach();
}

SwarmMasterCmd::~SwarmMasterCmd(){
    _pActorScheduler.reset();

    if(_pPubMasterCmd){
        delete _pPubMasterCmd;
        _pPubMasterCmd = NULL;
    }

    if(_pSubMasterCmd){
        delete _pSubMasterCmd;
        _pSubMasterCmd = NULL;
    }

    if(_pPubGSMasterCmd){
        delete _pPubGSMasterCmd;
        _pPubGSMasterCmd = NULL;
    }

    if(_pSubGSMasterCmd){
        delete _pSubGSMasterCmd;
        _pSubGSMasterCmd = NULL;
    }

    if(_pthResendTimeoutMsgs){
        _pthResendTimeoutMsgs->join();
        _pthResendTimeoutMsgs->interrupt();
        _pthResendTimeoutMsgs.reset();
    }

    for(std::map<int, std::map<int, MasterCmd*> >::iterator it = _robotID2TimeoutMsg.begin(); it != _robotID2TimeoutMsg.end(); it++){
        for(std::map<int, MasterCmd*>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++){
            delete it2->second;
            it2->second = NULL;
        }
    }
    _robotID2TimeoutMsg.clear(); // or swap

    _barrierKey2BarrierRequestList.clear();

    _barrierKey2ConditionAndResult.clear();
}

void SwarmMasterCmd::gsMasterCmdCallBack(MasterCmd& aGSCmd){
    //TODO:
    //sub cmd from ground station, and send the cmd to swarm members
}

// when robot join, assign a larger formation pos
void SwarmMasterCmd::addRobotToFormation(const int32_t aRobotID){
    if(INVALID_ROBOTPOS == SwarmDataStorage::instance()->getRobotPosByID(aRobotID)){
        int nextPos = SwarmDataStorage::instance()->getRobotCount();
        SwarmDataStorage::instance()->setRobotPos(aRobotID, nextPos);
        ROS_INFO("[SwarmMasterCmd] add robot [%d],pos [%d]", aRobotID, nextPos);
    }
}

//spread formation pos when needed
//set formation pos when Leader/Follower loses, DA required
//broadcast the formation pos info, saved by all members and set by target member
//when leader loses, send the formation pos data firstly and then send the tranfer actor cmd
void SwarmMasterCmd::reassignFormation(){
    std::map<int, int> mapRobotPos; // pos->robotID
    SwarmDataStorage::instance()->getAllRobotPos(mapRobotPos);

    //if invalid_pos exists, then set a larger pos for these robots whose pos is -1
    if (mapRobotPos.count(INVALID_ROBOTPOS) > 0) {
    #ifdef ACTOR_SWARM_LOG_OUT
        SwarmDataStorage::instance()->logOut2File("event", "INVALID POS exists when reassign");
    #endif

        mapRobotPos.erase(INVALID_ROBOTPOS);
        std::vector<int> robots;
        SwarmDataStorage::instance()->getRobotIDs(robots);
        for (int i = 0; i < robots.size(); i++) {
            //if not find, set a larger pos
            std::map<int, int>::iterator it = mapRobotPos.begin();
            for (; it != mapRobotPos.end(); it++)
            {
                if (it->second == robots[i])
                    break;
            }
            if (it == mapRobotPos.end())
                mapRobotPos[robots.size() + i] = robots[i];
        }
    }

    std::string sSwarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);

    // reassign robot position in formation
    for (int pos = 0; pos < mapRobotPos.size(); pos++) {
        //if pos not exist, reassign and send switch cmd
        if (mapRobotPos.count(pos) != 0) continue; 

        // if this position has no robot,then find a robot which is in the same side and its pos > pos
        std::map<int32_t, int32_t>::iterator nextRobot = mapRobotPos.upper_bound(pos);
        //IF NOT FOUND, SOMETHING WROING
        if (nextRobot == mapRobotPos.end()) {
            ROS_FATAL("[SwarmMasterCmd] no larger pos for %d", pos);
            return;
        }

        // if the robot in the same side ,if has none ,then use the nearest one
        for (; nextRobot != mapRobotPos.end(); nextRobot++) {
            if (pos%2 == nextRobot->first%2) {
                break;
            }
        } 

        //if not find a plat with the same side, find the min pos 
        if (nextRobot == mapRobotPos.end()) {
            nextRobot = mapRobotPos.upper_bound(pos);
        }

        // replace
        mapRobotPos[pos] = nextRobot->second;
        mapRobotPos.erase(nextRobot);  

         //log to file
        #ifdef ACTOR_SWARM_LOG_OUT
            std::string logStr = "reassign pos->id:";
            logStr.append(std::to_string(pos))
            .append(std::to_string(mapRobotPos[pos]))
            .append(", islocal=").append(std::to_string(mapRobotPos[pos] == _robotID));
            SwarmDataStorage::instance()->logOut2File("event",logStr);
        #endif          
        
        std::string startActorName = pos == 0 ? "Leader" : "Follower";
        std::string stopActorName = pos == 0 ? "Follower" : "Leader";
        
        // if local, switch lcoal actor
        if (mapRobotPos[pos] == _robotID) {
            _pActorScheduler->setFormation(sSwarmName, startActorName, "0", std::to_string(pos));
            _pActorScheduler->pauseActor(sSwarmName, stopActorName);
            _pActorScheduler->activateActor(sSwarmName, startActorName);
        } else { // else send switch msg
            MasterCmd *cmd = new MasterCmd();
            cmd->sendID(_robotID);
            cmd->receID(mapRobotPos[pos]);
            cmd->type(CMD_TYPE_SET_FORMATION_SWITCH);
            cmd->param1(gActorTagStore.swarmName2Tag(sSwarmName));
            cmd->param2(gActorTagStore.actorName2Tag(startActorName));
            cmd->param3(0);
            cmd->param4(pos);
            cmd->param5(gActorTagStore.actorName2Tag(stopActorName));
    
            sendMasterCmd(cmd);
        }

        // broadcast the cmd to inform pos info
        MasterCmd *cmd = new MasterCmd();
        cmd->sendID(_robotID);
        cmd->receID(RECE_ID_ALL_MEMBER);
        cmd->type(CMD_TYPE_SET_SAVE_FORMATION);
        cmd->param1(gActorTagStore.swarmName2Tag(sSwarmName));
        cmd->param2(gActorTagStore.actorName2Tag(startActorName));
        cmd->param3(0);
        cmd->param4(pos);
        cmd->param5(mapRobotPos[pos]);

        sendMasterCmd(cmd);
        
    }

    SwarmDataStorage::instance()->resetRobotPos(mapRobotPos);
}

// send by master robot
void SwarmMasterCmd::sendIamMasterCmd(const int32_t aOldMasterID, const int32_t aDestRobotID){
    ROS_INFO("[SwarmMasterCmd] sendIamMasterCmd aOldMasterID is [%d]", aOldMasterID);
    
    //if aDestRobotID is all members, then send the msg to all member robots.
    if (aDestRobotID == RECE_ID_ALL_MEMBER) {
        std::vector<int> robotIDs;
        SwarmDataStorage::instance()->getRobotIDs(robotIDs);
        for (int i = 0; i < robotIDs.size(); i++) {
            if (_robotID == robotIDs[i])
                continue;
            MasterCmd *cmd = new MasterCmd();
            cmd->sendID(_robotID);
            cmd->receID(robotIDs[i]);
            cmd->type(CMD_TYPE_SWITCH_MASTER);
            cmd->param1(aOldMasterID);
            sendMasterCmd(cmd);
        }
    } else {
        MasterCmd *cmd = new MasterCmd();
        cmd->sendID(_robotID);
        cmd->receID(aDestRobotID);
        cmd->type(CMD_TYPE_SWITCH_MASTER);
        cmd->param1(aOldMasterID);
        sendMasterCmd(cmd);
    }
}

//send swarm info to member new joined, called by master
//only send the information which is necessary, formation pos for now
void SwarmMasterCmd::sendInfo2RobotNewJoin(const int32_t aRootID){ 
    if(SwarmDataStorage::instance()->getSwarmNameByID(_robotID).empty())return;
    
    ROS_INFO("[SwarmMasterCmd] sendInfo2RobotNewJoin to robot[%d]", aRootID);
    std::vector<int> robotIDs;
    SwarmDataStorage::instance()->getRobotIDs(robotIDs);

    std::string swarmName = "", actorName = "", formationType = "";
    int formationPos = INVALID_ROBOTPOS;
    for (int i = 0; i < robotIDs.size(); i++) {
        //only send formation pos of other robots
        if (aRootID == robotIDs[i])
            continue;
        swarmName.clear();
        actorName.clear();
        formationType.clear();
        formationPos = INVALID_ROBOTPOS;
        if (SwarmDataStorage::instance()->getRobotPosByID(robotIDs[i], swarmName, actorName, formationType, formationPos)) {
            MasterCmd *cmd = new MasterCmd();
            cmd->sendID(_robotID);
            cmd->receID(aRootID);
            cmd->type(CMD_TYPE_SET_SAVE_FORMATION);
            cmd->param1(gActorTagStore.swarmName2Tag(swarmName));
            cmd->param2(gActorTagStore.actorName2Tag(actorName));
            cmd->param3(0);
            cmd->param4(formationPos);
            cmd->param5(robotIDs[i]);
            sendMasterCmd(cmd);
        }
    }
}

// send by member robot, also handle from master itself
void SwarmMasterCmd::sendSwarmActorRequestCmd(const std::string aSendActorName, const std::string aActorName, int aType){
    ROS_INFO("[SwarmMasterCmd] sendSwarmActorRequestCmd, aSendActorName=%s, aActorName=%s, type=%d", aSendActorName.c_str(), aActorName.c_str(), aType);
    
    int masterID = SwarmDataStorage::instance()->getMasterID();
    std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    //if receive request from master itself
    if(_robotID == masterID){
        ROS_WARN("[SwarmMasterCmd] receive swarm actor request: local is master.");
        if(handleSwarmActorRequest(_robotID, aType, swarmName, aSendActorName, aActorName)){
            switch (aType) {
                case REQUEST_ACTOR_TYPE_ACTIVATE:
                    _pActorScheduler->activateActor(swarmName, aActorName); 
                    ROS_INFO("[SwarmMasterCmd] recvRequestActor answer, master allowd activate actor [%s].", aActorName.c_str());
                    break;
                case REQUEST_ACTOR_TYPE_SWITCH:
                    _pActorScheduler->pauseActor(swarmName, aSendActorName);
                    _pActorScheduler->activateActor(swarmName, aActorName); 
                    ROS_INFO("[SwarmMasterCmd] recvRequestActor answer, master allowd switch to actor [%s].", aActorName.c_str());
                    break;
                default:
                    break;
            } 
        }
    }else{
        //send request cmd
        MasterCmd *cmd = new MasterCmd();
        cmd->sendID(_robotID);
        cmd->receID(masterID);
        cmd->type(CMD_TYPE_REQUEST_ACTOR);
        cmd->param1(aType);
        cmd->param2(gActorTagStore.swarmName2Tag(swarmName));
        cmd->param3(gActorTagStore.actorName2Tag(aSendActorName));
        cmd->param4(gActorTagStore.actorName2Tag(aActorName));

        sendMasterCmd(cmd);
    }
}

//handle swarm actor request cmd
bool SwarmMasterCmd::handleSwarmActorRequest(int32_t aSendID, int aType, std::string aSwarmName, std::string aSendActorName,std::string aActorName){
    ROS_INFO("[SwarmMasterCmd] recvRequestActor request,robot[%d] need actor[%s]", aSendID, aActorName.c_str());
    
    // request actor cmd in 10s, be process as the same cmd
    //compensate the time (send cmd + activate/switch actor + broadcast running actors through stigmergy)
    boost::shared_lock<boost::shared_mutex> rlock(_actorName2RequestResultMutex);
    if(_actorName2RequestResult.count(aActorName) == 0){
        _actorName2RequestResult[aActorName].first = ros::Time::now();
    }else{
        ros::Time now = ros::Time::now();
        int seconds = (now - _actorName2RequestResult[aActorName].first).toSec();
        if(seconds >= 10){
            _actorName2RequestResult[aActorName].first = now;
            _actorName2RequestResult[aActorName].second.clear();
        }
    }
    
    // store robotID who runs the actor, and reject other robot if actor reached on max Count
    bool reqRet = true;
    std::string curSwarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    if(curSwarmName.empty() || curSwarmName.compare(aSwarmName) != 0 || !SwarmDataStorage::instance()->isActorExist(aSwarmName, aActorName)){
        reqRet = false;
    } else if(std::find(_actorName2RequestResult[aActorName].second.begin(), _actorName2RequestResult[aActorName].second.end(), aSendID) == _actorName2RequestResult[aActorName].second.end()) {
        int runActorCount = SwarmDataStorage::instance()->getSwarmActorCount(aSwarmName, aActorName);
        int maxActorCount = SwarmDataStorage::instance()->getSwarmActorMaxCount(aSwarmName, aActorName);
        if (runActorCount < _actorName2RequestResult[aActorName].second.size())
            runActorCount = _actorName2RequestResult[aActorName].second.size();
        if(runActorCount < maxActorCount){
            _actorName2RequestResult[aActorName].second.push_back(aSendID);
        } else {
            reqRet = false;
        }
    }

    return reqRet;
}

BarrierResult SwarmMasterCmd::sendBarrierRequestCmd(GlobalBarrierKey& aBarrierKey, int aWaitCount, const short aTimeout){
    // read swarmName
    // if(aBarrierKey._swarmName.empty()){
    //     std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    //     aBarrierKey._swarmName = swarmName;
    // }

    // use actor maxcount as the aWaitCount
    // if(aWaitCount == -1){
    //     aWaitCount = SwarmDataStorage::instance()->getSwarmActorMaxCount(aBarrierKey._swarmName, aBarrierKey._actorName);
    // }

    // create condition_variable for aBarrierKey
    boost::shared_ptr<boost::condition_variable> cond(new boost::condition_variable());
    {   
        boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2ConditionAndResultMutex);  
        _barrierKey2ConditionAndResult[aBarrierKey].second = NO;
        _barrierKey2ConditionAndResult[aBarrierKey].first = cond;
    }

    // if the barrier is on master node, then process it 
    int masterID = SwarmDataStorage::instance()->getMasterID();
    if(_robotID == masterID){
        // when process local barrier, all barriers may reach to synchronous state, the methos should return immediately
        BarrierResult localRet = handleBarrierRequest(aBarrierKey, aWaitCount, _robotID, true);
        if(localRet == YES || localRet == OPTIONALYES){
            return localRet;
        }
    } else { // if the barrier is on member node, then send barrier cmd to the master node
        MasterCmd *cmd = new MasterCmd();
        cmd->sendID(_robotID);
        cmd->receID(masterID);
        cmd->type(CMD_TYPE_BARRIER_REQUEST);
        // cmd->param1(gActorTagStore.swarmName2Tag(aBarrierKey._swarmName));
        // cmd->param2(gActorTagStore.actorName2Tag(aBarrierKey._actorName));
        // cmd->param3(gActorTagStore.pluginName2Tag(aBarrierKey._pluginName));
        cmd->param4(aBarrierKey._barrierKey);
        cmd->param5(aWaitCount);
        sendMasterCmd(cmd);
    }

    boost::mutex mutex;
    boost::unique_lock<boost::mutex> lock(mutex);
    //boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2ConditionAndResultMutex);
    BarrierResult ret = NO;
    if(cond->timed_wait(lock, boost::get_system_time() + boost::posix_time::seconds(aTimeout))){
        ret = _barrierKey2ConditionAndResult[aBarrierKey].second;
    } else {
        ret = TIMEOUT;
    }

    boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2ConditionAndResultMutex);
    _barrierKey2ConditionAndResult[aBarrierKey].first.reset();
    _barrierKey2ConditionAndResult.erase(aBarrierKey);
    return ret;
}

BarrierResult SwarmMasterCmd::handleBarrierRequest(GlobalBarrierKey& aBarrierKey, const int aWaitCount, const int aRobotID, bool aCalledByLocal){
    boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2BarrierRequestListMutex);
    if(_barrierKey2BarrierRequestList.count(aBarrierKey) == 0){
        _barrierKey2BarrierRequestList[aBarrierKey]._firstRequestTime = ros::Time::now();
        if(_barrierKey2BarrierRequestList.size() > 100){
            _barrierKey2BarrierRequestList.erase(_barrierKey2BarrierRequestList.begin());
        }
    }
    _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.insert(aRobotID);

    BarrierResult ret = NO;
    if(_barrierKey2BarrierRequestList[aBarrierKey]._isReplyed || _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.size() >= aWaitCount){
        if(!_barrierKey2BarrierRequestList[aBarrierKey]._isReplyed)
            _barrierKey2BarrierRequestList[aBarrierKey]._firstReplyTime = ros::Time::now();
        ret = _barrierKey2BarrierRequestList[aBarrierKey]._isReplyed? OPTIONALYES : YES; 

        // notify local robot
        if(_barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.count(_robotID) != 0){
            ROS_INFO("[SwarmMasterCmd] handleBarrierRequest, notify local barrier");
            if(!aCalledByLocal){ // if triggered by remote robot,notify local barrier
                boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2ConditionAndResultMutex);
                if(_barrierKey2ConditionAndResult.count(aBarrierKey) != 0){
                    _barrierKey2ConditionAndResult[aBarrierKey].second = ret;
                    _barrierKey2ConditionAndResult[aBarrierKey].first->notify_one();
                }
            }
            _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.erase(_robotID);
        }

        // notify remote robot
        for(auto it = _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.begin(); it !=  _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.end(); it++){
            MasterCmd *cmd = new MasterCmd();
            cmd->sendID(_robotID);
            cmd->receID(*it);
            cmd->type(CMD_TYPE_BARRIER_RESPONSE);
            // cmd->param1(gActorTagStore.swarmName2Tag(aBarrierKey._swarmName));
            // cmd->param2(gActorTagStore.actorName2Tag(aBarrierKey._actorName));
            // if(!aBarrierKey._pluginName.empty())
            //     cmd->param3(gActorTagStore.pluginName2Tag(aBarrierKey._pluginName));
            cmd->param4(aBarrierKey._barrierKey);
            cmd->param5(ret);
            sendMasterCmd(cmd);
        }

        // erase robots in BarrierRequestList
        _barrierKey2BarrierRequestList[aBarrierKey]._isReplyed = true;
        _barrierKey2BarrierRequestList[aBarrierKey]._requestRobots.clear();
    }
    return ret;
}

// return if the cmd replyed
bool SwarmMasterCmd::sendMasterCmdAndGetReply(MasterCmd* pCmd){
    bool reply = true;
    int32_t cmdNo = pCmd->cmdNo();
    boost::shared_lock<boost::shared_mutex> cmdNoReadLock(_cmdNo2RobotReplyCountMutex);
    for (std::map<int32_t,int32_t>::iterator it = _cmdNo2RobotReplyCount[cmdNo].begin(); it != _cmdNo2RobotReplyCount[cmdNo].end(); it++) {
        if (it->second == RESEND_NUM_CMD_RTPS) {
            reply = false;
            break;
        }
    }
    cmdNoReadLock.unlock();

    if (!reply) {
        //ROS_INFO("[SwarmMasterCmd] sendMasterCmdAndGetReply, cmdNo=%d, type=%d, dest=%d", cmdNo, pCmd->type(), pCmd->receID());
        #ifdef ACTOR_SWARM_LOG_OUT
            std::string logStr = "sendMasterCmd";
            logStr.append(std::to_string(pCmd->sendID())).append("-->").append(std::to_string(pCmd->receID()))
            .append(" cmdNo:").append(std::to_string(pCmd->cmdNo()))
            .append(" cmdType:").append(std::to_string(pCmd->type()));
            SwarmDataStorage::instance()->logOut2File("event",logStr);
        #endif
        boost::unique_lock<boost::mutex> pubCmdLock(_pubMutex);
        _pPubMasterCmd->publish(*pCmd);
        pubCmdLock.unlock();
    }

    return reply;
}

void SwarmMasterCmd::sendMasterCmd(MasterCmd* pCmd){
    boost::unique_lock<boost::shared_mutex> cmdNoWriteLock(_cmdNo2RobotReplyCountMutex);
    _masterCmdNo++;
    pCmd->cmdNo(_masterCmdNo);
    if (pCmd->receID() == RECE_ID_ALL_MEMBER) {
        std::vector<int> vRobotIDs;
        SwarmDataStorage::instance()->getRobotIDs(vRobotIDs);
        for (std::vector<int>::iterator it = vRobotIDs.begin(); it != vRobotIDs.end(); it++) {
            if (_robotID != *it)
                _cmdNo2RobotReplyCount[_masterCmdNo].insert(std::pair<int32_t, int32_t>(*it, RESEND_NUM_CMD_RTPS));
        }
    } else {
        _cmdNo2RobotReplyCount[_masterCmdNo].insert(std::pair<int32_t, int32_t>(pCmd->receID(), RESEND_NUM_CMD_RTPS));
    }
    cmdNoWriteLock.unlock();

    //push back to the cmd msg queue
    boost::unique_lock<boost::shared_mutex> wlock(_robotID2TimeoutMsgMutex);
    ROS_INFO("[SwarmMasterCmd] Add a cmd to msg queue to send cmdNo %d, receId %d, cmdType %d", pCmd->cmdNo(),pCmd->receID(),pCmd->type());
    if(_robotID!=pCmd->receID())
    _robotID2TimeoutMsg[pCmd->receID()].insert(std::pair<int,MasterCmd*>(pCmd->cmdNo(),pCmd));

}

void SwarmMasterCmd::masterCmdCallback(MasterCmd& aCmd){
    int32_t receID = aCmd.receID();
    int32_t sendID = aCmd.sendID();
    int32_t cmdNo = aCmd.cmdNo();
    int32_t masterID = SwarmDataStorage::instance()->getMasterID();

    if((receID != _robotID && receID != RECE_ID_ALL_MEMBER) // this robot is not target
        || sendID == _robotID) // this robot is sender
        return;

    //log to file
    #ifdef ACTOR_SWARM_LOG_OUT
        std::string logStr = "recvMasterCmd";
        logStr.append(std::to_string(sendID)).append("-->").append(std::to_string(receID))
        .append(" cmdNo:").append(std::to_string(cmdNo))
        .append(" cmdType:").append(std::to_string(aCmd.type()));
        SwarmDataStorage::instance()->logOut2File("event",logStr);
    #endif

    //if it is a reply msg
    if (aCmd.type() == CMD_TYPE_REPLY) {
        //ROS_INFO("[SwarmMasterCmd] recv reply, cmdNo=%d, sender=%d", cmdNo, sendID);
        boost::unique_lock<boost::shared_mutex> cmdNoWriteLock(_cmdNo2RobotReplyCountMutex);
        if (_cmdNo2RobotReplyCount.count(cmdNo) > 0 && _cmdNo2RobotReplyCount[cmdNo].count(sendID) > 0)
            _cmdNo2RobotReplyCount[cmdNo][sendID]--;
        return;
    }

    //handle the cmd msg
    // cmd from master
    if (sendID == masterID) {
        // answer from master,so cmdNo may be smaller than _robotID2ReceivedCmdNo[sendID]
        if(aCmd.type() == CMD_TYPE_REQUEST_ACTOR_RSP){ 
            boost::unique_lock<boost::shared_mutex> cmdNoWriteLock(_cmdNo2RobotReplyCountMutex);
            if (_cmdNo2RobotReplyCount.count(cmdNo) > 0 && _cmdNo2RobotReplyCount[cmdNo].count(sendID) > 0)
                _cmdNo2RobotReplyCount[cmdNo][sendID]--;
            cmdNoWriteLock.unlock();

            std::string swarmName = gActorTagStore.swarmTag2Name(aCmd.param2());
            std::string sendActorName = gActorTagStore.actorTag2Name(aCmd.param3());
            std::string actorName = gActorTagStore.actorTag2Name(aCmd.param4());
            if (aCmd.param5() == 1){//  param3==1 means allowed
                switch (aCmd.param1()) {
                    case REQUEST_ACTOR_TYPE_ACTIVATE:
                        _pActorScheduler->activateActor(swarmName, actorName); 
                        ROS_INFO("[SwarmMasterCmd] recvRequestActor answer, master allowd activate actor [%s].", actorName.c_str());
                        break;
                    case REQUEST_ACTOR_TYPE_SWITCH:
                        _pActorScheduler->pauseActor(swarmName, sendActorName);
                        _pActorScheduler->activateActor(swarmName, actorName); 
                        ROS_INFO("[SwarmMasterCmd] recvRequestActor answer, master allowd switch to actor [%s].", actorName.c_str());
                        break;
                    default:
                        break;
                }                
            }else{
                ROS_INFO("[SwarmMasterCmd] recvRequestActor answer, master denied actor [%s].", actorName.c_str());
            }
            return;
        } else if (aCmd.type() == CMD_TYPE_BARRIER_RESPONSE){
            ROS_WARN("receive barrier response:key=%d,ret=%d",aCmd.param4(),aCmd.param5());
            GlobalBarrierKey barrierKey(
                // gActorTagStore.swarmTag2Name(aCmd.param1()),
                // gActorTagStore.actorTag2Name(aCmd.param2()),
                // gActorTagStore.pluginTag2Name(aCmd.param3()),
                aCmd.param4());
            if(aCmd.param5() == BarrierResult::YES || aCmd.param5() == BarrierResult::OPTIONALYES) {
                boost::unique_lock<boost::shared_mutex> rlock(_barrierKey2ConditionAndResultMutex);
                if(_barrierKey2ConditionAndResult.count(barrierKey) != 0){
                    _barrierKey2ConditionAndResult[barrierKey].second = (BarrierResult)aCmd.param5();
                    _barrierKey2ConditionAndResult[barrierKey].first->notify_one();  
                }
            }
            //reply to sender
            MasterCmd replyMsg;
            replyMsg.cmdNo(cmdNo);
            replyMsg.type(CMD_TYPE_REPLY);
            replyMsg.sendID(_robotID);
            replyMsg.receID(sendID);
            boost::unique_lock<boost::mutex> pubCmdLock(_pubMutex);
            _pPubMasterCmd->publish(replyMsg);
            pubCmdLock.unlock();
            return;
        }

        // master cmd sent by master actively
        //new cmd or broadcast data RECE_ID_ALL_MEMBER
        if ((_robotID2ReceivedCmdNo.count(sendID) == 0) || (_robotID2ReceivedCmdNo[sendID] < cmdNo) ||(receID == RECE_ID_ALL_MEMBER)) {
            if(receID != RECE_ID_ALL_MEMBER) _robotID2ReceivedCmdNo[sendID] = cmdNo;
            if (aCmd.param1() > 127 || aCmd.param2() > 127 || aCmd.param3() > 127 || aCmd.param4() > 127 || aCmd.param5() > 127){
                ROS_ERROR("[SwarmMasterCmd] receive a master cmd type [%d] with invalid params, return", aCmd.type());
                ROS_ERROR("data:%d,%d,%d,%d,%d", aCmd.param1(), aCmd.param2(), aCmd.param3(), aCmd.param4(), aCmd.param5());
                return; 
            }
        
            std::string swarmName = "", actorName = "", actorName1 = "", formationType = "", formationPosStr = "";
            int32_t formationPos = -1, targetID = -1;
            switch (aCmd.type()) {
            case CMD_TYPE_ACTIVATE_ACTOR:
                swarmName = gActorTagStore.swarmTag2Name(aCmd.param1());
                actorName = gActorTagStore.actorTag2Name(aCmd.param2());
                _pActorScheduler->activateActor(swarmName, actorName);
                break;

            case CMD_TYPE_YIELD_ACTOR:
                swarmName = gActorTagStore.swarmTag2Name(aCmd.param1());
                actorName = gActorTagStore.actorTag2Name(aCmd.param2());
                _pActorScheduler->pauseActor(swarmName, actorName);
                break;

            case CMD_TYPE_SWITCH_ACTOR:
                swarmName = gActorTagStore.swarmTag2Name(aCmd.param1());
                actorName = gActorTagStore.actorTag2Name(aCmd.param2());
                actorName1 = gActorTagStore.actorTag2Name(aCmd.param3());
                _pActorScheduler->pauseActor(swarmName, actorName);
                _pActorScheduler->activateActor(swarmName, actorName1);
                break;

            case CMD_TYPE_SET_FORMATION: //not used currently, replaced by CMD_TYPE_SET_SAVE_FORMATION
                break;
            case CMD_TYPE_GET_FORMATION:
                break;
            case CMD_TYPE_SET_SAVE_FORMATION:
                swarmName = gActorTagStore.swarmTag2Name(aCmd.param1());
                actorName = gActorTagStore.actorTag2Name(aCmd.param2());
                formationType = std::to_string(aCmd.param3());
                formationPos = aCmd.param4();
                targetID = aCmd.param5();
                SwarmDataStorage::instance()->setRobotPos(targetID, formationPos,swarmName,actorName,formationType);
                if (targetID == _robotID)
                    _pActorScheduler->setFormation(swarmName, actorName, formationType, std::to_string(formationPos));
                break;

            case CMD_TYPE_SET_FORMATION_SWITCH:
                swarmName = gActorTagStore.swarmTag2Name(aCmd.param1());
                actorName = gActorTagStore.actorTag2Name(aCmd.param2());
                actorName1 = gActorTagStore.actorTag2Name(aCmd.param5());
                formationType = std::to_string(aCmd.param3());
                formationPosStr = std::to_string(aCmd.param4());
                _pActorScheduler->setFormation(swarmName, actorName, formationType, formationPosStr);
                //switch actor
                _pActorScheduler->pauseActor(swarmName, actorName1);
                _pActorScheduler->activateActor(swarmName, actorName);
                //may not need,SwarmDataStorage::instance()->setRobotPos(_robotID), formationPos);
                break;

            case CMD_TYPE_SWITCH_MASTER:
                SwarmDataStorage::instance()->setLocalRobotState(KEEPING);
                ROS_INFO("[SwarmMasterCmd] recvIamMasterCmd, newMasterID is localMasterID, oldMasterID is [%d]", aCmd.param1());
                break; 
            // case CMD_TYPE_BARRIER_RESPONSE:{
            //     ROS_WARN("receive barrier response:%d,%d",aCmd.param2(),aCmd.param4());
            //     GlobalBarrierKey barrierKey(
            //         // gActorTagStore.swarmTag2Name(aCmd.param1()),
            //         // gActorTagStore.actorTag2Name(aCmd.param2()),
            //         // gActorTagStore.pluginTag2Name(aCmd.param3()),
            //         aCmd.param4());
            //     if(aCmd.param5() == BarrierResult::YES || aCmd.param5() == BarrierResult::OPTIONALYES) {
            //         boost::unique_lock<boost::shared_mutex> rlock(_barrierKey2ConditionAndResultMutex);
            //         if(_barrierKey2ConditionAndResult.count(barrierKey) != 0){
            //             _barrierKey2ConditionAndResult[barrierKey].second = (BarrierResult)aCmd.param5();
            //             _barrierKey2ConditionAndResult[barrierKey].first->notify_one();  
            //         }
            //     }
            // }

            // break;
            default:
                break;
            }
        }

        //reply to sender
        MasterCmd replyMsg;
        replyMsg.cmdNo(cmdNo);
        replyMsg.type(CMD_TYPE_REPLY);
        replyMsg.sendID(_robotID);
        replyMsg.receID(sendID);
        boost::unique_lock<boost::mutex> pubCmdLock(_pubMutex);
        _pPubMasterCmd->publish(replyMsg);
        pubCmdLock.unlock();

        //log to file
        #ifdef ACTOR_SWARM_LOG_OUT
            logStr.clear();
            logStr = "sendcmdCmdReply";
            logStr.append(std::to_string(_robotID)).append("-->").append(std::to_string(sendID))
            .append(" cmdNo:").append(std::to_string(cmdNo))
            .append(" cmdType:").append(std::to_string(replyMsg.type()));
            SwarmDataStorage::instance()->logOut2File("event", logStr);
        #endif

    } else if(masterID == _robotID){ // sender is not master
        switch(aCmd.type()){
            case CMD_TYPE_REQUEST_ACTOR:{
                std::string swarmName = gActorTagStore.swarmTag2Name(aCmd.param2());
                std::string sendActorName = gActorTagStore.actorTag2Name(aCmd.param3());
                std::string actorName = gActorTagStore.actorTag2Name(aCmd.param4());
                int requestResult = handleSwarmActorRequest(sendID,aCmd.param1(), swarmName, sendActorName,actorName);

                //answer to member
                MasterCmd answerMsg(aCmd);
                answerMsg.type(CMD_TYPE_REQUEST_ACTOR_RSP);
                answerMsg.sendID(_robotID);
                answerMsg.receID(sendID);
                answerMsg.param5(requestResult);

                boost::unique_lock<boost::mutex> pubCmdLock(_pubMutex);
                _pPubMasterCmd->publish(answerMsg);
                pubCmdLock.unlock();
                ROS_INFO("[SwarmMasterCmd] recvRequestActor request,robot[%d] need actor[%s],result:%d.", sendID, actorName.c_str(), answerMsg.param5());

                #ifdef ACTOR_SWARM_LOG_OUT
                    std::string logStr = "answerActorRequest";
                    logStr.append(std::to_string(_robotID)).append("-->").append(std::to_string(sendID))
                    .append(" cmdNo:").append(std::to_string(cmdNo))
                    .append(" cmdType:").append(std::to_string(answerMsg.param1()))
                    .append(" requestResult:").append(std::to_string(answerMsg.param5()));
                    SwarmDataStorage::instance()->logOut2File("event", logStr);
                #endif 
            }
            break;
            case CMD_TYPE_BARRIER_REQUEST: {
                ROS_WARN("[SwarmMasterCmd] receive barrier request from [%d],key=%d", sendID, aCmd.param4());
                GlobalBarrierKey barrierKey(
                    // gActorTagStore.swarmTag2Name(aCmd.param1()),
                    // gActorTagStore.actorTag2Name(aCmd.param2()),
                    // gActorTagStore.pluginTag2Name(aCmd.param3()),
                    aCmd.param4());
                handleBarrierRequest(barrierKey, aCmd.param5(), sendID);
            }
            break;
            default: break;
        }

        if(aCmd.type() == CMD_TYPE_REQUEST_ACTOR || aCmd.type() == CMD_TYPE_BARRIER_REQUEST){
            //reply to sender
            MasterCmd replyMsg;
            replyMsg.cmdNo(cmdNo);
            replyMsg.type(CMD_TYPE_REPLY);
            replyMsg.sendID(_robotID);
            replyMsg.receID(sendID);
            boost::unique_lock<boost::mutex> pubCmdLock(_pubMutex);
            _pPubMasterCmd->publish(replyMsg);
            pubCmdLock.unlock();

                //log to file
            #ifdef ACTOR_SWARM_LOG_OUT
                logStr.clear();
                logStr = "sendcmdCmdReply";
                logStr.append(std::to_string(_robotID)).append("-->").append(std::to_string(sendID))
                .append(" cmdNo:").append(std::to_string(cmdNo))
                .append(" cmdType:").append(std::to_string(replyMsg.type()));
                SwarmDataStorage::instance()->logOut2File("event", logStr);
            #endif
        }
    }
}

// clear from _robotID2TimeoutMsg by robotID
void SwarmMasterCmd::clearMasterCmdsForRobot(const int32_t aRobotID){
    ROS_INFO("[SwarmMasterCmd] clearMasterCmdsForRobot [%d]", aRobotID);

    boost::unique_lock<boost::shared_mutex> wlock(_robotID2TimeoutMsgMutex);
    if(_robotID2TimeoutMsg.count(aRobotID)>0) {
        for(std::map<int, MasterCmd*>::iterator it = _robotID2TimeoutMsg[aRobotID].begin(); it != _robotID2TimeoutMsg[aRobotID].end(); it++){
            delete it->second;
            it->second = NULL;
        }
        _robotID2TimeoutMsg.erase(aRobotID);
    }
    wlock.unlock();

    boost::unique_lock<boost::shared_mutex> cmdNoWriteLock(_cmdNo2RobotReplyCountMutex);
    for(std::map<int32_t,std::map<int32_t,int32_t> >::iterator it=_cmdNo2RobotReplyCount.begin();it!=_cmdNo2RobotReplyCount.end();){
        if(it->second.count(aRobotID)>0) it->second.erase(aRobotID);
        if(it->second.empty()) it = _cmdNo2RobotReplyCount.erase(it);
        else it++;    
    } 
}

// clear _robotID2TimeoutMsg
void SwarmMasterCmd::clearAllMasterCmds(){
    ROS_INFO("[SwarmMasterCmd] clearAllMasterCmds");
    {
        boost::unique_lock<boost::shared_mutex> wlock(_robotID2TimeoutMsgMutex);
        for(std::map<int, std::map<int, MasterCmd*> >::iterator it = _robotID2TimeoutMsg.begin(); it != _robotID2TimeoutMsg.end(); it++){
            for(std::map<int, MasterCmd*>::iterator it2 = it->second.begin(); it2 != it->second.end(); it2++){
                delete it2->second;
                it2->second = NULL;
            }
        }
        _robotID2TimeoutMsg.clear(); // or swap
    }

    {
        boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2BarrierRequestListMutex);
        _barrierKey2BarrierRequestList.clear();// the master should not response to barrier request
    }
    
    {
        boost::unique_lock<boost::shared_mutex> wlock(_barrierKey2ConditionAndResultMutex);
        _barrierKey2ConditionAndResult.clear();
    }
}

// resend master cmd until recv reply
void SwarmMasterCmd::resendTimeoutMasterCmdLoop(){
    ROS_INFO("[SwarmMasterCmd] start resendTimeoutMasterCmdLoop");
    while(1){
        resendTimeoutMasterCmd();
        usleep((3*RESEND_DURATION_CMD_RTPS+rand()%50)*1000);
    }
}

void SwarmMasterCmd::resendTimeoutMasterCmd(){
    boost::unique_lock<boost::shared_mutex> wlock(_robotID2TimeoutMsgMutex);
    if(!_robotID2TimeoutMsg.empty()){
        // send the front master cmd
        for(std::map<int,std::map<int, MasterCmd*> >::iterator it = _robotID2TimeoutMsg.begin();it!=_robotID2TimeoutMsg.end();it++){
            if(it->second.empty()) continue;
            if(sendMasterCmdAndGetReply(it->second.begin()->second)){
                //ROS_INFO("[SwarmMasterCmd] resendTimeoutMasterCmd to receID [%d], cmdNo=%d replyed", it->first,it->second.begin()->first);
                delete it->second.begin()->second;
                it->second.erase(it->second.begin());
            } else {
                //ROS_INFO("[SwarmMasterCmd] resendTimeoutMasterCmd to receID [%d], cmdNo=%d no replyed", it->first,it->second.begin()->first);
            }
        }
    }
}