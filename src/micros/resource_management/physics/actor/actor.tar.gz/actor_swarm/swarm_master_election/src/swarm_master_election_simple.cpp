#include "swarm_master_election/swarm_master_election_simple.h"
#include "swarm_data_storage/swarm_data_storage.h"

SwarmMasterElectionSimple::SwarmMasterElectionSimple(){

}

SwarmMasterElectionSimple::~SwarmMasterElectionSimple(){

}


// choose min robotID in this group as masterID
int SwarmMasterElectionSimple::electMasterID(){
    std::vector<int> robotIDs;
    SwarmDataStorage::instance()->getRobotIDs(robotIDs);
    if(!robotIDs.empty()) {
        int minRobotID = *std::min_element(std::begin(robotIDs), std::end(robotIDs));
        SwarmDataStorage::instance()->setMasterID(minRobotID);
    }
}

