#ifndef __SWARM_MASTER_ELECTION_H__
#define __SWARM_MASTER_ELECTION_H__

//elect master base class
class SwarmMasterElection{
public:
    SwarmMasterElection(){};
    virtual ~SwarmMasterElection(){};
};
#endif
