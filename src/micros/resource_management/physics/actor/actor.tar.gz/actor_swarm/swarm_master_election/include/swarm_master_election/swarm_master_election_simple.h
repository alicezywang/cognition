#ifndef __SWARM_MASTER_ELECTION_SIMPLE_H__
#define __SWARM_MASTER_ELECTION_SIMPLE_H__

#include "swarm_master_election.h"
//#include "micros_swarm/micros_swarm.h"
//elect master in the group given group members
class SwarmMasterElectionSimple : public SwarmMasterElection{
public:
    SwarmMasterElectionSimple();
    virtual ~SwarmMasterElectionSimple();
    // this method will generate materid immediately
    int electMasterID();
};
#endif
