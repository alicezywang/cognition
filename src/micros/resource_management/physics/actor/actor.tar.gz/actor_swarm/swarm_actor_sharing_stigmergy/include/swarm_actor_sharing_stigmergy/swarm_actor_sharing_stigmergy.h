#ifndef __SWARM_ACTOR_SHARING_STIGMERGY_H__
#define __SWARM_ACTOR_SHARING_STIGMERGY_H__

#include "std_msgs/Int8.h"
#include "micros_swarm/micros_swarm.h"
#include "actor_schedule/actor_schedule.h"
//robot actors info sharing through stigmergy
class SwarmActorSharingStigmergy{
public:
    SwarmActorSharingStigmergy(boost::shared_ptr<ActorScheduler> pScheduler);
    ~SwarmActorSharingStigmergy();
    void putSwarmActors(const int32_t aNum, const int32_t aDuration);

protected:
    bool getSwarmActors(const int32_t aRobotID, std::string& anSwarmName, std::vector<std::string>& anActors);

    // if local actor changed, then save and put to stigmergy
    void updateLocalSwarmActors();
    void updateLocalSwarmActorsLoop();

    // read others' actors info from stigmergy
    void checkSwarmActors();
    void checkSwarmActorsLoop();

    std::string getCmdKey(const int32_t aRobotID);

private:
    int _robotID;

    micros_swarm::VirtualStigmergy _vs;
    boost::mutex _vsMutex;

    // map for save robot actors lamport_clock
	std::map<int32_t, int32_t> _robotID2Clock;
	boost::mutex _rcMutex;

    boost::shared_ptr<ActorScheduler> _pActorScheduler;

    // thread for put actors and check actors
	boost::shared_ptr<boost::thread> _pthCheckActors;
	boost::shared_ptr<boost::thread> _pthUpdateActors;
};
#endif