#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler.h"
#include "swarm_data_storage/swarm_data_storage.h"

SwarmRobotHeartbeatHandler::SwarmRobotHeartbeatHandler(boost::shared_ptr<ActorScheduler> pScheduler){
    _robotID = SwarmDataStorage::instance()->getLocalRobotID();
    _pMasterCmd = new SwarmMasterCmd(pScheduler);
    _pRobotActors = new SwarmActorSharingStigmergy(pScheduler);
    gSwarmMasterCmd = _pMasterCmd;
}

SwarmRobotHeartbeatHandler::~SwarmRobotHeartbeatHandler(){
    if(_pMasterCmd){
        delete _pMasterCmd;
        _pMasterCmd = NULL;
    }
    if(_pRobotActors){
        delete _pRobotActors;
        _pRobotActors = NULL;
    }
    if(gSwarmMasterCmd){
        delete gSwarmMasterCmd;
        gSwarmMasterCmd = NULL;
    }
}