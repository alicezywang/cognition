#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler_for_electionbids.h"
#include "swarm_data_storage/swarm_data_storage.h"
#include "ros/ros.h"

SwarmRobotHeartbeatHandler_ForElectionBids::SwarmRobotHeartbeatHandler_ForElectionBids(boost::shared_ptr<ActorScheduler> pScheduler)
: SwarmRobotHeartbeatHandler(pScheduler) {
    _pMasterElection = new SwarmMasterElectionBids; // will be released by base class
    _pMasterElection->init(-1, "/home/gjl/log/bid/");
    _pthCheckVotingState = boost::shared_ptr<boost::thread>(new boost::thread(boost::bind(&SwarmRobotHeartbeatHandler_ForElectionBids::checkVotingStateLoop,this)));
    _pthCheckVotingState->detach();
}

SwarmRobotHeartbeatHandler_ForElectionBids::~SwarmRobotHeartbeatHandler_ForElectionBids(){
    if(_pMasterElection){
        delete _pMasterElection;
        _pMasterElection = NULL;
    }
    if(_pthCheckVotingState){
        _pthCheckVotingState->join();
        _pthCheckVotingState->interrupt();
        _pthCheckVotingState.reset();
    }
}

void SwarmRobotHeartbeatHandler_ForElectionBids::processRobotJoinMsg(const int aJoinRobotID){
    //if already join, return
    if(SwarmDataStorage::instance()->getRobotStateByID(aJoinRobotID) == KEEPING) return;

    //add to local swarm
    SwarmDataStorage::instance()->addRobotToLocalSwarm(aJoinRobotID);

    //for master
    int32_t curMasterID = _pMasterElection->getMasterID();
    if(curMasterID == _robotID){
        //notify aJoinRobotID that i am the master to aJoinRobotID
        _pMasterCmd->sendIamMasterCmd(_robotID, aJoinRobotID);

        //if a swarm task is running, reassign formation pos
        //condition is temporary, may need to judge running actors and other states
        std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
        if(!swarmName.empty()) {
            _pMasterCmd->addRobotToFormation(aJoinRobotID);
            _pMasterCmd->reassignFormation();
            SwarmDataStorage::instance()->printInformation();
        }

        //send swarm info to member new joined, called after reassign because reassign may change the formation pos info
        _pMasterCmd->sendInfo2RobotNewJoin(aJoinRobotID);  
    }

    // notify local actors to swarm stigmergy
    std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    if(!swarmName.empty())
        _pRobotActors->putSwarmActors(1, 10);//put swarm actors on stigmergy '1' time in every '10' ms, '10' makes on sense if the first param is '1'
}

void SwarmRobotHeartbeatHandler_ForElectionBids::processRobotLeaveMsg(const int aLeaveRobotID){
    //if already leave, return
    if(SwarmDataStorage::instance()->getRobotStateByID(aLeaveRobotID) == LEAVE) return;

    //remove from swarm, set formation pos to INVALID
    SwarmDataStorage::instance()->removeRobotFromLocalSwarm(aLeaveRobotID);

    //when robot leave, clear cmd msg sent to it
    _pMasterCmd->clearMasterCmdsForRobot(aLeaveRobotID);
    
    // if master leave,then elect master
    int oldMasterID = SwarmDataStorage::instance()->getMasterID();
    if(aLeaveRobotID == oldMasterID) {
        // elect master
        _pMasterElection->activateMasterVote();
        ROS_INFO("[SwarmRobotHeartbeatHandler_ForElectionBids] after [%d] leave, revote new master", aLeaveRobotID);
    }
}


void SwarmRobotHeartbeatHandler_ForElectionBids::checkVotingStateLoop(){
    while(1){
        int oldMasterID = SwarmDataStorage::instance()->getMasterID();

        boost::unique_lock<boost::mutex> lock(_mutex);
        _pMasterElection->getVoteCompletedCond().wait(lock);
        if(SwarmDataStorage::instance()->getMasterID() == _robotID
        && SwarmDataStorage::instance()->getLocalRobotState() == KEEPING){
            _pMasterCmd->sendIamMasterCmd(oldMasterID, RECE_ID_ALL_MEMBER);
            _pMasterCmd->reassignFormation();
        }
        
    }
}