#ifndef __SWARM_ROBOT_HEARTBEAT_HANDLER_H__
#define __SWARM_ROBOT_HEARTBEAT_HANDLER_H__
#include "swarm_master_cmd/swarm_master_cmd.h"
#include "swarm_actor_sharing_stigmergy/swarm_actor_sharing_stigmergy.h"
#include "actor_schedule/actor_schedule.h"
// base class for handle the robot join/leave msg
class SwarmRobotHeartbeatHandler{
public:
    SwarmRobotHeartbeatHandler(boost::shared_ptr<ActorScheduler> pScheduler);
    ~SwarmRobotHeartbeatHandler();
    virtual void processRobotJoinMsg(const int aJoinRobotID) = 0;
    virtual void processRobotLeaveMsg(const int aLeaveRobotID) = 0;

protected:
    int _robotID; // local robotID
    SwarmMasterCmd* _pMasterCmd;//pointer to master command
    SwarmActorSharingStigmergy* _pRobotActors;
};
#endif
