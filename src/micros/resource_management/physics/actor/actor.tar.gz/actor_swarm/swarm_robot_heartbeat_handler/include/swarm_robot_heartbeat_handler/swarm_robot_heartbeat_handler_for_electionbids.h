#ifndef __SWARM_ROBOT_HEARTBEAT_HANDLER_FOR_ELECTIONBIDS_H__
#define __SWARM_ROBOT_HEARTBEAT_HANDLER_FOR_ELECTIONBIDS_H__

#include "swarm_robot_heartbeat_handler.h"
#include "swarm_master_election/swarm_master_election_bids.h"

//handle the robot join/leave msg
class SwarmRobotHeartbeatHandler_ForElectionBids : public SwarmRobotHeartbeatHandler{
public:
    SwarmRobotHeartbeatHandler_ForElectionBids(boost::shared_ptr<ActorScheduler> pScheduler);
    ~SwarmRobotHeartbeatHandler_ForElectionBids();
    virtual void processRobotJoinMsg(const int aJoinRobotID);
    virtual void processRobotLeaveMsg(const int aLeaveRobotID);

private:
    void checkVotingStateLoop();

private:
    boost::mutex _mutex;
    SwarmMasterElectionBids* _pMasterElection;//pointer to master election 
    boost::shared_ptr<boost::thread> _pthCheckVotingState;
};
#endif
