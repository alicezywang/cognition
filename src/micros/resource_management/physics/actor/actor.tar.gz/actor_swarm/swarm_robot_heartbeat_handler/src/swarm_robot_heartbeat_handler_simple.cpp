#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler_simple.h"
#include "swarm_data_storage/swarm_data_storage.h"
#include "ros/ros.h"

SwarmRobotHeartbeatHandlerSimple::SwarmRobotHeartbeatHandlerSimple(boost::shared_ptr<ActorScheduler> pScheduler)
: SwarmRobotHeartbeatHandler(pScheduler){
    _pMasterElection = new SwarmMasterElectionSimple; // will be released by base class
}

SwarmRobotHeartbeatHandlerSimple::~SwarmRobotHeartbeatHandlerSimple(){
    if(_pMasterElection){
        delete _pMasterElection;
        _pMasterElection = NULL;
    }
}

void SwarmRobotHeartbeatHandlerSimple::processRobotJoinMsg(const int aJoinRobotID){
    //if already join, return
    if(SwarmDataStorage::instance()->getRobotStateByID(aJoinRobotID) == KEEPING) return;

    //add to local swarm
    SwarmDataStorage::instance()->addRobotToLocalSwarm(aJoinRobotID);

    // reset local masterID,because aJoinRobotID maybe the min ID
    int oldMasterID = SwarmDataStorage::instance()->getMasterID();
    _pMasterElection->electMasterID();
    int newMasterID = SwarmDataStorage::instance()->getMasterID();
    ROS_INFO("[SwarmRobotHeartbeatHandlerSimple] after [%d] join, current master is [%d]", aJoinRobotID, newMasterID);
    
    // set robot state, waiting for master switch
    //CAUTION: may never satisfy for a master under current master election rule, and is only useful for members
    if(newMasterID != oldMasterID){
        SwarmDataStorage::instance()->setLocalRobotState(VOTING);
        //if master changes, clear the cmd msg to it
        _pMasterCmd->clearMasterCmdsForRobot(oldMasterID);
    }

    //for master
    if(newMasterID == _robotID){
        //CAUTION: destMasterID would always be aJoinRobotID under current master election rule
        int destMasterID = newMasterID == oldMasterID ? aJoinRobotID : RECE_ID_ALL_MEMBER;
        //declare i am the master
        processSwitchMaster(oldMasterID, destMasterID);
        
        //if a swarm task is running, reassign formation pos
        //condition is temporary, may need to judge running actors and other states
        // std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
        // if(!swarmName.empty()) {
        //     _pMasterCmd->addRobotToFormation(aJoinRobotID);
        //     _pMasterCmd->reassignFormation();
        //     SwarmDataStorage::instance()->printInformation();
        // }

        //send swarm info to member new joined, called after reassign because reassign may change the formation pos info
        //_pMasterCmd->sendInfo2RobotNewJoin(aJoinRobotID);
            
    } else { //for members
        // when master changed to common member, clearAllMasterCmds
        if(oldMasterID == _robotID){  
            _pMasterCmd->clearAllMasterCmds();
        }
    }

    // notify local actors to swarm stigmergy
    std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    if(!swarmName.empty())
        _pRobotActors->putSwarmActors(1, 10);//put swarm actors on stigmergy '1' time in every '10' ms, '10' makes on sense if the first param is '1'
}

void SwarmRobotHeartbeatHandlerSimple::processRobotLeaveMsg(const int aLeaveRobotID){
    //if already leave, return
    if(SwarmDataStorage::instance()->getRobotStateByID(aLeaveRobotID) == LEAVE) return;

    //remove from swarm, set formation pos to INVALID
    SwarmDataStorage::instance()->removeRobotFromLocalSwarm(aLeaveRobotID);

    //when robot leave, clear cmd msg sent to it
    _pMasterCmd->clearMasterCmdsForRobot(aLeaveRobotID);
    
    // if master leave,then elect master
    int oldMasterID = SwarmDataStorage::instance()->getMasterID();
    if(aLeaveRobotID == oldMasterID) {
        // elect master
        _pMasterElection->electMasterID();
        int newMasterID = SwarmDataStorage::instance()->getMasterID();
        ROS_INFO("[SwarmRobotHeartbeatHandlerSimple] after [%d] leave, current master is [%d]", aLeaveRobotID, newMasterID);
        
        // notify all members "i'm the master"
        if (newMasterID == _robotID )
            processSwitchMaster(oldMasterID, RECE_ID_ALL_MEMBER);
        
    }
    
    // if local robot is master 
    // int masterID = SwarmDataStorage::instance()->getMasterID();
    // if(masterID == _robotID) { 
    //     //if a swarm task is running, reassign formation pos
    //     //condition is temporary, may need to judge running actors and other states
    //     std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    //     if(!swarmName.empty()){
    //         _pMasterCmd->reassignFormation();
    //         SwarmDataStorage::instance()->printInformation();
    //     }
    // }
    
}

//deprecated
void SwarmRobotHeartbeatHandlerSimple::processRobotJoinForMaster(const int anOldMasterID, const int aDestMasterID, const int aJoinRobotID){
    //set robot state, wait for members to reply
    SwarmDataStorage::instance()->setLocalRobotState(VOTING);
    // notify dest members
    _pMasterCmd->sendIamMasterCmd(anOldMasterID, aDestMasterID);

    //TODO: may need to change state to keeping when receive all reply msgs
    SwarmDataStorage::instance()->setLocalRobotState(KEEPING);

    //send swarm info to member new joined
    _pMasterCmd->sendInfo2RobotNewJoin(aJoinRobotID);
    
    //if a swarm task is running, reassign formation pos
    //condition is temporary, may need to judge running actors and other states
    // std::string swarmName = SwarmDataStorage::instance()->getSwarmNameByID(_robotID);
    // if(!swarmName.empty()) {
    //     _pMasterCmd->addRobotToFormation(aJoinRobotID);
    //     _pMasterCmd->reassignFormation();
    //     SwarmDataStorage::instance()->printInformation();
    // }
}

void SwarmRobotHeartbeatHandlerSimple::processSwitchMaster(const int anOldMasterID, const int aDestMasterID){
    //set robot state, wait for members to reply
    SwarmDataStorage::instance()->setLocalRobotState(VOTING);
    // notify dest members
    _pMasterCmd->sendIamMasterCmd(anOldMasterID, aDestMasterID);

    //TODO: may need to change state to keeping when receive all reply msgs
    SwarmDataStorage::instance()->setLocalRobotState(KEEPING);

}