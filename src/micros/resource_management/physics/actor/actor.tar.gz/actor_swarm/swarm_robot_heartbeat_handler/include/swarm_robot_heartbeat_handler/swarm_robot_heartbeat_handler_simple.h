#ifndef __SWARM_ROBOT_HEARTBEAT_HANDLER_SIMPLE_H__
#define __SWARM_ROBOT_HEARTBEAT_HANDLER_SIMPLE_H__

#include "swarm_robot_heartbeat_handler.h"
#include "swarm_master_election/swarm_master_election_simple.h"

//handle the robot join/leave msg
class SwarmRobotHeartbeatHandlerSimple : public SwarmRobotHeartbeatHandler{
public:
    SwarmRobotHeartbeatHandlerSimple(boost::shared_ptr<ActorScheduler> pScheduler);
    ~SwarmRobotHeartbeatHandlerSimple();
    virtual void processRobotJoinMsg(const int aJoinRobotID);
    virtual void processRobotLeaveMsg(const int aLeaveRobotID);

private:
    //deprecated
    void processRobotJoinForMaster(const int anOldMasterID, const int aDestMasterID,const int aJoinRobotID);
    //called by the new master when master changes
    void processSwitchMaster(const int anOldMasterID, const int aDestMasterID);

private:
    SwarmMasterElectionSimple* _pMasterElection;//pointer to master election 
};
#endif
