#ifndef __TEST_QUEUE_PUB_PLUGIN__
#define __TEST_QUEUE_PUB_PLUGIN__

#include "general_plugin/general_plugin.h"
#include <ros/single_subscriber_publisher.h>
namespace general_bus {
	class TestQueuePubPlugin: public GeneralPlugin {	
	public:
		void connectCallback(const ros::SingleSubscriberPublisher& pub);
void disconnectCallback(const ros::SingleSubscriberPublisher& pub);
		virtual void start();
	};
}
#endif
