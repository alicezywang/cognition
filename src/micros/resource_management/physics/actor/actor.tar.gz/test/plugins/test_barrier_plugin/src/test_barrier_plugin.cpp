#include "test_barrier_plugin/test_barrier_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "std_msgs/Empty.h"
#include "ros/ros.h"
#include "general_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::TestBarrierPlugin,general_bus::GeneralPlugin)

namespace general_bus {
	void TestBarrierPlugin::start(){
		GOON_OR_RETURN;

        std::string actorName = "";
    //getActorName(_actorID, actorName);
		ROS_INFO("[TestBarrierPlugin] start in actor:%s", actorName.c_str());

        int endt = rand()%3+20;
        int i = 0;
        while(i<endt){
            ROS_INFO("[TestBarrierPlugin] %s %d/%d", actorName.c_str(), i, endt);
            sleep(1);
            i++;
        }

        ROS_INFO("[TestBarrierPlugin] %s start barrier 1...", actorName.c_str());
        GlobalBarrierKey barrierKey(
            actorName,
            "test_barrier_plugin",
            1
        );
        BarrierResult ret = pluginBarrierApi(barrierKey, 3, 10);
        ROS_INFO("[TestBarrierPlugin] %s barrier 1 result:%d", actorName.c_str(), ret);
        
        if(ret == YES){
            i = 0;
            while(i<endt){
                ROS_INFO("[TestBarrierPlugin] %s %d/%d", actorName.c_str(), i, endt);
                sleep(1);
                i++;
            }
            ROS_INFO("[TestBarrierPlugin] %s start barrier 2...", actorName.c_str());
            GlobalBarrierKey barrierKey2(
                actorName,
                "test_barrier_plugin",
                2
            );
            ret = pluginBarrierApi(barrierKey2, 3, 3);
            ROS_INFO("[TestBarrierPlugin] %s barrier 2 result:%d", actorName.c_str(), ret);
        }
    }
}    
