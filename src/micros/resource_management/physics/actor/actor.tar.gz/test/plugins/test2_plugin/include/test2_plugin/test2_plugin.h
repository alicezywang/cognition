#ifndef __TEST2_PLUGIN__
#define __TEST2_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "std_msgs/String.h"

namespace general_bus {

class Test2Plugin: public GeneralPlugin {	

public:

    virtual void start();
    
    /* For Test */
    std::string _actorName;
    // ROS msg publish
    // ros::Publisher _pub;
    // ROS msg subscribe callback
    // void callback(const std_msgs::String::ConstPtr& msg);

};

}

#endif
