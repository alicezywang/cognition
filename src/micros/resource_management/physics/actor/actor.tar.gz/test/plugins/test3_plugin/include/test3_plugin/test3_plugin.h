#ifndef __TEST3_PLUGIN__
#define __TEST3_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "actor_msgs/UTOEvent.h"
#include "actor_msgs/UtoActorParams.h"

namespace general_bus {
	class Test3Plugin: public GeneralPlugin {	
	public:
		virtual void start();
		// void callback(const actor_msgs::UtoActorParamsConstPtr& msg);
		std::string _actorName;
	};
}
#endif
