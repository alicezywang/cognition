#include "test_queue_pub_plugin/test_queue_pub_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
#include "std_msgs/String.h"
//#include "test3_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::TestQueuePubPlugin,general_bus::GeneralPlugin)

namespace general_bus {
	void TestQueuePubPlugin::connectCallback(const ros::SingleSubscriberPublisher& pub){
			ROS_INFO("[PubPlugin] connect from %s", pub.getSubscriberName().c_str());
	}

	void TestQueuePubPlugin::disconnectCallback(const ros::SingleSubscriberPublisher& pub){
		ROS_INFO("[PubPlugin] disconnect from %s", pub.getSubscriberName().c_str());
	}

	void TestQueuePubPlugin::start(){
		GOON_OR_RETURN;
		
		std::string actorName;
    //getActorName(_actorID,actorName);
		ROS_INFO("[PubPlugin] %s start", actorName.c_str());

		// ros create pub, this is depecated.
		/*ros::NodeHandle n;
		ros::Publisher chatter_pub = n.advertise<std_msgs::String>("/chatter", 1000,
		 boost::bind(&TestQueuePubPlugin::connectCallback, this, _1),
		 boost::bind(&TestQueuePubPlugin::disconnectCallback, this, _1)
		);*/

		// user create ros publisher, test the method in general_plugin
		ros::Publisher chatter_pub = pluginAdvertise<std_msgs::String>("/chatter", 1000);

		ros::Rate loop_rate(1);
		int count = 0;
  		while (ros::ok()){
			GOON_OR_RETURN;
			std_msgs::String msg;

    		std::stringstream ss;
    		ss << "Pushlish: " << count;
    		msg.data = ss.str();
    
    		ROS_INFO("[PubPlugin]subNum%d, %s", chatter_pub.getNumSubscribers(), msg.data.c_str());
			chatter_pub.publish(msg);

    		//ros::spinOnce();

    		loop_rate.sleep();
    		++count;
			if(count >=100)sleep(20);
		}

		GeneralPlugin::start();
	}

};
