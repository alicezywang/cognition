#ifndef __EXAMPLE1_PLUGIN__
#define __EXAMPLE1_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"
#include "UTOEventTransition.h"

namespace general_bus {
	class Example1Plugin: public GeneralPlugin {	
	public:
		Example1Plugin();
		~Example1Plugin();
		void start();
		//test s
		int i;
		int test();
		// RTPSPublisher<UTOEventTransition> *_pub;
		RTPSSubscriber<UTOEventTransition> *_sub;
		void eventTransitionCallback(UTOEventTransition &msg);
	};
}
#endif
