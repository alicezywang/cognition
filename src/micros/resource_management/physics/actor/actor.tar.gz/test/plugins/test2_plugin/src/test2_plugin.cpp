#include "test2_plugin/test2_plugin.h"
#include <pluginlib/class_list_macros.h>

PLUGINLIB_EXPORT_CLASS(general_bus::Test2Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	/* For Test */
	// void Test2Plugin::callback(const std_msgs::String::ConstPtr& msg){
	// 	ROS_INFO("[Test2Plugin] heard: %s", msg->data.c_str());
	// }

	void Test2Plugin::start(){

		// Get param which is defined in UTO xml
		// Method param is key, return value
		std::string locationValue = getParam("location");
		
		/* For Test */
		// Get actor name
    //getActorName(_actorID, _actorName);

		// Sub a topic
		// ros::Subscriber sub = pluginSubscribe("test_sub_topic", 10000, &Test2Plugin::callback, this);
		// Pub a topic
		// _pub = pluginAdvertise<std_msgs::String>("test_pub_topic", 10000);

		int i = 0;
		while(ros::ok()){
			GOON_OR_RETURN;
			if(i == 20) {
				// Call this method to pub event msgs, parameter is event name
				pubEventMsg("finish_event"); //switch to Egress actor
			}
			else if(i == 10) {
				pubEventMsg("lost_leader_event"); //switch to Scout actor
			}
			ROS_INFO("[Test2Plugin] in actorID %ld actorName %s running for %d time", _actorID, _actorName.c_str(), i++);
			usleep(100000);
		}
	}

};
