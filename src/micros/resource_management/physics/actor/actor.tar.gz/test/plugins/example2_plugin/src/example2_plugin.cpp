#include "example2_plugin/example2_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
#include "example2_plugin/example1_plugin.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Example2Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	/* bool Example2Plugin::start() {
		ROS_INFO("example2_plugin is started");
		return true;
	}
	bool Example2Plugin::pause() {
		ROS_INFO("example2_plugin is paused");
		return true;
	}
	bool Example2Plugin::stop() {
		ROS_INFO("example2_plugin is paused");
		return true;
	} */
	void Example2Plugin::start(){
		GOON_OR_RETURN;
		boost::shared_ptr<general_bus::GeneralPlugin> ptrGeneralPlugin;//= new general_bus::Example1Plugin();;
		boost::shared_ptr<general_bus::Example1Plugin> ptrExample1;// = new general_bus::Example1Plugin();
		std::string tempStr = "example1_plugin";
		if(getActorPlugin(_actorID,tempStr,ptrGeneralPlugin)){

			ptrExample1 = boost::dynamic_pointer_cast<general_bus::Example1Plugin>(ptrGeneralPlugin); 
			for(int i=0;i<10;i++) {
					//goon();
					GOON_OR_RETURN;
					ROS_INFO("[Example2 Plugin]in actorID: %ld is running for %d time",_actorID,i+1);
					int j = ptrExample1->test();
					ROS_INFO("[Example2 Plugin]example1 plugin is running %d time",j);
					sleep(2*_duration);
					
				}
		}else{

			;
		}
		terminate();
	}

};
