#include "test_rt_plugin/test_rt_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
//#include "test3_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::TestRTPlugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	void TestRTPlugin::start(){
		GOON_OR_RETURN;
		std::string tempStr="";
    //getActorName(_actorID,tempStr);
		for(int i=0;i<10;i++) {
				GOON_OR_RETURN;
				ROS_INFO("[Test RealTime Plugin]in actorID: %lld in actorName: %s is running on thread %lu cpu %d for %d time",_actorID,tempStr.c_str(),pthread_self(), sched_getcpu(), i+1);
				sleep(_duration);
			}
		//switch
		//std::string swtichStr = "Transmitter1";
		//switchToActor(_actorID,swtichStr);

		GeneralPlugin::start();
	}

};
