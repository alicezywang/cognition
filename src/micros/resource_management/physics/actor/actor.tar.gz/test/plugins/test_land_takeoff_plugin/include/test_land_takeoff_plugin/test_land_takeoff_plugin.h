#ifndef __TEST_LAND_TAKEOFF_PLUGIN__
#define __TEST_LAND_TAKEOFF_PLUGIN__

#include "general_plugin/general_plugin.h"
namespace general_bus {
	class TestLandTackoffPlugin: public GeneralPlugin {	
	public:
		virtual void start();
	};
}
#endif
