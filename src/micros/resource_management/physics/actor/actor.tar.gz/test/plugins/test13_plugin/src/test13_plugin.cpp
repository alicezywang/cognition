#include "test13_plugin/test13_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
//#include "test13_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test13Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	void Test13Plugin::start(){
		std::string swtichStr = "Follower1";
		std::string tempStr;
    //getActorName(_actorID, tempStr);
		GOON_OR_RETURN;
		int i = 0;
		while (ros::ok()) {
			i++;
			GOON_OR_RETURN;
			ROS_INFO("[Test13 Plugin]in actorID: %ld in actorName: %s is running for %d time", _actorID, tempStr.c_str(), i);
			if (i%10 == 0) {
				switchToActor(_actorID, swtichStr);
			}
			usleep(100000);
		}
	}
};
