#include "test5_plugin/test5_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test5Plugin,general_bus::GeneralPlugin)

namespace general_bus {

	void Test5Plugin::start(){
		GOON_OR_RETURN;
		std::string tempStr="";
    //getActorName(_actorID,tempStr);
		int i = 0;
		while(ros::ok()){
			GOON_OR_RETURN;
			if(i == 30) {
				pubEventMsg("finish_event");
			} else if(i == 10) {
				pubEventMsg("enemy_event");
			}
			ROS_INFO("[Test5 Plugin]in actorID: %lld in actorName: %s is running on cpu %d for %d time",_actorID,tempStr.c_str(),sched_getcpu(),i+1);
			usleep(100000);
			i++;
		}
	}

};
