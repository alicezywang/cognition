#include "test12_plugin/test12_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
//#include "test12_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test12Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	void Test12Plugin::start(){
		std::string tempStr;
    //getActorName(_actorID, tempStr);
		GOON_OR_RETURN;
		int i = 0;
		while (ros::ok()) {
			i++;
			GOON_OR_RETURN;
			ROS_INFO("[Test12 Plugin]in actorID: %ld in actorName: %s is running for %d time", _actorID, tempStr.c_str(), i);
			usleep(100000);
		}
	}
};
