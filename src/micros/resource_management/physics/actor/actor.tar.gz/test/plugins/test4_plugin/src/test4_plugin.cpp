#include "test4_plugin/test4_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test4Plugin,general_bus::GeneralPlugin)

namespace general_bus {

	void Test4Plugin::start(){

    //getActorName(_actorID, _actorName);

		int i=0;
		while(ros::ok()){
			GOON_OR_RETURN;
			if(i == 30) {
				pubEventMsg("finish_event");
			}
			ROS_INFO("[Test4Plugin] in actorID %ld actorName %s running for %d time", _actorID, _actorName.c_str(), i++);
			usleep(100000);
		}
	}
};
