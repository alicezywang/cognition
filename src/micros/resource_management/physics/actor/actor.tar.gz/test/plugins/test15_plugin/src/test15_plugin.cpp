#include "test15_plugin/test15_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
//#include "test15_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test15Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	void Test15Plugin::start(){
		std::string tempStr;
    //getActorName(_actorID, tempStr);
		int i = 0;
		while (ros::ok()) {
			i++;
			GOON_OR_RETURN;
			ROS_INFO("[Test15 Plugin]in actorID: %ld in actorName: %s is running for %d time", _actorID, tempStr.c_str(), i);
			if (i%5 == 0) {
				ROS_INFO("[Test15 Plugin]in actorID: %ld in actorName: %s is about to pause actor", _actorID, tempStr.c_str());
				GeneralPlugin::yieldActor();
			}
			sleep(_duration);
		}
	}
};
