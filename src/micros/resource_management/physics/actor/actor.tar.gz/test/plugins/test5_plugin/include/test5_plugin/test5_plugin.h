#ifndef __TEST5_PLUGIN__
#define __TEST5_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class Test5Plugin: public GeneralPlugin {	
	public:
		virtual void start();
	};
}
#endif
