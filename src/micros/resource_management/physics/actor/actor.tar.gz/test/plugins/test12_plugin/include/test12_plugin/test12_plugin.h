#ifndef __TEST12_PLUGIN__
#define __TEST12_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class Test12Plugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	};
}
#endif
