#include "test1_plugin/test1_plugin.h"
#include <pluginlib/class_list_macros.h>
//#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test1Plugin,general_bus::GeneralPlugin)

namespace general_bus {

	void Test1Plugin::start(){
		
		// ros::Subscriber sub = pluginSubscribe("uto_actor_params", 10000, &Test1Plugin::callback, this);
		_pub = pluginAdvertise<actor_msgs::UTOEvent>("uto_event_msg", 10000);

    //getActorName(_actorID, _actorName);

		bool flag = false;
		int i=0;
		while(ros::ok()){
			GOON_OR_RETURN;
			if(i == 10) {
				pubEventMsg("finish_event");
			}
			ROS_INFO("[Test1Plugin] in actorID %ld actorName %s running for %d time", _actorID, _actorName.c_str(), i++);
			usleep(100000);
		}
	}
};
