#ifndef __TEST_QUEUE_SUB_PLUGIN__
#define __TEST_QUEUE_SUB_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "std_msgs/String.h"
namespace general_bus {
	class TestQueueSubPlugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	private:
	void chatterCallback(const std_msgs::String::ConstPtr& msg);
	void chatterCallback2(const std_msgs::String::ConstPtr& msg);
	};
}
#endif
