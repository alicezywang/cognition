#ifndef __TEST_ACTOR_REQUEST_PLUGIN__
#define __TEST_ACTOR_REQUEST_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "std_msgs/String.h"
namespace general_bus {
	class TestActorRequestPlugin: public GeneralPlugin {	
	public:
		virtual void start();
	private:
		void callback(const std_msgs::String::ConstPtr& msg);	
				
	};
}
#endif
