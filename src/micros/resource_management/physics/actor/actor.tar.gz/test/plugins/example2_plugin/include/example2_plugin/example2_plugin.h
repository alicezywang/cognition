#ifndef __EXAMPLE2_PLUGIN__
#define __EXAMPLE2_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class Example2Plugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	};
}
#endif
