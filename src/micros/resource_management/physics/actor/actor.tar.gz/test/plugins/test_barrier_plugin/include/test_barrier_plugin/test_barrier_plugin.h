#ifndef __TEST_BARRIER_PLUGIN__
#define __TEST_BARRIER_PLUGIN__

#include "general_plugin/general_plugin.h"
namespace general_bus {
	class TestBarrierPlugin: public GeneralPlugin {	
	public:
		virtual void start();
	};
}
#endif
