#include "gstation_plugin/gstation_plugin.h"

PLUGINLIB_EXPORT_CLASS(general_bus::GStationPlugin,general_bus::GeneralPlugin)

namespace general_bus {

void GStationPlugin::start(){
	std::string curActorNameStr;
  //getActorName(_actorID, curActorNameStr);
	int64_t i = 0;
	while (ros::ok()) {
		i++;
		GOON_OR_RETURN;
		std::cout << "[GStation Plugin] in actorID: " << _actorID << " in actorName: " << curActorNameStr << " is running for " << i << " times." << std::endl;
		sleep(_duration);
	}
}

GStationPlugin::GStationPlugin()
{
	this->_nh = ros::NodeHandle("~/");
	string tempParamStr;
	if (_nh.hasParam("timeDurationSingle")) {
        _nh.getParam("timeDurationSingle",tempParamStr); 
		timeDurationSingle = atoi(tempParamStr.c_str());
    } else {
       timeDurationSingle = 5;
       cout << "[INFO] cannot find timeDurationSingle in the parameter server, using 5 as default." << endl;
    }
	if (_nh.hasParam("timeDurationSwarm")) {
        _nh.getParam("timeDurationSwarm",tempParamStr); 
		timeDurationSwarm = atoi(tempParamStr.c_str());
    } else {
       timeDurationSwarm = 5;
       cout << "[INFO] cannot find timeDurationSwarm in the parameter server, using 5 as default." << endl;
    }
	_matchFilePath.clear();
	_taskFilePath.clear();
	_swarmMatchXmlStr.clear();
	_swarmTaskXmlStr.clear();
	// NOTICE: vector.clear() will clear the vector, however the data saved in the vector is not cleared, using swap instead
	std::vector<string>().swap(_swarmTaskActorList);
	std::vector<struct SwarmTaskResponse>().swap(_responseVec);
	std::vector<int64_t>().swap(_confirmedPlatformID);

	_pPubReq = new RTPSPublisher<SwarmTask>("/swarm_task_requirements");
	_pSubResp = new RTPSSubscriber<SwarmTask>("/swarm_task_response", &GStationPlugin::subResponseCallback, this);
	_pPubAssign = new RTPSPublisher<SwarmTask>("/swarm_task_assignments");
	_pSubConfirm = new RTPSSubscriber<SwarmTask>("/task_assignment_confirmation", &GStationPlugin::subConfirmationCallback, this);
	_pPubCommand = new RTPSPublisher<CtrlMsg>("/swarm_commands");	
	_pPubTagList = new RTPSPublisher<TagList>("/TagList");
	_pSubTagListReq = new RTPSSubscriber<TagListRequest>("/TagListRequest", &GStationPlugin::tagListRequestCallback, this);
	_subRemoteCmds = _nh.subscribe("/gstation_remote_cmds", 10000, &GStationPlugin::subRemoteCmdsCallback0, this);
	_subUsrInstructions = _nh.subscribe("/gstation_usr_instructions", 10000, &GStationPlugin::subUsrInstructionsCallback0, this);

	// set flags
	_taskAssignFlag = false;
	_confirmAssignFlag = false;
	_subRespOvertimeFlag = false;
	_subConfOvertimeFlag = false;

	// initialize params for TagDictService
	_count = 0;
	_lasttime = time(NULL);
	string tagListFilePath;
	if (_nh.getParam("taglistdict", tagListFilePath)) {
		TiXmlDocument doc(tagListFilePath);
		cout << "[Ground Station] Trying to get taglistdict from " << tagListFilePath << endl;
		if (doc.LoadFile()) {
			TiXmlPrinter printer;
			doc.Accept( &printer );
			_tagListStr = printer.CStr();
		}
	}
	else {
		cout << "[Ground Station] Cannot find 'taglistdict' in the Param Server, using default TagListStr!" << endl;
		_tagListStr = "\
<actor><name>Observer</name><tag>1</tag></actor>\
<actor><name>Leader</name><tag>2</tag></actor>\
<actor><name>Follower</name><tag>3</tag></actor>\
<actor><name>Attacker</name><tag>4</tag></actor>\
<actor><name>Transmitter</name><tag>5</tag></actor>";
	}

	if (!_pPubReq->init()) {
		cout << "[Ground Station] Failed to initialize RTPSPublisher for /swarm_task_requirements!" << endl;
		return;
	}
	if (!_pSubResp->init()) {
		cout << "[Ground Station] Failed to initialized RTPSSubscriber for /swarm_task_response!" << endl;
		return;
	}
	if (!_pPubAssign->init()) {
		cout << "[Ground Station] Failed to initialized RTPSPublisher for /swarm_task_assignments!" << endl;
		return;
	}
	if (!_pSubConfirm->init()) {
		cout << "[Ground Station] Failed to initialized RTPSSubscriber for /task_assignment_confirmation!" << endl;
		return;
	}
	if (!_pPubCommand->init()) {
		cout << "[Ground Station] Failed to initialized RTPSPublisher for /swarm_commands!" << endl;
		return;
	}
	if (!_pPubTagList->init()) {
		cout << "[Ground Station] Failed to initialized RTPSPublisher for /TagList!" << endl;
		return;
	}
	if (!_pSubTagListReq->init()) {
		cout << "[Ground Station] Failed to initialized RTPSSubscriber for /TagListRequest!" << endl;
		return;
	}

	cout << "[Ground Station] Initialized!" << endl;
}

GStationPlugin::~GStationPlugin()
{
	if (_pPubReq != NULL) {
		delete _pPubReq;
		_pPubReq = NULL;
	}
	if (_pSubResp != NULL) {
		delete _pSubResp;
		_pSubResp = NULL;
	}
	if (_pPubAssign != NULL) {
		delete _pPubAssign;
		_pPubAssign = NULL;
	}
	if (_pSubConfirm != NULL) {
		delete _pSubConfirm;
		_pSubConfirm = NULL;
	}
	if (_pPubCommand != NULL) {
		delete _pPubCommand;
		_pPubCommand = NULL;
	}
	if (_pPubTagList != NULL) {
		delete _pPubTagList;
		_pPubTagList = NULL;
	}
	if (_pSubTagListReq != NULL) {
		delete _pSubTagListReq;
		_pSubTagListReq = NULL;
	}
}

bool GStationPlugin::init()
{
	TiXmlDocument doc1, doc2;
	string xmlStr1, xmlStr2;
	if ( !doc1.LoadFile(_matchFilePath) )
	{
		// ROS_ERROR("[Ground Station] Error while open swarm match XML file!");
		cout << "[Ground Station] Error while open swarm match XML file!" << endl;
		return false;
	}
	else
	{
		TiXmlPrinter printer1;
		doc1.Accept(&printer1);
		xmlStr1 = printer1.CStr();
	}

	if ( !doc2.LoadFile(_taskFilePath) )
	{
		// ROS_ERROR("[Ground Station] Error while open swarm task XML file!");
		cout << "[Ground Station] Error while open swarm task XML file!" << endl;
		return false;
	}
	else
	{
		TiXmlPrinter printer2;
		doc2.Accept(&printer2);
		xmlStr2 = printer2.CStr();
	}
	
	if ( !initSwarmArchitecture(xmlStr2) ) {
		// ROS_FATAL("[Ground Station] Failed to initialize Swarm Architecture!");
		cout << "[Ground Station] Failed to initialize Swarm Architecture!" << endl;
		return false;
	}

	_swarmMatchXmlStr = xmlStr1;
	_swarmTaskXmlStr = xmlStr2;

	cout << "Debug: size of SwarmMatch: " << xmlStr1.size() << ", size of SwarmTask: " << xmlStr2.size() << "." << endl;

	return true;
	
}

void GStationPlugin::pubRequirements()
{
	SwarmTask msg;
	msg.swarmMatchXmlStr(_swarmMatchXmlStr);
	msg.swarmTaskXmlStr(_swarmTaskXmlStr);
	GET_CUR_TIME;
	string curTimeStr(szTime);
	msg.timeStamp(curTimeStr);

	for (int i = 0; i < timeDurationSingle; i++)
	{
		cout << "[Ground Station] Publishing /swarm_task_requirements." << endl;
		_pPubReq->publish(msg);
		sleep(1);
	}

}

bool GStationPlugin::initSwarmArchitecture(string aXmlStr)
// everytime the _swarmTaskXmlStr is updated the struct of _swarmArchitectureInfo must be updated!!!
{
	struct SwarmArchitecture tempSwarmArchitectureInfo;
	vector<string> tempSwarmTaskActorList;
	TiXmlDocument doc;
	// receive XML file as string
	if (aXmlStr.size()==0) {
		// ROS_FATAL("[Ground Station] Input XML string is empty!");
		cout << "[Ground Station] Input XML string is empty!" << endl;
		return false;
	}
	doc.Parse(aXmlStr.c_str());
	if (doc.Error()!=0) {
		// ROS_FATAL("[Ground Station] Input XML file is not in correct format!");
		cout << "[Ground Station] Input XML file is not in correct format!" << endl;
		return false;
	}
	TiXmlElement *pEle;
	TiXmlHandle hDoc(&doc);
	pEle = hDoc.FirstChildElement().Element();
	for (pEle = pEle->FirstChildElement(); pEle != NULL; pEle = pEle->NextSiblingElement()) {
		string tagName = pEle->Value();
		if (tagName == "_P_SwarmName") {
			_swarmName = pEle->GetText();
		}
		if (tagName == "_ActorsConfig") {
			for (TiXmlElement* pActorType = pEle->FirstChildElement(); pActorType != NULL; pActorType = pActorType->NextSiblingElement()) {
				string actorTypeTag = pActorType->Value();
				if (actorTypeTag == "_GeneralActors") {
					for (TiXmlElement* pActors = pActorType->FirstChildElement(); pActors != NULL; pActors = pActors->NextSiblingElement()) {
						string actorName;
						int actorNum = 0;
						bool foundName = false;
						bool foundNum = false;
						for (TiXmlElement* pActorTag = pActors->FirstChildElement(); pActorTag != NULL; pActorTag = pActorTag->NextSiblingElement() ) {
							string actorTagName = pActorTag->Value();
							if (actorTagName == "_P_Name") {
								actorName = pActorTag->GetText();
								foundName = true;
							}
							if (actorTagName == "_P_Num") {
								string strNum = pActorTag->GetText();
								actorNum = atoi( strNum.c_str() );
								if (actorNum >= 0) {
									foundNum = true;;
								}								
							}							
						}
						if (!foundName) {
							cout << "[Ground Station] Warning: Actor Name missing in _GeneralActors!" << endl;
						}
						if (!foundNum) {
							cout << "[Ground Station] Warning: Actor Num missing in _GeneralActors!" << endl;
						}
						tempSwarmTaskActorList.push_back(actorName);
						for (int i = 1; i <= actorNum; i++) {
							stringstream ss;
							ss << i;
							string str, temp;
							ss >> str;
							temp = actorName + str;
							tempSwarmArchitectureInfo.actors.generalActors.push_back(temp);
						}
					}
				}
				else if (actorTypeTag == "_ExcluActors") {
					for (TiXmlElement* pActors = pActorType->FirstChildElement(); pActors != NULL; pActors = pActors->NextSiblingElement()) {
						string actorName;
						int actorNum = 0;
						bool foundName = false;
						bool foundNum = false;
						for (TiXmlElement* pActorTag = pActors->FirstChildElement(); pActorTag != NULL; pActorTag = pActorTag->NextSiblingElement() ) {
							string actorTagName = pActorTag->Value();
							if (actorTagName == "_P_Name") {
								actorName = pActorTag->GetText();
								foundName = true;
							}
							if (actorTagName == "_P_Num") {
								string strNum = pActorTag->GetText();
								actorNum = atoi( strNum.c_str() );
								if (actorNum >= 0) {
									foundNum = true;;
								}
							}							
						}
						if (!foundName) {
							cout << "[Ground Station] Warning: Actor Name missing in _ExcluActors!" << endl;
						}
						if (!foundNum) {
							cout << "[Ground Station] Warning: Actor Num missing in _ExcluActors!" << endl;
						}
						tempSwarmTaskActorList.push_back(actorName);
						for (int i = 1; i <= actorNum; i++) {
							stringstream ss;
							ss << i;
							string str, temp;
							ss >> str;
							temp = actorName + str;
							tempSwarmArchitectureInfo.actors.exclusiveActors.push_back(temp);
						}
					}
				}
				else if (actorTypeTag == "_DynamicActors") {
					for (TiXmlElement* pActors = pActorType->FirstChildElement(); pActors != NULL; pActors = pActors->NextSiblingElement()) {
						string actorName;
						int actorNum = 0;
						bool foundName = false;
						bool foundNum = false;
						for (TiXmlElement* pActorTag = pActors->FirstChildElement(); pActorTag != NULL; pActorTag = pActorTag->NextSiblingElement() ) {
							string actorTagName = pActorTag->Value();
							if (actorTagName == "_P_Name") {
								actorName = pActorTag->GetText();
								foundName = true;
							}
							if (actorTagName == "_P_Num") {
								string strNum = pActorTag->GetText();
								actorNum = atoi( strNum.c_str() );
								if (actorNum >= 0) {
									foundNum = true;;
								}
							}							
						}
						if (!foundName) {
							cout << "[Ground Station] Warning: Actor Name missing in _DynamicActors!" << endl;
						}
						if (!foundNum) {
							cout << "[Ground Station] Warning: Actor Num missing in _DynamicActors!" << endl;
						}
						tempSwarmTaskActorList.push_back(actorName);
						for (int i = 1; i <= actorNum; i++) {
							stringstream ss;
							ss << i;
							string str, temp;
							ss >> str;
							temp = actorName + str;
							tempSwarmArchitectureInfo.actors.dynamicActors.push_back(temp);
						}
					}
				}
				else {
					// ROS_ERROR("[Ground Station] Unknown Actor Type: %s!", actorTypeTag.c_str());
					cout << "[Ground Station] Unknown Actor Type: " << actorTypeTag << endl;
					return false;
				}
			}
		}
	}
	_swarmArchitectureInfo = tempSwarmArchitectureInfo;
	_swarmTaskActorList = tempSwarmTaskActorList;
	return true;
}

void GStationPlugin::subscribeResponses()
{
	// ROS_INFO("[Ground Station] Start subscribing /swarm_task_response.");
	cout << "[Ground Station] Wait for subscribing /swarm_task_response." << endl;

	for (int i = 0; i < timeDurationSwarm; i++)
	{
		sleep(1);
		if (_taskAssignFlag) {
			cout << "[Ground Station] OK to assign tasks, quit waiting." << endl;
			break;
		}
	}

	if (!_taskAssignFlag) {
		cout << "[Ground Station] Overtime while subscribing responses." << endl;
		_subRespOvertimeFlag = true;
	}
}

void GStationPlugin::subResponseCallback(SwarmTask& aMsg)
{
	if (_subRespOvertimeFlag) {	// Overtime?
		cout << "[Ground Station] Subscribe swarm matching responses overtime, please modify overtime params." << endl;
		return;
	} 
	else {
		if (_taskAssignFlag) { 	// Task assigned?
			cout << "[Ground Station] Ready to assign swarm tasks, not open to new responses." << endl;
			return;
		}
		else {	// subscribe new responses and try to assign tasks
			for (int i = 0; i < _responseVec.size(); i++) {
				if (aMsg.platformID() == _responseVec[i].platformID) {	// received before?
					cout << "[Ground Station] Response received before!" << endl;
					return;
				}
			}
			// // TODO: check whether the response is legal or not, commented for debug, remember to uncomment after debug
			// int actorNum = _swarmArchitectureInfo.actors.generalActors.size() + _swarmArchitectureInfo.actors.exclusiveActors.size() + _swarmArchitectureInfo.actors.dynamicActors.size();
			// std::vector<string> tempActorName = aMsg.actorName();
			// if (tempActorName.size() != actorNum) {
			// 	// ROS_WARN("[Ground Station] Actor number may be wrong in response message from platform %ld!", aMsg.platformID());
			// 	cout << "[Ground Station] Actor number may be wrong in response message from platform " << aMsg.platformID() << endl;
			// }

			// // TODO: assign swarm tasks based on BID from platforms
			struct SwarmTaskResponse resp;
			resp.platformID = aMsg.platformID();
			// resp.actorNameVec = aMsg.actorName();
			// resp.bidActorVec = aMsg.bidActor();

			_responseVec.push_back(resp);

			if (
				(_responseVec.size() >= _swarmArchitectureInfo.actors.generalActors.size()) &&
				(_responseVec.size() >= _swarmArchitectureInfo.actors.exclusiveActors.size()) &&
				(_responseVec.size() >= _swarmArchitectureInfo.actors.dynamicActors.size()) )
			{
				// // Debug
				// cout << "[Debug] General Actors Num: " << _swarmArchitectureInfo.actors.generalActors.size()
				// 	<< ", Exclusive Actors Num: " << _swarmArchitectureInfo.actors.exclusiveActors.size() 
				// 	<< ", Dynamic Actors Num: " << _swarmArchitectureInfo.actors.dynamicActors.size()
				// 	<< endl;
				cout << "[Ground Station] Receive enough responses to assign swarm tasks!" << endl;
				_taskAssignFlag = true;
			}
			else {
				cout << "[Ground Station] Not enough platform. Continue..." << endl;
			}
		}
	}
}

void GStationPlugin::pubAssignments()
// TODO: This algorithm is not completed yet!!!
// Suppose all platforms are available for all the tasks
{
	// // debug
	// int responseNum = _responseVec.size();
	// for (int i=0; i<responseNum; i++) {
	// 	// ROS_INFO("[Ground Station] responseNum:%d, responser ID: %ld", responseNum, _responseVec[i].platformID);
	// 	cout << "[Ground Station] Responser count: " << responseNum << ", responser ID: " << _responseVec[i].platformID << endl;
	// }

	SwarmTask msg;
	msg.swarmMatchXmlStr(_swarmMatchXmlStr);
	msg.swarmTaskXmlStr(_swarmTaskXmlStr);
	
	int actorNum = _swarmArchitectureInfo.actors.generalActors.size();
	std::vector<string> tempActorName;			// idl messages based on sequence<string>
	std::vector<int64_t> tempTaskAssignment;	// idl messages based on sequence<int64_t>
	string tempActorNameListStr, tempTaskAssignmentListStr;	// 20181026: Swarm Task Message, change sequence<string> into string<_size>
	tempActorNameListStr.clear();
	tempTaskAssignmentListStr.clear();
	for (int i=0; i<actorNum; i++) {
		tempActorName.push_back(_swarmArchitectureInfo.actors.generalActors[i]);
		tempTaskAssignment.push_back(_responseVec[i].platformID);
		// 20181026: change sequence<string> into string<_size>
		tempActorNameListStr += _swarmArchitectureInfo.actors.generalActors[i];
		tempActorNameListStr += ";";
		stringstream ss;
		ss.clear();
		string tempStr1;
		ss << _responseVec[i].platformID;
		ss >> tempStr1;
		tempTaskAssignmentListStr += tempStr1;
		tempTaskAssignmentListStr += ";";
	}
	actorNum = _swarmArchitectureInfo.actors.exclusiveActors.size();
	int tempFormationID = 0;
	for (int i=0; i<actorNum; i++) {
		tempActorName.push_back(_swarmArchitectureInfo.actors.exclusiveActors[i]);
		tempTaskAssignment.push_back(_responseVec[i].platformID);
		// 20181026: change sequence<string> into string<_size>
		// task assignment
		tempActorNameListStr += _swarmArchitectureInfo.actors.exclusiveActors[i];
		tempActorNameListStr += ";";
		stringstream ss;
		ss.clear();
		string tempStr1;
		ss << _responseVec[i].platformID;
		ss >> tempStr1;
		tempTaskAssignmentListStr += tempStr1;
		tempTaskAssignmentListStr += ";";
	}
	actorNum = _swarmArchitectureInfo.actors.dynamicActors.size();
	for (int i=0; i<actorNum; i++) {
		tempActorName.push_back(_swarmArchitectureInfo.actors.dynamicActors[i]);
		tempTaskAssignment.push_back(_responseVec[i].platformID);
		// 20181026: change sequence<string> into string<_size>
		tempActorNameListStr += _swarmArchitectureInfo.actors.dynamicActors[i];
		tempActorNameListStr += ";";
		stringstream ss;
		ss.clear();
		string tempStr1;
		ss << _responseVec[i].platformID;
		ss >> tempStr1;
		tempTaskAssignmentListStr += tempStr1;
		tempTaskAssignmentListStr += ";";
	}
	msg.actorNameList(tempActorNameListStr);
	msg.taskAssignmentList(tempTaskAssignmentListStr);

	for (int i=0; i<tempTaskAssignment.size(); i++) {
		// ROS_INFO("[Ground Station] debug assignment: %s: platform %ld", tempActorName[i].c_str(), tempTaskAssignment[i]);
		cout << "[Ground Station] Print assignments: " << tempActorName[i] << ", assigned to platformID " << tempTaskAssignment[i] << endl;
	}
	
	// clear the vector of _confirmedPlatformID, and prepare for the message of task assignment confirmation from platforms
	std::vector<int64_t>().swap(_confirmedPlatformID);

	// ROS_INFO("[Ground Station] About to publish /swarm_task_assignments.");
	cout << "[Ground Station] About to publish /swarm_task_assignments." << endl;

	for (int i = 0; i < timeDurationSingle; i++)
	{
		GET_CUR_SEC;
		msg.timeStamp(curSecStr);
		_pPubAssign->publish(msg);
		cout << "[Ground Station] Publishing /swarm_task_assignments!" << endl;
		sleep(1);
	}

	cout << "[Ground Station] Finish publishing /swarm_task_assignments." << endl;
}

void GStationPlugin::pubFormationCtrlMsg() 
{
	string keyWord1 = "Leader";
	string keyWord2 = "Follower";

	// Swarm Command Message
	CtrlMsg msg1, msg2;

	string tempPlatformIdListStr1, tempDataStr1;	// debug only: Swarm Command Message for keyWord1, change sequence<string> into string<_size>
	string tempPlatformIdListStr2, tempDataStr2;	// debug only: Swarm Command Message for keyWord2, change sequence<string> into string<_size>
	tempPlatformIdListStr1.clear();
	tempDataStr1.clear();
	tempPlatformIdListStr2.clear();
	tempDataStr2.clear();

	int actorNum = _swarmArchitectureInfo.actors.exclusiveActors.size();
	int temp1FormationID = 0;
	int temp2FormationID = 0;
	for (int i=0; i<actorNum; i++) {
		// notice: change sequence<string> into string<_size>
		// swarm formation control message
		string tempActorName = _swarmArchitectureInfo.actors.exclusiveActors[i];
		stringstream ss;
		ss.clear();
		string tempStr1;
		ss << _responseVec[i].platformID;
		ss >> tempStr1;
		if (tempActorName.find(keyWord1) != std::string::npos) {	
			tempPlatformIdListStr1 += tempStr1;
			tempPlatformIdListStr1 += ";";
			temp1FormationID++;
			tempDataStr1 += "TYPE_UNKNOWN,0;";		// formation type
			if (temp1FormationID > 1) {
				cout << "[Ground Station] Warning: More than 1 " << keyWord1 << "!" << endl;
			}
		}
		if (tempActorName.find(keyWord2) != std::string::npos) {	
			tempPlatformIdListStr2 += tempStr1;
			tempPlatformIdListStr2 += ";";
			temp2FormationID++;
			string tempStr2;
			ss.clear();
			ss << temp2FormationID;
			ss >> tempStr2;
			tempDataStr2 += "TYPE_UNKNOWN,";		// formation type
			tempDataStr2 += tempStr2;				// formation position
			tempDataStr2 += ";";
		}
	}
	
	msg1.swarmName(_swarmName);
	msg1.actorName(keyWord1);
	msg1.platformIdList(tempPlatformIdListStr1);
	msg1.data(tempDataStr1);

	msg2.swarmName(_swarmName);
	msg2.actorName(keyWord2);
	msg2.platformIdList(tempPlatformIdListStr2);
	msg2.data(tempDataStr2);

	cout << "[Ground Station] Publish swarm formation control message:" << endl;
	cout << "swarmName is " << _swarmName << endl;
	cout << "actorName is " << keyWord1 << endl;
	cout << "platformIdList is " << tempPlatformIdListStr1 << endl;
	cout << "data is " << tempDataStr1 << endl;

	cout << "swarmName is " << _swarmName << endl;
	cout << "actorName is " << keyWord2 << endl;
	cout << "platformIdList is " << tempPlatformIdListStr2 << endl;
	cout << "data is " << tempDataStr2 << endl;
	
	cout << "[Ground Station] About to publish /swarm_commands." << endl;

	for (int i = 0; i < timeDurationSingle; i++)
	{
		GET_CUR_TIME;
		string curTimeStr(szTime);
		msg1.timeStamp(curTimeStr);
		_pPubCommand->publish(msg1);
		cout << "[Ground Station] Publishing /swarm_commands for " << keyWord1 << endl;
		sleep(1);
	}
	sleep(1);
	for (int i = 0; i < timeDurationSingle; i++)
	{
		GET_CUR_TIME;
		string curTimeStr(szTime);
		msg2.timeStamp(curTimeStr);
		_pPubCommand->publish(msg2);
		cout << "[Ground Station] Publishing /swarm_commands for " << keyWord2 << endl;
		sleep(1);
	}

	cout << "[Ground Station] Finish publishing /swarm_commands." << endl;
}

void GStationPlugin::subscribeConfirmation()
{
	// ROS_INFO("[Ground Station] Start subscribing /task_assignment_confirmation.");
	cout << "[Ground Station] Wait for subscribing /task_assignment_confirmation." << endl;

	for (int i = 0; i < timeDurationSwarm; i++)
	{
		sleep(1);
		if (_confirmAssignFlag) {
			cout << "[Ground Station] Task assignment confirmed, quit waiting." << endl;
			break;
		}
	}

	if (_confirmAssignFlag) {
		return;
	}
	else {
		cout << "[Ground Station] Overtime while subscribing confirmations." << endl;
		_subConfOvertimeFlag = true;
	}
}

void GStationPlugin::subConfirmationCallback(SwarmTask& aMsg)
{
	if (_subConfOvertimeFlag) {	// Overtime?
		cout << "[Ground Station] Subscribe task assignment confirmation overtime, please modify overtime params." << endl;
		return;
	} 
	else {
		if (_confirmAssignFlag) { // Task assignment confirmed?
			cout << "[Ground Station] Task assignment already confirmed, no need to keep publishing confirmations." << endl;
			return;
		}
		else {	// subscribing new confirmations
			for (int i=0; i<_confirmedPlatformID.size(); i++) {
				if (aMsg.platformID() == _confirmedPlatformID[i]) {
					cout << "[Ground Station] Confirmation received before!" << endl;
					return;
				}
			}
			if (aMsg.confirmAssignment() == 1) {
				_confirmedPlatformID.push_back(aMsg.platformID());
			}
			_confirmAssignFlag = confirmSwarmTaskAssignment();
		}
	}
}

bool GStationPlugin::confirmSwarmTaskAssignment()
// NOTICE: This only works when the size of _responseVec is equal to the minimum number of platforms which the Swarm Task requires.
{
	if (_responseVec.size() == 0) {
		cout << "[Ground Station] Error: Response vector is empty!" << endl;
		return false;
	}
	if (_confirmedPlatformID.size() == 0) {
		cout << "[Ground Station] Error: _confirmedPlatformID vector is empty!" << endl;
		return false;
	}

	for (int i = 0; i < _responseVec.size(); i++) {
		int64_t tempID = _responseVec[i].platformID;
		bool matchFlag = false;
		for (int j = 0; j < _confirmedPlatformID.size(); j++) {
			if ( _responseVec[i].platformID == _confirmedPlatformID[j] ) {
				matchFlag = true;
				break;
			}
		}
		if (!matchFlag) {
			return false;
		}
	}
	return true;
}

void GStationPlugin::subRemoteCmdsCallback0(const actor_msgs::gstation_remote_cmds& aMsg)
{
	cout << "[Ground Station] GStation Remote Cmds received!" << endl;
	CtrlMsg msg1;
	msg1.timeStamp(aMsg.timeStamp);
	msg1.swarmName(aMsg.swarmName);
	msg1.actorName(aMsg.actorName);
	msg1.platformIdList(aMsg.platformIdList);
	msg1.data(aMsg.data);

	cout << "[Ground Station] About to publish /swarm_commands to set formations." << endl;

	for (int i = 0; i < timeDurationSingle; i++)
	{
		GET_CUR_TIME;
		string curTimeStr(szTime);
		msg1.timeStamp(curTimeStr);
		_pPubCommand->publish(msg1);
		cout << "[Ground Station] Publishing /swarm_commands!" << endl;
		sleep(1);
	}

	cout << "[Ground Station] Finish publishing /swarm_commands." << endl;
}

void GStationPlugin::subUsrInstructionsCallback0(const actor_msgs::GStationCommInterface& aMsg)
{
	cout << "[Ground Station] GStation User Instructions received!" << endl;

	if (aMsg.command == "SwarmMatch") {
		// get file path info
		vector<string> filePathList;
		string str1, str2;
		str1 = aMsg.filePath;
		while (str1.find(";") != std::string::npos) {
			size_t pos1 = str1.find(";");
			str2 = str1.substr(0,pos1);
			str1 = str1.substr(pos1+1);
			filePathList.push_back(str2);
		}
		if (filePathList.size() != 2) {
			cout << "[Ground Station] aMsg.filePath() is not be in the right format, which should be like 'MatchPath;TaskPath;' !" << endl;
			return;
		}
		_matchFilePath = filePathList[0];
		_taskFilePath = filePathList[1];
		// load the xml files as strings and pub
		if (init())
		{
			cout << "[Ground Station] About to publish /swarm_task_requirements." << endl;
			int cnt = 0;
			while (!_taskAssignFlag)
			{
				pubRequirements();
				cnt++;
				if (cnt > timeDurationSwarm)
				{
					cout << "[Ground Station] Timeout and return!" << endl;
					return;
				}
			}
			subscribeResponses();		// wait for responses
		}
		else
		{
			cout << "[Ground Station] Failed to initialize, quit publishing /swarm_task_requirements!" << endl;
			return;
		}
	}
	else if (aMsg.command == "SwarmTask") {
		if (!_taskAssignFlag) {
			cout << "[Ground Station] Please run SwarmMatch command first before assigning SwarmTasks!" << endl;
			return;
		}
		else {
			pubAssignments();
			subscribeConfirmation();
			pubFormationCtrlMsg();
		}
	}
	else {
		cout << "[Ground Station] Unknown Command!" << endl;
	}

}

//broadcast once when receiving a TagListReq, limited frequency 1Hz
void GStationPlugin::tagListRequestCallback(TagListRequest& aMsg) 
{
	//calc time interval between last bcast and the current req in microsec
	double now = time(NULL);
	double duration = difftime(now, _lasttime);
	if (duration >= 1) { 
		_count++;
		cout << "[Ground Station] Publishing taglist for " << _count << " times." << endl;
		TagList tagList;
		tagList.data( _tagListStr.c_str() );
		_pPubTagList->publish(tagList);
		_lasttime = now;
	}
}

};
