#include "test_actor_request_plugin/test_actor_request_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "std_msgs/String.h"
#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::TestActorRequestPlugin,general_bus::GeneralPlugin)

namespace general_bus {
	void TestActorRequestPlugin::callback(const std_msgs::String::ConstPtr& msg){
		ROS_INFO("[TestActorRequestPlugin] /swarmactor_request heard: [%s], and reqeustSwarmActorFromMaster.", msg->data.c_str());
		std::string sendActorName;
    //getActorName(_actorID, sendActorName);
		requestActivateActorFromMaster(sendActorName,msg->data);
	}

	void TestActorRequestPlugin::start(){
		GOON_OR_RETURN;

		std::string actorName = "";
    //getActorName(_actorID, actorName);
		ROS_INFO("[TestActorRequestPlugin] start in actor:", actorName.c_str());
	    
		ros::NodeHandle n;
		ros::Subscriber sub = n.subscribe("/swarmactor_request", 100, &TestActorRequestPlugin::callback, this);
		ros::Publisher pub = n.advertise<std_msgs::String>("/swarmactor_request", 100);

		int i=0;
		while(ros::ok()){
			GOON_OR_RETURN;
			ROS_INFO("[TestActorRequestPlugin] in actorID %ld actorName %s running for %d time",_actorID,actorName.c_str(),i++);
			sleep(_duration);
			ros::spinOnce();
		}

	}

};
