#ifndef __TEST15_PLUGIN__
#define __TEST15_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class Test15Plugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	};
}
#endif
