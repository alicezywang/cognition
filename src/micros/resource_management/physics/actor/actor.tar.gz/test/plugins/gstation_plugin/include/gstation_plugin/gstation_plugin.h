#ifndef __GSTATION_PLUGIN__
#define __GSTATION_PLUGIN__

#include <pluginlib/class_list_macros.h>
#include <string>
#include <iostream>
#include <tinyxml.h>
#include <stdlib.h>
#include <vector>
#include <sstream>
#include <sys/time.h>
#include <time.h>

#include "ros/ros.h"
#include "general_plugin/general_plugin.h"

#include "actor_core/actor_core.h"
#include "actor_msgs/GStationCommInterface.h"
#include "actor_msgs/gstation_remote_cmds.h"
#include "gstation_plugin/SwarmTask.h"
#include "gstation_plugin/CtrlMsg.h"
#include "gstation_plugin/TagListRequest.h"
#include "gstation_plugin/TagList.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

using namespace std;

#define GET_CUR_SEC  \
	timeval temp_timeV;\
	gettimeofday(&temp_timeV,NULL);\
	string curSecStr;\
	stringstream temp_ss;\
	temp_ss.clear();\
	temp_ss << temp_timeV.tv_sec;\
	temp_ss >> curSecStr;

namespace general_bus {
	class GStationPlugin: public GeneralPlugin {	
	public:
	  GStationPlugin();
	  ~GStationPlugin();
	  struct SwarmTaskResponse
	  {
		  int64_t platformID;
		  vector<string> actorNameVec;
		  vector<int> bidActorVec;
	  };
	  struct ActorArchitecture
	  {
		  vector<string> generalActors;
		  vector<string> exclusiveActors;
		  vector<string> dynamicActors;
	  };
	  struct SwarmArchitecture
	  {
		  struct ActorArchitecture actors;
		  vector<int64_t> platformID;
	  };
	  struct SwarmArchitecture _swarmArchitectureInfo; // swarm size (or actor numbers) is considered, e.g. Observer1, Obsserver2, ...
	  vector<string> _swarmTaskActorList;			  // compared to _swarmArchitectureInfo, this variable does not consider swarm size, e.g. the vector may be like Observer, Leader, Follower, Transmitter, ...
	  vector<struct SwarmTaskResponse> _responseVec;
	  vector<int64_t> _confirmedPlatformID;
	  ros::NodeHandle _nh;
	  string _matchFilePath;
	  string _taskFilePath;
	  int timeDurationSingle = 5;
	  int timeDurationSwarm = 5;
	  string _swarmMatchXmlStr;
	  string _swarmTaskXmlStr;
	  string _swarmName;

	  bool _taskAssignFlag;		// true: OK to assign task; false: not OK to assign task
	  bool _confirmAssignFlag;   // true: task assignment confirmed; false: not confirmed
	  bool _subRespOvertimeFlag; // true: overtime while subscribing match responses; false: not overtime
	  bool _subConfOvertimeFlag; // true: overtime while subscribing task assignment confirmation; false: not overtime

	  bool init();
	  bool confirmSwarmTaskAssignment();
	  virtual void start();

	  //----------------------- Based on FAST-RTPS -----------------------//
	  void pubRequirements();
	  void pubAssignments();
	  void pubFormationCtrlMsg();
	  bool initSwarmArchitecture(string aXmlStr);
	  void subscribeResponses();
	  void subResponseCallback(SwarmTask &aMsg);
	  void subscribeConfirmation();
	  void subConfirmationCallback(SwarmTask &aMsg);
	  void tagListRequestCallback(TagListRequest& aMsg);

	  void subRemoteCmdsCallback0(const actor_msgs::gstation_remote_cmds &aMsg);
	  void subUsrInstructionsCallback0(const actor_msgs::GStationCommInterface &aMsg);

	private:
	  RTPSPublisher<SwarmTask> *_pPubReq;
	  RTPSSubscriber<SwarmTask> *_pSubResp;
	  RTPSPublisher<SwarmTask> *_pPubAssign;
	  RTPSSubscriber<SwarmTask> *_pSubConfirm;
	  RTPSPublisher<CtrlMsg> *_pPubCommand;
	  RTPSPublisher<TagList>* _pPubTagList;
	  RTPSSubscriber<TagListRequest> *_pSubTagListReq;
	  ros::Subscriber _subRemoteCmds;
	  ros::Subscriber _subUsrInstructions;
	  int64_t _count;
	  std::string _tagListStr;
	  double _lasttime;
	};
}
#endif
