#ifndef __TEST_RT_PLUGIN__
#define __TEST_RT_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class TestRTPlugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	};
}
#endif
