#include "test10_plugin/test10_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
//#include "test10_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test10Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	
	void Test10Plugin::start(){
		std::string swtichStr = "Observer";
		std::string tempStr;
    //getActorName(_actorID, tempStr);
		GOON_OR_RETURN;
		int i = 0;
		while (ros::ok()) {
			i++;
			GOON_OR_RETURN;
			if(i == 20) {
				pubEventMsg("timeout_event");
			} else if(i == 10) {
				pubEventMsg("lost_leader_event");
			}
			ROS_INFO("[Test10 Plugin]in actorID: %ld in actorName: %s is running for %d time", _actorID, tempStr.c_str(), i);
			usleep(100000);
		}
	}
};
