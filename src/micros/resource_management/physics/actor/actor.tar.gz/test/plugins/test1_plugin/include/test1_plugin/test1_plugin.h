#ifndef __TEST1_PLUGIN__
#define __TEST1_PLUGIN__

#include "general_plugin/general_plugin.h"
#include "actor_msgs/UTOEvent.h"
#include "actor_msgs/UtoActorParams.h"

namespace general_bus {
	class Test1Plugin: public GeneralPlugin {	
	public:
		virtual void start();
		//for test msgs pub
		ros::Publisher _pub;
		std::string _actorName;
	};
}
#endif
