#include "test_land_takeoff_plugin/test_land_takeoff_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "std_msgs/Empty.h"
#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::TestLandTackoffPlugin,general_bus::GeneralPlugin)

namespace general_bus {
	void TestLandTackoffPlugin::start(){
		GOON_OR_RETURN;

		std::string actorName = "", formationType="", formationPos="";
    //getActorName(_actorID, actorName);
		ROS_INFO("[TestLandTackoffPlugin] start in actor:", actorName.c_str());
	    
		ros::NodeHandle n;
		std::string topicName = actorName.compare("Leader") ==0? "/plane/takeoff" :"/plane/land";
		ros::Publisher pub = n.advertise<std_msgs::Empty>(topicName, 10);
		ros::Rate loop_rate(1);
		int count = 0;
		std_msgs::Empty msg;
		
  		while (ros::ok()){
			GOON_OR_RETURN;
			pub.publish(msg);
			getFormation(_actorID, formationType, formationPos);
			ROS_INFO("[TestLandTackoffPlugin] %s pub %s, formation type=%s,pos=%s", actorName.c_str(), topicName.c_str(), formationType.c_str(), formationPos.c_str());
    		ros::spinOnce();

    		loop_rate.sleep();
		}
	}

};
