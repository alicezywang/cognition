#include "test3_plugin/test3_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"
#include "std_msgs/String.h"
//#include "test3_plugin/actor_api.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Test3Plugin,general_bus::GeneralPlugin)

namespace general_bus {

	void Test3Plugin::start(){

    //getActorName(_actorID, _actorName);

		actor_msgs::UTOEvent event;
		int i=0;
		while(ros::ok()){
			GOON_OR_RETURN;
			if(i == 10) {
				pubEventMsg("finish_event");
			}
			ROS_INFO("[Test3Plugin] in actorID %ld actorName %s running for %d time", _actorID, _actorName.c_str(), i++);
			usleep(100000);
		}
	}
};
