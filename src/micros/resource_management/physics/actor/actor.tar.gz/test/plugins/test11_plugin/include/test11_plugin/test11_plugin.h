#ifndef __TEST11_PLUGIN__
#define __TEST11_PLUGIN__

#include "general_plugin/general_plugin.h"

namespace general_bus {
	class Test11Plugin: public GeneralPlugin {	
	public:
		/* virtual bool start();
		virtual bool pause();
		virtual bool stop();	 */
		virtual void start();
	};
}
#endif
