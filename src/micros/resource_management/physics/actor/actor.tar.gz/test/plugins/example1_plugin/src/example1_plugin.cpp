#include "example1_plugin/example1_plugin.h"
#include <pluginlib/class_list_macros.h>
#include "ros/ros.h"

PLUGINLIB_EXPORT_CLASS(general_bus::Example1Plugin,general_bus::GeneralPlugin)

namespace general_bus {
	Example1Plugin::Example1Plugin(){
		_sub = new RTPSSubscriber<UTOEventTransition>("/uto_event_transition", &Example1Plugin::eventTransitionCallback, this);
		// _pub = new RTPSPublisher<UTOEventTransition>("/uto_event_sync");
	}

	Example1Plugin::~Example1Plugin(){
		if(_sub){
			delete _sub;
		}
	}

	void Example1Plugin::eventTransitionCallback(UTOEventTransition &msg){
		ROS_INFO("[Example1Plugin] Receive uto msg by FastRTPS: currentActor:%s eventName:%s on robot %ld", msg.currentActor().c_str(), msg.eventName().c_str(), msg.robotId());
	}

	void Example1Plugin::start(){
		//GOON_OR_RETURN;
		i = 0;
		std::string tempStr;
    //getActorName(_actorID,tempStr);
		while(ros::ok()){
			GOON_OR_RETURN;
			i++;
			// UTOEventTransition transition;
            // transition.currentActor(tempStr);
            // transition.eventName("default");
            // transition.syncStatus(-1);
            // transition.robotId(i);
			// _pub->publish(transition);
			ROS_INFO("[Example1 Plugin] in actorID %ld actorName %s running on cpu %d for %d time",_actorID,tempStr.c_str(),sched_getcpu(),i);
			sleep(_duration);
		}

		// std::string switchStr = "Transmitter";
		// activateActor(_actorID, switchStr);

		// while(i < 10){
		// 	GOON_OR_RETURN;
		// 	i++;
		// 	ROS_INFO("[Example1 Plugin] in actorID %ld actorName %s running on cpu %d for %d time",_actorID,tempStr.c_str(),sched_getcpu(),i);
		// 	sleep(_duration);
		// }

		// switchStr = "Follower";
		// switchToActor(_actorID, switchStr);

		// while(i < 15){
		// 	GOON_OR_RETURN;
		// 	i++;
		// 	ROS_INFO("[Example1 Plugin] in actorID %ld actorName %s running on cpu %d for %d time",_actorID,tempStr.c_str(),sched_getcpu(),i);
		// 	sleep(_duration);
		// }

		// switchStr = "Transmitter";
		// switchToActor(_actorID, switchStr);

		// switchStr = "Follower";
		// while (ros::ok()) {
		// 	i++;
		// 	GOON_OR_RETURN;
		// 	ROS_INFO("[Example1 Plugin] in actorID %ld actorName %s running on cpu %d for %d time",_actorID,tempStr.c_str(),sched_getcpu(),i);
		// 	if(i%5==0) activateActor(_actorID, switchStr);
		// 	sleep(_duration);
		// }
	}
};
