#include "actor_schedule/actor_schedule.h"
#include <ros/ros.h>


int main(int argc,char** argv) {
	// ros::init(argc,argv,"test_general_bus");
	// general_bus::GeneralBus observeBus("observe_bus");
	// general_bus::GeneralBus actBus("act_bus");
	// observeBus.loadPlugin("example1_plugin",1234);
	// observeBus.startPlugin("example1_plugin",1234);	
	// actBus.loadPlugin("example2_plugin",1234);
	// actBus.startPlugin("example2_plugin",1234);	
	// ros::spin();	
	return 0;
}

