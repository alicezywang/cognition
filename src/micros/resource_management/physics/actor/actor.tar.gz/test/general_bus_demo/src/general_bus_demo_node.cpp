#include "general_bus/general_bus.h"
#include <ros/ros.h>
#include "general_bus_demo/LoadPlugin.h"
#include "general_bus_demo/StartPlugin.h"

boost::shared_ptr<general_bus::GeneralBus> bus;

bool loadPluginCb(general_bus_demo::LoadPlugin::Request  &req,  
              general_bus_demo::LoadPlugin::Response &res)  {
	// if (bus->loadPlugin(req.pluginName.c_str(),req.actorID)) 
	// 	res.success=true;	
	return true;
}

bool startPluginCb(general_bus_demo::StartPlugin::Request  &req,  
              general_bus_demo::StartPlugin::Response &res)  {
	// if (bus->startPlugin(req.pluginName.c_str(),req.actorID)) 
	// 	res.success=true;		
	return true;
}


int main(int argc,char** argv) {
	// ros::init(argc,argv,"general_bus_demo_node");
	// ros::NodeHandle nh("~");
	// std::string busName("unknown_bus");
	// if (nh.hasParam("bus_name")) nh.getParam("bus_name",busName);
	// bus=boost::make_shared<general_bus::GeneralBus>(busName.c_str());
	// ros::ServiceServer loadPluginSrv=nh.advertiseService("loadPlugin",loadPluginCb);
	// ros::ServiceServer startPluginSrv=nh.advertiseService("startPlugin",startPluginCb);
	// ros::spin();	
	return 0;
}

