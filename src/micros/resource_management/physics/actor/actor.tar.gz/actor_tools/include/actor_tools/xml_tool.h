#ifndef __XML_TOOL__
#define __XML_TOOL__
#include <stdio.h>
#include "ros/ros.h"

//todo list 
//move the implementation to cpp 
void readFromXMLFile(std::string& filePath,std::string&content) {
	FILE *fin=fopen(filePath.c_str(),"r");
	if (fin==NULL) {
		ROS_FATAL("unable to find platform file %s",filePath.c_str());
	}
	//todo list
	//read the content to string
	fclose(fin);
}
#endif
