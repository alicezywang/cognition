#include "actor_schedule/actor_schedule.h"
#include "actor_schedule/actor_api.h"
#include <string.h>


int SHARED_DATA_SIZE=32768;
char* gPSharedData;
ActorScheduler *gPActorScheduler;

//get actor name by actor ID
/*
bool getActorName(int64_t anActorID,std::string &anActorName){
    if((gPActorScheduler==NULL)||(!gPActorScheduler)) return false;
    return gPActorScheduler->getActorNameByID(anActorID,anActorName);

}
*/
//get plugin pointer by pluginname
bool getActorPlugin(int64_t anActorID,std::string aPluginName,boost::shared_ptr<general_bus::GeneralPlugin> &aPluginStr){
    if((gPActorScheduler==NULL)||(!gPActorScheduler)) return false;
    return gPActorScheduler->getActorPlugin(anActorID,aPluginName,aPluginStr);
}

int getSharedData(char* aPData,int aSize) {
    if (aSize>SHARED_DATA_SIZE) {
        aSize=SHARED_DATA_SIZE;
    }
    memcpy(aPData,gPSharedData,aSize);
    return aSize;
}

int setSharedData(char* aPData,int aSize) {
    if (aSize>SHARED_DATA_SIZE) {
        aSize=SHARED_DATA_SIZE;
    }
    memcpy(gPSharedData,aPData,aSize);
    return aSize;
}

/*
bool switchToActor(int64_t anActorID,std::string anActorName){
    if((gPActorScheduler==NULL)||(!gPActorScheduler)) return false;
    return gPActorScheduler->switchToActor(anActorID,anActorName);
}
*/
void switchToActor(int64_t anActorID,std::string anActorName){
    ScheduleMsg scheMsg;
    scheMsg._type=SCHEDULE_CMD_SWITCH_PRIO;
    scheMsg._param1=anActorID;
    assert(anActorName.size()<SCHE_MSGS_CHAR_SIZE);
    strcpy(scheMsg._param3,anActorName.c_str());//,anActorName.size());
    scheMsg._param3[anActorName.size()]=0;
    gPActorScheduler->appendScheduleMsg(scheMsg);
}

void activateActor(int64_t anActorID,std::string anActorName){
    ScheduleMsg scheMsg;
    scheMsg._type=SCHEDULE_CMD_ACTIVATE_ACTOR;
    scheMsg._param1=anActorID;
    assert(anActorName.size()<SCHE_MSGS_CHAR_SIZE);
    strcpy(scheMsg._param3,anActorName.c_str());//,anActorName.size());
    scheMsg._param3[anActorName.size()]=0;
    gPActorScheduler->appendScheduleMsg(scheMsg);
}

void pauseActorApi(int64_t anActorID){
    ScheduleMsg scheMsg;
    scheMsg._type=SCHEDULE_CMD_YIELD_ACTOR;
    scheMsg._param1=anActorID;
    gPActorScheduler->appendScheduleMsg(scheMsg);
}

//quit actor
void appendScheduleRequest(int64_t anActorID){
    ScheduleMsg scheMsg;
    scheMsg._type=SCHEDULE_CMD_QUIT_ACTOR;
    scheMsg._param1=anActorID;
    gPActorScheduler->appendScheduleMsg(scheMsg);
}

int32_t getActorNumbers() {
    //TODO: return the number of single actors in the swarm actor
    return 0;
}

bool getFormation(int64_t anActorID, std::string &aFormationType, std::string &aFormationPos) 
{
    if( ( gPActorScheduler == NULL ) || ( !gPActorScheduler ) ) {
        return false;
    }
    return gPActorScheduler->getFormation(anActorID, aFormationType, aFormationPos);
}
