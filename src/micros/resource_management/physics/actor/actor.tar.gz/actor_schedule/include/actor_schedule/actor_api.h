#ifndef __ACTOR_API__
#define __ACTOR_API__


#include <string>
#include "boost/shared_ptr.hpp"

extern int SHARED_DATA_SIZE;

/*class declration*/
class ActorScheduler;


namespace general_bus {
    class GeneralPlugin;
}


/*global variable and functions*/
extern  ActorScheduler *gPActorScheduler;
//get actor name by actorID
//extern bool getActorName(int64_t anActorID,std::string &anActorName);
//get plugin pointer by pluginname 
extern bool getActorPlugin(int64_t anActorID,std::string aPluginName,boost::shared_ptr<general_bus::GeneralPlugin> &aPluginStr);
//get and set shareddata
 extern char* gPSharedData;
extern int getSharedData(char* aPData,int aSize);
extern int setSharedData(char* aPData,int aSize);
//switch actor
extern void switchToActor(int64_t anActorID,std::string anActorName);
//activate actor
extern void activateActor(int64_t anActorID,std::string anActorName);
//pause actor
void pauseActorApi(int64_t anActorID);
//quit actor
extern void appendScheduleRequest(int64_t anActorID);
//get formation info by actorID
extern bool getFormation(int64_t anActorID, std::string &aFormationType, std::string &aFormationPos);

#endif
