
// ros node for actor match test
#include "actor_match/actor_match.h"

int main(int argc, char **argv)
{
	ros::init(argc, argv, "actor_match");

	ActorMatcher actor_match("/home/dibin/actor_management_guo/actor_data/actor_match_test_db/robot_0.xml");
	actor_match.startService();
	
	/*TEST test the actor match service */
	
	
	
	/*TEST test the actor match getActorMatchInfo function */
  	ros::spin();

	  
	return 0;
}
