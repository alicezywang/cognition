#ifndef HUNGARYMATCH_H
#define HUNGARYMATCH_H


//#include <vector>
//#include "actor_data_types.h"
//#include <QtCore>
//#include <iostream>

//#define N 100

//using namespace std;

class HungaryMatch
{
/*public:
  HungaryMatch(){
    for(int i = 0 ; i < sizeof(b) ; i++)
    {
      b[i] = -1;
    }
    ActorSensorCount = PlatformSensorCount = 0;
  }
  void hungaryMatchInit();
  int v[N];
  int b[N];
  int Matrix_match[N][N];
  int ActorSensorCount;
  int PlatformSensorCount;

  bool DoHungaryMatch(vector<matchEdge> &XML_matchInfo);
  bool Hungary_find(int x);
*/
  /////////////////////////////////////////////////
public:
  HungaryMatch(int index_m, int index_n, int **matrix);
	~HungaryMatch();

	//m-actor sensor num, n-platform sensor num
	int m;
	int n;
	int *v;
	int *b;
	int **matrix_match;
  int doHungaryMatch(int* &match_result);
	bool hungaryFind(int x);



};

#endif // HUNGARYMATCH_H