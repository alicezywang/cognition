#include "actor_core/actor_types.h"
#include "actor_match/actor_match.h"
#include "task_bind/task_bind.h"
#include "actor_manager/actor_manager.h"
#include "actor_schedule/actor_schedule.h"
#include "ros/ros.h"
#include "actor_tools/xml_tool.h"
#include "tinyxml.h"
//consensus
#include "micros_swarm/micros_swarm.h"//vs only needed
#include "micros_swarm/serialize.h"
#include "micros_swarm/singleton.h"
#include "micros_swarm/runtime_handle.h"//rth 
#include "micros_swarm/runtime_core.h"

//#include "actor_election/actor_election.h"
#include "swarm_data_storage/swarm_data_storage.h"
#include "swarm_robot_heartbeat/swarm_robot_heartbeat_stigmergy.h"
#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler_simple.h"
#include "swarm_robot_heartbeat/swarm_robot_heartbeat_strategy_simple.h"
//#include "swarm_robot_heartbeat/swarm_robot_heartbeat_strategy_latency.h"
//#include "swarm_robot_heartbeat_handler/swarm_robot_heartbeat_handler_for_electionbids.h"

//#define DEBUG_FLAG   
#include "actor_tag_store/ActorTagStore.h"
#include "uto_task/uto_task.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

class ServiceInterface {
    virtual void startService()=0;
};

class DaemonApp: public ServiceInterface{
public:
    DaemonApp(ros::NodeHandle& nh,std::string& platformResourcesXMLContent,std::vector<boost::shared_ptr<general_bus::GeneralBus>> aBusVec,int32_t aPlatID) {
        this->_nh=nh;
        _pActorMatcher = new ActorMatcher(platformResourcesXMLContent);
        _pActorScheduler = boost::shared_ptr<ActorScheduler>(new ActorScheduler(aBusVec));

        _pUTOTask = new UTOTask(_pActorScheduler.get(), aPlatID);
        _pTaskBinder = new TaskBinder(_pActorMatcher, _pActorScheduler.get(), _pUTOTask, aPlatID);
       
        // _pActorCommand = new ActorCommand(_pActorMatcher,_pActorScheduler,aPlatformID);
        //_pActorElection = new ActorElection(aPlatID,_pActorScheduler);
        
        _pHeartbeatHandler = new SwarmRobotHeartbeatHandlerSimple(_pActorScheduler);
        _pHeartbeatStrategy = new SwarmRobotHeartbeatStrategySimple();
        //_pHeartbeatHandler = new SwarmRobotHeartbeatHandler_ForElectionBids(_pActorScheduler);
        //_pHeartbeatStrategy = new SwarmRobotHeartbeatStrategyLatency();
        _pHeartbeatStrategy->initHeatbeatHandler(_pHeartbeatHandler);
        _pHeartbeat = new SwarmRobotHeartbeat_Stigmergy();
        _pHeartbeat->initHeartbeatStrategy(_pHeartbeatStrategy);

        //_pActorManager = new ActorManager(_pActorScheduler,_pActorElection,aPlatID);
        _pActorManager = new ActorManager(_pActorScheduler.get());
        
    }

    ~DaemonApp() {
        if(_pUTOTask) {
            delete _pUTOTask;
           _pUTOTask = NULL;
        }
        if (_pTaskBinder) {
            delete _pTaskBinder;
           _pTaskBinder=NULL;
        }
        if (_pActorManager) {
            delete _pActorManager;
            _pActorManager=NULL;
        }
        // if (_pActorElection) {
        //     delete _pActorElection;
        //     _pActorElection=NULL;
        // }
        if (_pActorScheduler) {
            //delete _pActorScheduler;
            //_pActorScheduler=NULL;
            _pActorScheduler.reset();
        }
        if (_pActorMatcher) {
            delete _pActorMatcher;
            _pActorMatcher=NULL;
        }
        //
        if(_pHeartbeatHandler){
            delete _pHeartbeatHandler;
            _pHeartbeatHandler = NULL;
        }
        if(_pHeartbeatStrategy){
            delete _pHeartbeatStrategy;
            _pHeartbeatStrategy = NULL;
        }
        if(_pHeartbeat){
            delete _pHeartbeat;
            _pHeartbeat = NULL;
        }
        
    }

    void startService() {
        _pActorScheduler->start();
        #ifndef DEBUG_FLAG
        _pActorMatcher->startService();
        #endif
        _pTaskBinder->start0();
        _pUTOTask->start();
        //
        //_pActorElection->start();
        _pHeartbeat->run();
        //_pActorManager->start();
        
    }

    ros::NodeHandle _nh;
    ActorMatcher* _pActorMatcher;
    TaskBinder* _pTaskBinder;
    UTOTask *_pUTOTask;
    ActorManager* _pActorManager;
    // ActorScheduler* _pActorScheduler;
    boost::shared_ptr<ActorScheduler> _pActorScheduler;
    //election
    //ActorElection* _pActorElection;

    SwarmRobotHeartbeat* _pHeartbeat;
    SwarmRobotHeartbeatStrategy* _pHeartbeatStrategy;
    SwarmRobotHeartbeatHandler* _pHeartbeatHandler;

};

//consensus
/* ros::Timer timer1,timer2;
micros_swarm::VirtualStigmergy vs;
boost::shared_ptr<micros_swarm::RuntimeHandle> rth;

double x = 0;
double y = 0;


    void loop_puts(const ros::TimerEvent&)
    {
        std::string robot_id_string = "robot_"+boost::lexical_cast<std::string>(rth->getRobotID());

        static int count = 0;
        std_msgs::Int32 pval;
        //pval.data = get_id() + count;
        pval.data = rth->getRobotID();
        vs.put<std_msgs::Int32>(robot_id_string, pval);

        count=count+rth->getRobotID();
        if (count==101)
        	count=0;

        micros_swarm::Base l(count, count, count, 0, 0, 0, 1);
        rth->setRobotBase(l);
        //std::cout<<robot_id_string<<": "<<vs.size()<<std::endl;
        //vs.print();
        /*static bool flag = true;
        if(flag) {
            if(vs.size() == 60) {
                std::cout<<get_id()<<" get all tuple"<<std::endl;
                flag = false;
            }
        }*/ /*
    }

    void loop_gets(const ros::TimerEvent&)
    {
        std::string robot_id_string = "robot_" + boost::lexical_cast<std::string>(rth->getRobotID());
        std_msgs::Int32 gval;
        //int lamport_clock;
        if(!vs.get<std_msgs::Int32>(robot_id_string,gval))
        	return;
        //std::cout << robot_id_string << ": " << vs.size() << ", " << gval.data << ", " << lamport_clock << std::endl;
        vs.print();
        std::map<std::string, micros_swarm::VirtualStigmergyTuple> vs_map;
        vs.get_vs(vs_map);

        std_msgs::Int32 temp=micros_swarm::deserialize_ros<std_msgs::Int32>(vs_map[robot_id_string].vstig_value);
        std::cout << robot_id_string << ": " <<  vs_map[robot_id_string].lamport_clock << ", " <<temp.data << std::endl;
    }
 */

int main(int argc,char** argv) {
    //micROS::init();
    ros::init(argc,argv,"actor_main");
    ros::NodeHandle nh;
    ros::NodeHandle privNh("~");
    
    // fastrtps participant discovery list 
    std::string strRobotListFile="";
    if (nh.hasParam("/robotListFile")) {
        nh.getParam("/robotListFile",strRobotListFile); 
    } else {
        ROS_WARN("cannot find robotListFile in the parameter server");
    }
    
    micROS::init(strRobotListFile);

    if (!gActorTagStore.init()) {
		std::cout<<"FATAL: unable to get the actorName to tag mapping!"<<std::endl;
		return 1;
	}    

    std::string platformResourcesFileName;
    platformResourcesFileName = "/home/gjl/micros_ws/micros_actor/src/micros/behavior_management/actor/test_data/robot_0.xml";
    //platformResourcesFileName = "/home/captain/code_server/phy_code_server/micros_actor/src/micros/behavior_management/actor/test_data/robot_0.xml";
    
    if (nh.hasParam("PlatformResourcesFile")) {
        nh.getParam("PlatformResourcesFile",platformResourcesFileName); 
    } else {
        ROS_WARN("cannot find PlatformResourcesFile in the parameter server");
    }

    //platID
    int32_t platID = -1;
    if (privNh.hasParam("robot_id")) {
        privNh.getParam("robot_id",platID); 
    } else {
        ROS_WARN("[Daemon Node]cannot find robot ID in the parameter server, return..");
        return 0;
    }

    std::string logFilePath = "";
    if (nh.hasParam("/ActorLogFileDir")) {
        nh.getParam("/ActorLogFileDir",logFilePath); 
    } else {
        std::cout<<"WARNING:cannot find actor election data file dir in the parameter server"<<std::endl;
    }
    
    //SwarmDataStorage::instance()->setLocalRobotID(platID);
    SwarmDataStorage::instance()->init(platID, logFilePath);
    ROS_INFO("[Daemon Node] robotID=%d", platID);
    
    //TODO: move to DaemaonApp constructor
    boost::shared_ptr<general_bus::GeneralBus> pObserveBus(new general_bus::GeneralBus("observe_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pOrientBus(new general_bus::GeneralBus("orient_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pDecideBus(new general_bus::GeneralBus("decide_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pActBus(new general_bus::GeneralBus("act_bus"));
    std::vector<boost::shared_ptr<general_bus::GeneralBus>> busVec;
    busVec.push_back(pObserveBus);
    busVec.push_back(pOrientBus);
    busVec.push_back(pDecideBus);
    busVec.push_back(pActBus);
    
    /*  
    TiXmlDocument doc;
    std::string xmlStr;
    if (!doc.LoadFile(platformResourcesFileName)) {
	    ROS_FATAL("[Actor Daemon Node]Error while open the platform resource XML file!");
    } else {
        TiXmlPrinter printer;
        doc.Accept(&printer);
        xmlStr = printer.CStr();
    } 
    std::string platformResourcesXMLContent;
    platformResourcesXMLContent = xmlStr;


    */
    //consensus information

    boost::shared_ptr<micros_swarm::RuntimeCore> rtp_core_;

    rtp_core_.reset(new micros_swarm::RuntimeCore());
    rtp_core_->initialize();

    //micros_swarm::VirtualStigmergy vs;
    
	//vs=micros_swarm::VirtualStigmergy(3);
    //may be global
    boost::shared_ptr<micros_swarm::RuntimeHandle> rth;
	rth = micros_swarm::Singleton<micros_swarm::RuntimeHandle>::getSingleton();   

    //timer1 = nh.createTimer(ros::Duration(2), &loop_puts);
    //timer2 = nh.createTimer(ros::Duration(3), &loop_gets);
    

    DaemonApp daemonApp(nh,platformResourcesFileName,busVec,platID);
    daemonApp.startService();
    //ros::spin();
    boost::thread t = boost::thread(boost::bind(&ros::spin));
    t.join();    

    for(std::vector<boost::shared_ptr<general_bus::GeneralBus> >::iterator it= busVec.begin();it!=busVec.end();it++){
        (*it).reset();
    }


    micROS::finish();
    return 0;
}
