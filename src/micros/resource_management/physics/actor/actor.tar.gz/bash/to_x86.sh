find ../ -name "*.cpp" -exec sed -i 's/\%lld/\%ld/g' {} \;
find ../ -name "general_plugin.h" -exec sed -i 's/\%lld/\%ld/g' {} \;
