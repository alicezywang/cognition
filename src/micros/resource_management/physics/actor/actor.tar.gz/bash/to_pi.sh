find ../ -name "*.cpp" -exec sed -i 's/\%ld/\%lld/g' {} \;
find ../ -name "general_plugin.h" -exec sed -i 's/\%ld/\%lld/g' {} \;
