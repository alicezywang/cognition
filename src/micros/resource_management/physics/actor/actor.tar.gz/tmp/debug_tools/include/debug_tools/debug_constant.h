#ifndef __DEBUG_CONSTANT__
#define __DEBUG_CONSTANT__

//#define DEBUG_FLAG

#endif
