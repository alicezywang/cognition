// ros node for actor match test
#include "task_bind/task_bind.h"
#include "tinyxml.h"
#include "actor_core/actor_core.h"
#include <iostream>

#define DEBUG_FLAG

using namespace std;

int main(int argc, char **argv)
{
	ros::init(argc, argv, "pseudo_client");

	ros::NodeHandle nh_;
	#ifndef DEBUG_FLAG
	ros::service::waitForService("/actor_main/actor_match");
	ros::ServiceClient client1 = nh_.serviceClient<actor_msgs::actor_match>("/actor_main/actor_match");
	#endif
	ros::service::waitForService("/actor_main/task_bind_service");
	ros::ServiceClient client2 = nh_.serviceClient<actor_msgs::task_bind>("/actor_main/task_bind_service");

	// TEST condition 1
	string temp = "/home/captain/code_server/physical_experiment/src/micros/behavior_management/actor/test_data/swarm_test_task1-";
	TiXmlDocument doc2;
	string XmlStr2;
	{
		for (int i=1; i<=8; i++) {
			stringstream ss;
			string str;
			ss << i;
			ss >> str;
			string filePath = temp + str + ".xml";
			cout << filePath << endl;
			actor_msgs::task_bind srv2;
			if ( !doc2.LoadFile(filePath) )
			{
				ROS_ERROR("[Pseudo Client Node] Error while open XML file!");
			}
			else
			{
				TiXmlPrinter printer2;
				doc2.Accept(&printer2);
				XmlStr2 = printer2.CStr();
			}
			srv2.request.str = XmlStr2;
			if (client2.call(srv2))
			{
				ROS_INFO("[Pseudo Client Node] Call task_bind client request");
				if (srv2.response.bind)
				{
					ROS_INFO("[Pseudo Client Node] Bind and generate ACB!");
				}
			}
			else
			{
				ROS_ERROR("[Pseudo Client Node] Failed to call service task_bind");
				return 1;
			}
			sleep(7);
		}
	}

	return 0;
}
