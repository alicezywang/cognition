#include <string>
#include "actor_core/actor_types.h"
#include "actor_match/actor_match.h"
#include "task_bind/task_bind.h"
#include "actor_schedule/actor_schedule.h"
#include "actor_manager/actor_manager.h"
#include "ros/ros.h"
#include "actor_tools/xml_tool.h"
#include "tinyxml.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"
#include "micROSRTPSExt.h"

using namespace std;

class ServiceInterface2 {
    virtual void startService()=0;
};

class DaemonApp2: public ServiceInterface2{
public:
    DaemonApp2(ros::NodeHandle& nh,std::string& platformResourcesXMLContent,std::vector<boost::shared_ptr<general_bus::GeneralBus>> aBusVec, int64_t aPlatformID) {
        this->_nh = nh;
        _pActorMatcher = new ActorMatcher(platformResourcesXMLContent);
        _pActorScheduler = new ActorScheduler(aBusVec);
        _pTaskBinder = new TaskBinder(_pActorMatcher,_pActorScheduler,aPlatformID);
        _pActorManager = new ActorManager(_pActorScheduler);
    }

    ~DaemonApp2() {
        if (_pTaskBinder) {
            delete _pTaskBinder;
            _pTaskBinder=NULL;
        }
        if (_pActorScheduler) {
            delete _pActorScheduler;
            _pActorScheduler=NULL;
        }
        if (_pActorMatcher) {
            delete _pActorMatcher;
            _pActorMatcher=NULL;
        }
        if (_pActorManager) {
            delete _pActorManager;
            _pActorManager=NULL;
        }
    }

    void startService() {
        _pActorScheduler->start();
        _pActorMatcher->startService();
        _pTaskBinder->start0();
        _pActorManager->start();
    }

    ros::NodeHandle _nh;
    ActorMatcher* _pActorMatcher;
    TaskBinder* _pTaskBinder;
    ActorScheduler* _pActorScheduler;
    ActorManager* _pActorManager;
};

int main(int argc,char** argv) {

    micROS::init();

    // if (argc!=2) {
	// 	//ROS_INFO("usage: rosrun actor_daemon_node2 actor_daemon_node2 YOUR_TASK_FILE_PATH");
    //     cout << "usage: rosrun actor_daemon_node2 actor_daemon_node2 YOUR_TASK_FILE_PATH" << endl;
	// 	return 0;
	// }   

    std::string platformResourcesFileName;
    platformResourcesFileName = argv[1];
    // std::string platformResourcesFileName;
    // platformResourcesFileName = "/home/captain/platform1.xml";

    cout << platformResourcesFileName << endl;
    // test: get platformID through platform file name
    std::string temp = platformResourcesFileName.substr(platformResourcesFileName.length()-5,1);
    int64_t platformID = atoll(temp.c_str());

    std::string localNodeName = "platform" + temp;

    ros::init(argc,argv,localNodeName);
    ros::NodeHandle nh;
    
    if (nh.hasParam("PlatformResourcesFile")) {
        nh.getParam("PlatformResourcesFile",platformResourcesFileName); 
    } else {
        //ROS_WARN("cannot find PlatformResourcesFile in the parameter server");
       cout << "[INFO] cannot find Platform Resource File in the parameter server" << endl;
    }
       
    boost::shared_ptr<general_bus::GeneralBus> pObserveBus(new general_bus::GeneralBus("observe_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pOrientBus(new general_bus::GeneralBus("orient_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pDecideBus(new general_bus::GeneralBus("decide_bus"));
    boost::shared_ptr<general_bus::GeneralBus> pActBus(new general_bus::GeneralBus("act_bus"));

    std::vector<boost::shared_ptr<general_bus::GeneralBus>> busVec;
    busVec.push_back(pObserveBus);
    busVec.push_back(pOrientBus);
    busVec.push_back(pDecideBus);
    busVec.push_back(pActBus);

    DaemonApp2 daemonApp2(nh,platformResourcesFileName,busVec,platformID);
    
    daemonApp2.startService();
    
    ros::spin();

    micROS::finish();
    return 0;
}
