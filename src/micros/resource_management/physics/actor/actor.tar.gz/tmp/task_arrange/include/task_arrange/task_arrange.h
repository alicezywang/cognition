#ifndef __TASK_ARRANGER__
#define __TASK_ARRANGER__

#include "actor_match/actor_match.h"
#include "ros/ros.h"
#include "actor_msgs/actor_match.h"
#include "actor_msgs/task_arrange.h"
#include <string>
#include <tinyxml.h>

using namespace std;

class TaskArranger {
public:
	TaskArranger(ActorMatcher* aPActorMatcher);
	void startService();
	
	ActorMatcher* pActorMatcher;		

private:
	ros::NodeHandle nh_;
	ros::ServiceServer task_arrange_server;
	bool callArrangeService(actor_msgs::task_arrange::Request  &req, actor_msgs::task_arrange::Response &res);
};

#endif