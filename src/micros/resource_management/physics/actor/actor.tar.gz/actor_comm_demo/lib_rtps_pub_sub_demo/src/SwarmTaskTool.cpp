#include "SwarmTaskTool.h"

#include "RTPSPublisher.h"
#include "RTPSSubscriber.h"

#include "SwarmTask.h"
#include "micROSRTPSExt.h"

void hello(SwarmTask& aMsg) {
	std::cout<<"hello() msg="<<aMsg.xmlStr()<<std::endl;
}

void SwarmTaskTool::startPub() {
	RTPSPublisher<SwarmTask>  mypub("SwarmTask");
	if (mypub.init()) {
		SwarmTask newTask;
		int i=0;
		while (true) {	
			char ch[128];
			sprintf(ch,"%d",i++);
			newTask.xmlStr("This is a task with ID "+std::string(ch));
			mypub.publish(newTask);
			sleep(1);
		}
	}
}

void SwarmTaskTool::startSub() {	
	RTPSSubscriber<SwarmTask> mysub("SwarmTask",hello);
	if (mysub.init())
	{
		while (true) {
			sleep(1);
		}
	}
}



SwarmTaskTool::SwarmTaskTool() {
}


