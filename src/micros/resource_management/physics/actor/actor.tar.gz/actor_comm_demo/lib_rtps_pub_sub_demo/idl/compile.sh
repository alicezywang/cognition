fastrtpsgen -example x64Linux2.6gcc SwarmTask.idl
