#ifndef __SWARM_TASK_TOOL__
#define __SWARM_TASK_TOOL__
class SwarmTaskTool {
public:
	SwarmTaskTool();
	void startPub();
	void startSub();
};

#endif
