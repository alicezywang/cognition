#include "SwarmTaskTool.h"
#include "micROSRTPSExt.h"

int main() {
	micROS::init();
	SwarmTaskTool tool;
	tool.startSub();
	micROS::finish();
}

