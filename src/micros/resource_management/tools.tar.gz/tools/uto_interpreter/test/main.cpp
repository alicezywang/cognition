#include <ros/ros.h>
#include "uto_interpreter/uto_interpreter_api.h"
#include <QDebug>

int main(int argc,char** argv) {
    
    ros::init(argc,argv,"uto_interpreter_node");

    QString bitStrFromXml;
    utobits::UTOTask destFromBitStr;

    std::string strXmlFilePath = "/home/micros/micros_orient_merge/src/orient/plugins/micros_ui_plugins/panel_plugins/uto_transfer_panel/resources/task_ultimate.xml";
    std::string strUtoCfgFilePath = "/home/micros/micros_orient_merge/src/other_softbus_dens/uto_interpreter/config/utoconfig.xml";

    UTOCodec *pUTOCodec = new UTOCodec();
    bitStrFromXml = pUTOCodec->encodeToBits(strXmlFilePath, strUtoCfgFilePath);
    qDebug() << "*************************************";
    qDebug() << "*****encode: Bit Stream**************";
    qDebug() << "*************************************";
    qDebug() << bitStrFromXml;

    pUTOCodec->decodeFromBits(bitStrFromXml, destFromBitStr);


    /*qDebug() << "*************************************";
    qDebug() << "***decode: struct UTOTask************";
    qDebug() << "*************************************";
    std::cout << "task_id:" << destFromBitStr._taskID<<std::endl;
    std::cout << "task_name:" << destFromBitStr._taskName<<std::endl;
    std::cout << "task_prior:" << destFromBitStr._taskPrio<<std::endl;
     for(int i=0;i<destFromBitStr._utoConfig.size();i++)
     {
         std::cout << "actor_name:" << destFromBitStr._utoConfig.at(i)._actorName<<std::endl;
         for(int j=0;j<destFromBitStr._utoConfig.at(i)._paramList.size();j++)
         {
             std::cout << "param_name:" << destFromBitStr._utoConfig.at(i)._paramList.at(j)._key<<std::endl;
             std::cout << "param_value:" << destFromBitStr._utoConfig.at(i)._paramList.at(j)._value<<std::endl;
         }
         for(int j=0;j<destFromBitStr._utoConfig.at(i)._eventList.size();j++)
         {
//             std::cout << "j:" << j;
             std::cout << "transition_name:" << destFromBitStr._utoConfig.at(i)._eventList.at(j)._eventName<<std::endl;
             std::cout << "sysnum:" << destFromBitStr._utoConfig.at(i)._eventList.at(j)._sysNum<<std::endl;
             std::cout << "barrierkey:" << destFromBitStr._utoConfig.at(i)._eventList.at(j)._barrierKey<<std::endl;
             std::cout << "successor:" << destFromBitStr._utoConfig.at(i)._eventList.at(j)._nextActor<<std::endl;
         }
     }
     for(int i=0;i<destFromBitStr._platformConfig.size();i++)
     {
         std::cout<< "initial actor:" << destFromBitStr._platformConfig[i]._initialActor<<std::endl;
         for(int j=0;j<destFromBitStr._platformConfig.at(i)._platformList.size();j++)
         {
    //         std::cout << "j:" << j;
             std::cout << "platformlist:" << destFromBitStr._platformConfig.at(i)._platformList.at(j)<<std::endl;
         }
     }
     */
    return 0;
}
