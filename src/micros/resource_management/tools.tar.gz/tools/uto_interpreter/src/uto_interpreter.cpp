#include <stdio.h>
#include <QtCore/qmath.h>
#include <QDebug>
#include "uto_interpreter/internal/uto_interpreter.h"
#include <QFile>

XMLbit:: XMLbit()
{
    // ros::NodeHandle nh;
    // std::string strFile = "";
    // if (nh.hasParam("/UtoConfigXml")) {
    //     nh.getParam("/UtoConfigXml", strFile); 
    // } else {
    //     ROS_WARN("cannot find /UtoConfigXml in the parameter server");
    // }
    
    std::string strUTO = "/home/ubuntu/catkin_ws/src/uto_interpreter/config/utoconfig.xml";
    QString strUTOConfigFilePath = QString::fromStdString(strUTO);
    QFile utoconfigfile(strUTOConfigFilePath);

    DomXML *mDomXML = new DomXML();
    // QFile utoconfigfile(QString::fromStdString(strFile));
    mDomXML->DomReadUTOConfigXMLFile(mDomXML->mstructUTOConfig, &utoconfigfile);
    sUTOConfig = mDomXML->mstructUTOConfig;
    delete mDomXML;

    sHeader.msgStandard = 1;
    sHeader.version = 0;
    sHeader.msgType = 1;
    countParam = 0;
}

XMLbit:: ~XMLbit()
{

}

QList<char> XMLbit:: fromByte2Bit(int src, QList<char> dest, int len)
{
//    qDebug() << __FUNCTION__;
    QString strSrc = QString::number(src, 2);
//    qDebug() << "strSrc" << strSrc;
//    qDebug() << "strSrc.length()" << strSrc.length();
    if(!dest.isEmpty())
    {
        dest.clear();
    }
    if(strSrc.length() < len)
    {
        for(int i=0; i<len - strSrc.length();i++)
        {
            dest.append('0');
        }
        for(int i=0;i<strSrc.length();i++)
        {
            dest.append(strSrc.toStdString().at(i));
        }
//        qDebug() << "dest" << dest;
    }
    else
    {
        for(int i=0;i<strSrc.length();i++)
        {
            dest.append(strSrc.toStdString().at(i));
        }
        for(int i=0;i<strSrc.length() - len;i++)
        {
            dest.removeFirst();
        }
//        qDebug() << "dest" << dest;
    }
    return dest;
}

QList<char> XMLbit:: fromByte2Bit(double src, QList<char> dest, int len, double range)
{
    double delta = range/1.0/(qPow(2,len));
    int srcInt = qFloor(src/delta+0.5);
    // qDebug() << "srcInt" << srcInt;
    dest = fromByte2Bit(srcInt, dest, len);
    return dest;
}

void XMLbit:: mergeCharList()
{
//    qDebug() << "listChar1" << listChar1;
    // qDebug() << "listChar2" << listChar2;
    listChar1.append(listChar2);
//    qDebug() << "listChar1" << listChar1;
}

void XMLbit:: addField(int src, int len)
{
    listChar2 = fromByte2Bit(src, listChar2, len);
    mergeCharList();
}

void XMLbit:: addField(double src, int len, double range)
{
    listChar2 = fromByte2Bit(src, listChar2, len, range);
    mergeCharList();
}

void XMLbit:: encodeToBit(utobits::iTask srcTask)
{
    // qDebug() << "*************************************";
    // qDebug() << "************FAH encode***************";
    // qDebug() << "*************************************";
    listChar1 = fromByte2Bit(sHeader.msgStandard, listChar1, 2);
    // qDebug() << "listChar1" << listChar1;
    addField(sHeader.version, 2);
    addField(sHeader.msgType, 2);
//    listChar1.append('1');      // task is enabled default
//    listChar1.append('0');      // only one task is configured in current XML
    addField(1, 1);             // G1:task is enabled default
    addField(0, 1);             // R1:only one task is configured in current XML
    addField(srcTask.task_id, 4);
    addField(srcTask.task_name, 6);
    addField(srcTask.task_prior, 4);


    int i = 0;
    int lenActor = srcTask.utoconfig.length();
    if(lenActor==0)
    {
        exit(-1);                          // error! because there must exist initial actor
    }
    else
    {
        if(lenActor==1)
        {
            addField(0, 1);               // R2:disabled the repeat flag for actor
        }
        else
        {
            addField(1, 1);               // R2:enabled the repeat flag for actor
        }
        while(i<lenActor)                 //R2 Circulation
        {
            addField(srcTask.utoconfig.at(i).actor_name, 8);           //角色
            int j = 0;
            int lenParam = srcTask.utoconfig.at(i).params.length();
            if(lenParam==0)
            {
                addField(0, 1);                   //G2
            }
            else 
            {
                addField(1, 1);                   //G2
                if(lenParam==1)
                {            
                    addField(0, 1);               //R3
                }
                else
                {
                    addField(1, 1);               //R3
                }
                while(j<lenParam)                 //R3 Circulation
                {
                    addField(srcTask.utoconfig.at(i).params.at(j).param_name, 8);

                    int k = 0;
                    int lenValue = srcTask.utoconfig.at(i).params.at(j).param_value.length();
                    if(lenValue == 1)
                    {
                        addField(0, 1);               //R4
                    }
                    else
                    {
                        addField(1, 1);               //R4
                    }
                    while(k<lenValue)                 //R4 Circulation
                    {
                        int n = srcTask.utoconfig.at(i).params.at(j).param_value.at(k);
                        if(n != 0)
                        {
                            n = log(abs(n))/log(2) + 2;
                        }
                        else
                        {
                            n = 2;
                        }
                            
                        if (n<32)
                        {
                            addField(n, 5);
                            addField(srcTask.utoconfig.at(i).params.at(j).param_value.at(k), n);
                        }
                        else
                        {
                            qDebug() << "Max size of Param value is 32 bit!";
                            exit(-1);
                        }
                            
                        k = k+1;
                        if(k==lenValue-1)
                        {
                            addField(0, 1);             //R4
                        }
                        else if(k==lenValue)
                        {
                            // do nothing
                        }
                        else
                        {
                            addField(1, 1);             //R4
                        }
                    }
                    
                    j = j+1;
                    if(j==lenParam-1)
                    {
                        addField(0, 1);             //R3
                    }
                    else if(j==lenParam)
                    {
                        // do nothing
                    }
                    else
                    {
                        addField(1, 1);             //R3
                    }
                
                }//endwhile(j)
                                                
            }//endelse

            j = 0;
            int lenTransition = srcTask.utoconfig.at(i).transitions.length();
            if(lenTransition==0)
            {
                addField(0, 1);               //G3
            }
            else
            {
                addField(1, 1);               //G3
                if(lenTransition==1)
                {
                    addField(0, 1);           //R5
                }
                else
                {
                    addField(1, 1);           //R5
                }
                while(j<lenTransition)        //R5 Circulation
                {
                    addField(srcTask.utoconfig.at(i).transitions.at(j).transition_name, 8);
                    if(srcTask.utoconfig.at(i).transitions.at(j).sysnum==-1)
                    {
                        addField(0, 1);           //G4
                    }
                    else
                    {
                        addField(1, 1);           //G4
                        addField(srcTask.utoconfig.at(i).transitions.at(j).sysnum, 10);
                    }
                    if(srcTask.utoconfig.at(i).transitions.at(j).barrierkey==-1)
                    {
                        addField(0, 1);           //G5
                    }
                    else
                    {
                        addField(1, 1);          //G5
                        addField(srcTask.utoconfig.at(i).transitions.at(j).barrierkey, 6);
                    }
                    addField(srcTask.utoconfig.at(i).transitions.at(j).successor, 8);

                    j = j+1;
                    if(j==lenTransition-1)
                    {
                        addField(0, 1);         //R5
                    }
                    else if(j==lenTransition)
                    {
                        // do nothing
                    }
                    else
                    {
                        addField(1, 1);         //R5
                    }
                }
            }

            i = i+1;
            if(i==lenActor-1)
            {
                addField(0, 1);             //R2
            }
            else if (i==lenActor)
            {
                // do nothing
            }
            else
            {
                addField(1, 1);             //R2
            }

        }//endwhile
    }//endelse

        // the initial actor must be a list, modified by zyp@20190513
        // the enabled flag is converted to repeat flag
        int lenPlatActorConfigList = srcTask.platformactorconfig.length();
        i = 0;
        if(lenPlatActorConfigList==0)
        {
            exit(-1);   // error! the initial actor is not configed
        }
        else
        {
            if(lenPlatActorConfigList==1)
            {
                addField(0, 1);     //R6
            }
            else
            {
                addField(1, 1);     //R6
            }
            while(i<lenPlatActorConfigList)  //R6 Circulation
            {
                addField(srcTask.platformactorconfig.at(i).initialactor_name, 8);
                int j = 0;
                int lenPlatList = srcTask.platformactorconfig.at(i).platformlist.length();
                if(lenPlatList==0)
                {
                    exit(-1);   // error! no platform is configed
                }
                else if(lenPlatList==1)
                {
                    addField(0, 1);         //R7
                }
                else
                {
                    addField(1, 1);         //R7
                    while(j<lenPlatList)
                    {
                        addField(srcTask.platformactorconfig.at(i).platformlist.at(j), 16);
                        j = j+1;
                        if(j==lenPlatList-1)
                        {
                            addField(0, 1);         //R7
                        }
                        else if (j==lenPlatList)
                        {
                            // do nothing
                        }
                        else
                        {
                            addField(1, 1);         //R7
                        }
                    }
                }
                i = i+1;
                if(i==lenPlatActorConfigList-1)
                {
                    addField(0, 1);         //R6
                }
                else if (i==lenPlatActorConfigList)
                {
                    // do nothing
                }
                else
                {
                    addField(1, 1);         //R6
                }
            }
        }

    for(int i=0; i<listChar1.length();i++)
    {
        taskBitString.append(listChar1.at(i));
    }
    // qDebug() << "taskBitString" << taskBitString;
}

void XMLbit:: decodeFromBit(QString src)
{
    // qDebug() << "*************************************";
    // qDebug() << "************FAH decode***************";
    // qDebug() << "*************************************";
    charLen = src.length();
    charPos = 0;
    QString strField;
    if(charPos>charLen) return;
    strField = src.mid(charPos, 2);
    // qDebug() << "standard catagory:" << strField.toInt(0, 2);
    charPos = charPos+2;                    // use 2 bit first, then move right with 2 bit
    if(charPos>charLen) return;
    strField = src.mid(charPos, 2);
    // qDebug() << "standard version:" << strField.toInt(0, 2);
    charPos = charPos+2;
    if(charPos>charLen) return;
    strField = src.mid(charPos, 2);
    // qDebug() << "message type:" << strField.toInt(0, 2);
    charPos = charPos+2;
    if(charPos>charLen) return;
    strField = src.mid(charPos, 1);
    // qDebug() << "task enabled:" << strField.toInt(0, 2);
    charPos = charPos+1;

    if(strField.toInt()!=1)
    {
        qDebug() << "ERROR, the task enabled indication is not 1!";
        exit(-1);
    }
    else
    {
        strField = src.mid(charPos, 1);
        // qDebug() << "task repeat:" << strField.toInt(0, 2);     // no repeat, only one task supported!
        charPos = charPos+1;
        mTaskInfo = new TaskInfo(this, src);
    }

    // qDebug() << "charLen:" << charLen;
    // qDebug() << "charPos:" << charPos;
    if(charLen==charPos)
    {
        // qDebug() << "decode process finished successfully!";
    }
}

// timeout=0, to be done
void XMLbit::decodeFromBits(QString src, utobits::UTOTask &dest)
{
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii 6666666"<<std::endl;
    decodeFromBit(src);
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii 000000 "<<mTaskInfo->taskName<<std::endl;
    dest._taskID = mTaskInfo->taskID;
    dest._taskName = sUTOConfig.planNameIndexMap.key(mTaskInfo->taskName).toStdString();
    dest._taskPrio = mTaskInfo->taskPri;
    
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii 000000 "<<dest._taskName<<std::endl;
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii 111"<<std::endl;
    for(int i=0;i<mTaskInfo->listActorInfo.length();i++)
    {
        utobits::UTOActorNode sUTOActorNode;
        const ActorInfo &nowActor=mTaskInfo->listActorInfo.at(i);
        sUTOActorNode._actorName = sUTOConfig.actorIndexMap.key(
                    nowActor.actorName).toStdString();
        
        sUTOActorNode._paramList.clear();
        for(int j=0;j<nowActor.listActorParam.length();j++)
        {
            utobits::UTOActorParam sUTOActorParam;
            // std::cout<<"aaaaaaaaaaaaaaaaaaaaaaa"<<nowActor.listActorParam.at(j).paramName<<std::endl;
            sUTOActorParam._key = sUTOConfig.paramIndexMap.key(
                        nowActor.listActorParam.at(j).paramName).toStdString();
            QString valueStr;
            QString tempStr;
            int flagExist = 1;
            for(int k=0;k<nowActor.listActorParam.at(j).paramValue.length();k++)
            {
                if(nowActor.listActorParam.at(j).paramValue.at(k)==-1)
                {
                    flagExist = 0;
                    break;
                }
                tempStr=QString::number(nowActor.listActorParam.at(j).paramValue.at(k));
                valueStr.append(tempStr);
                valueStr.append(' ');
            }
            if(flagExist)
            {
                sUTOActorParam._value = valueStr.toStdString();
                sUTOActorNode._paramList.push_back(sUTOActorParam);
            }           
        }
        
        sUTOActorNode._eventList.clear();
        for(int j=0;j<nowActor.listTransitionInfo.length();j++)
        {
            utobits::UTOTransition sUTOTransition;
            sUTOTransition._eventName = sUTOConfig.transitionEventIndexMap.key(
                    nowActor.listTransitionInfo.at(j).transition_name).toStdString();
            sUTOTransition._nextActor = sUTOConfig.actorIndexMap.key(
                    nowActor.listTransitionInfo.at(j).successor).toStdString();
            sUTOTransition._sysNum = nowActor.listTransitionInfo.at(j).sysnum;
            sUTOTransition._barrierKey = nowActor.listTransitionInfo.at(j).barrierkey;
            sUTOActorNode._eventList.push_back(sUTOTransition);
        }

        dest._utoConfig.push_back(sUTOActorNode);
    }
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii 222222"<<std::endl;
    
    for(int i=0;i<mTaskInfo->listActorInit.length();i++)
    {
        utobits::PlatformConfig sPlatformConfig;
        sPlatformConfig._initialActor = sUTOConfig.actorIndexMap.key(
                    mTaskInfo->listActorInit.at(i).actorInitName).toStdString();
        sPlatformConfig._platformList.clear();
        for(int j=0;j<mTaskInfo->listActorInit.at(i).listPlatID.length();j++)
        {
            sPlatformConfig._platformList.push_back(mTaskInfo->listActorInit.at(i).listPlatID.at(j));
        }
        dest._platformConfig.push_back(sPlatformConfig);
    }
    // std::cout<<"iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"<<std::endl;
}

FAHbasic:: FAHbasic(XMLbit* m)
{
    mXMLbit = m;
}
FAHbasic:: ~FAHbasic()
{

}

TransitionInfo:: TransitionInfo(XMLbit* m, QString src)
:FAHbasic(m)
{
    QString strField = src.mid(mXMLbit->getcharPos(), 8);
    // qDebug() << "transition name:" << strField.toInt(0, 2);
    int pos = mXMLbit->getcharPos()+8;
    mXMLbit->setcharPos(pos);
    transition_name = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 1);
//    qDebug() << "sysnum enabled flag:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    int flagSysNum = strField.toInt(0, 2);
    if(flagSysNum)
    {
        strField = src.mid(mXMLbit->getcharPos(), 10);
        // qDebug() << "sysnum:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+10;
        mXMLbit->setcharPos(pos);
        sysnum = strField.toInt(0, 2);
    }
    else
    {
        sysnum = -1;
        // qDebug() << "sysnum:" << sysnum;
    }

    strField = src.mid(mXMLbit->getcharPos(), 1);
//    qDebug() << "barrierkey enabled flag:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    int flagBarrierKey = strField.toInt(0, 2);
    if(flagBarrierKey)
    {
        strField = src.mid(mXMLbit->getcharPos(), 6);
        // qDebug() << "barrierkey:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+6;
        mXMLbit->setcharPos(pos);
        barrierkey = strField.toInt(0, 2);
    }
    else
    {
        barrierkey = -1;
        // qDebug() << "barrierkey:" << barrierkey;
    }

    strField = src.mid(mXMLbit->getcharPos(), 8);
    // qDebug() << "successor:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+8;
    mXMLbit->setcharPos(pos);
    successor = strField.toInt(0, 2);
}

TransitionInfo:: ~TransitionInfo()
{

}

ActorParam:: ActorParam(XMLbit* m, QString src)
: FAHbasic(m)
{
//    qDebug()<< "mXMLbit->getcountParam():" << mXMLbit->getcountParam();
    switch(mXMLbit->getcountParam())
    {
    case 1:
    {
        QString strField = src.mid(mXMLbit->getcharPos(), 3);   // onoff circle + region type
        int pos = mXMLbit->getcharPos()+3;
        mXMLbit->setcharPos(pos);
//        qDebug()<< "mXMLbit->getcharPos():" << mXMLbit->getcharPos();
//        qDebug()<< "strField.toInt(0, 3):" << strField.toInt(0, 3);
        //circle:1, region type:01
        //circle:0, region type:00
        switch(strField.toInt(0, 2))
        {
        case 0:
        {
            paramName = 4;
            // qDebug() << "param name(regionType=4):" << paramName;

            QString strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "param repeat flag:" << strField.toInt(0, 2);
            int pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);

            strField = src.mid(mXMLbit->getcharPos(), 22);
            // qDebug() << "param value:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+22;
            mXMLbit->setcharPos(pos);
            int tempvalue = BitToNumber(strField);
            paramValue.append(strField.toInt(0, 2));
            strField = src.mid(mXMLbit->getcharPos(), 21);
            // qDebug() << "param value:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+21;
            mXMLbit->setcharPos(pos);
            paramValue.append(strField.toInt(0, 2));
            strField = src.mid(mXMLbit->getcharPos(), 10);
            // qDebug() << "param value:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+10;
            mXMLbit->setcharPos(pos);
            paramValue.append(strField.toInt(0, 2));

            strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "param enabled(axis):" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);

            break;
        }
        case 5:
        {
            paramName = 1;
            // qDebug() << "param name(regionType=1):" << paramName;
            int tmp = 1;
            paramValue.append(tmp);
            // qDebug() << "param value(circle=1):" << tmp;
            break;
        }
        }
        break;
    }
    case 2:
    {
        paramName = 2;
        // qDebug() << "param name(regionCenter=2):" << paramName;

        QString strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "param repeat flag:" << strField.toInt(0, 2);
        int pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);

        strField = src.mid(mXMLbit->getcharPos(), 22);
        // qDebug() << "param value:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+22;
        mXMLbit->setcharPos(pos);
        paramValue.append(strField.toInt(0, 2));
        strField = src.mid(mXMLbit->getcharPos(), 21);
        // qDebug() << "param value:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+21;
        mXMLbit->setcharPos(pos);
        paramValue.append(strField.toInt(0, 2));
        strField = src.mid(mXMLbit->getcharPos(), 10);
        // qDebug() << "param value:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+10;
        mXMLbit->setcharPos(pos);
        paramValue.append(strField.toInt(0, 2));
        break;
    }
    case 3:
    {
        paramName = 3;
        // qDebug() << "param name(regionRadius=3):" << paramName;

        QString strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "param axis enabled:" << strField.toInt(0, 2);
        int pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);

        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "param value(radius):" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        paramValue.append(strField.toInt(0, 2));
        strField = src.mid(mXMLbit->getcharPos(), 8);
        //qDebug() << "param value:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        //paramValue.append(strField.toInt(0, 2));
        strField = src.mid(mXMLbit->getcharPos(), 8);
        //qDebug() << "param value:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        //paramValue.append(strField.toInt(0, 2));
        break;
    }
    default:
        break;
    }
}

ActorParam:: ActorParam(XMLbit* m, QString src, int index)
: FAHbasic(m)
{
    QString strField;
    int pos;
    int itemp;
    paramName = index; 
    switch(index)
    {
    case 1:
    case 2:
    case 3:
        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "delay_laps:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        itemp = strField.toInt(0, 2);
        paramValue.append(itemp);
        break;
    case 4:
    case 5:
    case 6:
    case 7:
        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "v0:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        itemp = strField.toInt(0, 2);
        paramValue.append(itemp);
        break;
    case 8:
        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "rd:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        itemp = strField.toInt(0, 2);
        paramValue.append(itemp);
        break;
    case 9:
        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "tracking height:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        itemp = strField.toInt(0, 2);
        paramValue.append(itemp);
        break;
    case 10:
        strField = src.mid(mXMLbit->getcharPos(), 12);
        // qDebug() << "timeout:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+12;
        mXMLbit->setcharPos(pos);
        // itemp = strField.toInt(0, 2);
        itemp = BitToNumber(strField);
        paramValue.append(itemp);
        break;
    case 11:
    default:
        break;
    }
}

ActorParam::ActorParam(XMLbit* m, int value, int index)
: FAHbasic(m)
{
    paramName = index;
    paramValue.append(value);
}

ActorParam::ActorParam(XMLbit* m, QList<int> listValue, int index)
: FAHbasic(m)
{
    paramName = index;
    int len = listValue.length();
    for(int i=0;i<len;i++)
    {
        paramValue.append(listValue.at(i));
    }
}

ActorParam:: ~ActorParam()
{

}

// the length of param can be varied, modified by zyp@0516
ActorInfo:: ActorInfo(XMLbit* m, QString src)
: FAHbasic(m)
{
    QString strField = src.mid(mXMLbit->getcharPos(), 8);
    // qDebug() << "actor name:" << strField.toInt(0, 2);
    int pos = mXMLbit->getcharPos()+8;
    mXMLbit->setcharPos(pos);
    actorName = strField.toInt(0, 2);
    mXMLbit->setactorNameForDec(actorName);

    strField = src.mid(mXMLbit->getcharPos(), 1);
    // the enabled flag is converted to on/off circle, modified by zyp@20190514
    // the enabled flag is converted to enabled flag for param, modified by zyp@0516
    // qDebug() << "actor enabled flag(param):" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    if(strField.toInt(0, 2))
    {

        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "repeat flag(param):" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);
        int repeatFlagParam = strField.toInt(0, 2);

        strField = src.mid(mXMLbit->getcharPos(), 8);
        // qDebug() << "param name:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+8;
        mXMLbit->setcharPos(pos);
        int paramName = strField.toInt(0, 2);

        QList<int> paramValueList;

        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "repeat flag(param value):" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);
        int repeatFlagParamValue = strField.toInt(0, 2); 

        strField = src.mid(mXMLbit->getcharPos(), 5);
        // qDebug() << "value length:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+5;
        mXMLbit->setcharPos(pos);
        int lenValue = strField.toInt(0, 2);

        strField = src.mid(mXMLbit->getcharPos(), lenValue);
        // qDebug() << "value:" << strField.toInt(0, 2);
        // qDebug() << "value:" << BitToNumber(strField);
        pos = mXMLbit->getcharPos()+lenValue;
        mXMLbit->setcharPos(pos);
        // int paramValue = strField.toInt(0, 2);
        int paramValue = BitToNumber(strField);
        paramValueList.append(paramValue);

        while(repeatFlagParamValue)
        {
            strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "repeat flag(param value):" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);
            repeatFlagParamValue = strField.toInt(0, 2);

            strField = src.mid(mXMLbit->getcharPos(), 5);
            // qDebug() << "value length:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+5;
            mXMLbit->setcharPos(pos);
            lenValue = strField.toInt(0, 2);

            strField = src.mid(mXMLbit->getcharPos(), lenValue);
            // qDebug() << "value:" << strField.toInt(0, 2);
            // qDebug() << "value:" << BitToNumber(strField);
            pos = mXMLbit->getcharPos()+lenValue;
            mXMLbit->setcharPos(pos);
            // paramValue = strField.toInt(0, 2);
            paramValue = BitToNumber(strField);
            paramValueList.append(paramValue);
        }

        ActorParam* mActorParam = new ActorParam(mXMLbit, paramValueList, paramName);
        listActorParam.append(*mActorParam);
        delete mActorParam;
        paramValueList.clear();

        while(repeatFlagParam)
        {
            strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "repeat flag(param):" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);
            repeatFlagParam = strField.toInt(0, 2);

            strField = src.mid(mXMLbit->getcharPos(), 8);
            // qDebug() << "param name:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+8;
            mXMLbit->setcharPos(pos);
            paramName = strField.toInt(0, 2);

            strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "repeat flag(param value):" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);
            repeatFlagParamValue = strField.toInt(0, 2); 

            strField = src.mid(mXMLbit->getcharPos(), 5);
            // qDebug() << "value length:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+5;
            mXMLbit->setcharPos(pos);
            lenValue = strField.toInt(0, 2);

            strField = src.mid(mXMLbit->getcharPos(), lenValue);
            // qDebug() << "value:" << strField.toInt(0, 2);
            // qDebug() << "value:" << BitToNumber(strField);
            pos = mXMLbit->getcharPos()+lenValue;
            mXMLbit->setcharPos(pos);
            // paramValue = strField.toInt(0, 2);
            paramValue = BitToNumber(strField);
            paramValueList.append(paramValue);

            while(repeatFlagParamValue)
            {
                strField = src.mid(mXMLbit->getcharPos(), 1);
                // qDebug() << "repeat flag(param value):" << strField.toInt(0, 2);
                pos = mXMLbit->getcharPos()+1;
                mXMLbit->setcharPos(pos);
                repeatFlagParamValue = strField.toInt(0, 2);

                strField = src.mid(mXMLbit->getcharPos(), 5);
                // qDebug() << "value length:" << strField.toInt(0, 2);
                pos = mXMLbit->getcharPos()+5;
                mXMLbit->setcharPos(pos);
                lenValue = strField.toInt(0, 2);

                strField = src.mid(mXMLbit->getcharPos(), lenValue);
                // qDebug() << "value:" << strField.toInt(0, 2);
                // qDebug() << "value:" << BitToNumber(strField);
                pos = mXMLbit->getcharPos()+lenValue;
                mXMLbit->setcharPos(pos);
                // paramValue = strField.toInt(0, 2);
            paramValue = BitToNumber(strField);
                paramValueList.append(paramValue);
            }

            ActorParam* mActorParam = new ActorParam(mXMLbit, paramValueList, paramName);
            listActorParam.append(*mActorParam);
            delete mActorParam;
            paramValueList.clear();
            }
    }
    else
    {
        // do nothing
        // some actor may not have param
        // no on/off circle, but v0, rd may exist, modified by zyp@20190514
        // do nothing, modified by zyp@20190516
    }

    strField = src.mid(mXMLbit->getcharPos(), 1);
//    qDebug() << "mXMLbit->getcharPos():" << mXMLbit->getcharPos();
    // qDebug() << "actor transition enabled:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    if(strField.toInt(0, 2))
    {
        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "actor transition repeat flag:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);
        int flagRepeatTransition = strField.toInt(0, 2);

        TransitionInfo* mTransitionInfo = new TransitionInfo(mXMLbit, src);
        listTransitionInfo.append(*mTransitionInfo);
        delete mTransitionInfo;
        while(flagRepeatTransition)
        {
            strField = src.mid(mXMLbit->getcharPos(), 1);
            // qDebug() << "actor transition repeat flag:" << strField.toInt(0, 2);
            pos = mXMLbit->getcharPos()+1;
            mXMLbit->setcharPos(pos);
            flagRepeatTransition = strField.toInt(0, 2);

            TransitionInfo* mTransitionInfo = new TransitionInfo(mXMLbit, src);
            listTransitionInfo.append(*mTransitionInfo);
            delete mTransitionInfo;
        }
    }
    else
    {
        // do nothing
        // egress point may not have transition
    }
}
ActorInfo:: ~ActorInfo()
{

}

ActorInit:: ActorInit(XMLbit* m, QString src)
: FAHbasic(m)
{

    QString strField = src.mid(mXMLbit->getcharPos(), 8);
    // qDebug() << "actor init name:" << strField.toInt(0, 2);
    int pos = mXMLbit->getcharPos()+8;
    mXMLbit->setcharPos(pos);
    actorInitName = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 1);
    // qDebug() << "listPlatID repeat flag:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    int flagRepeatPlatList = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 16);
    // qDebug() << "listPlatID:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+16;
    mXMLbit->setcharPos(pos);
    int platID = strField.toInt(0, 2);
    listPlatID.append(platID);

    while(flagRepeatPlatList)
    {
        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "listPlatID repeat flag:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);
        flagRepeatPlatList = strField.toInt(0, 2);

        strField = src.mid(mXMLbit->getcharPos(), 16);
        // qDebug() << "listPlatID:" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+16;
        mXMLbit->setcharPos(pos);
        int platID = strField.toInt(0, 2);
        listPlatID.append(platID);
    }

}
ActorInit:: ~ActorInit()
{

}

TaskInfo:: TaskInfo(XMLbit* m, QString src)
: FAHbasic(m)
{
    QString strField = src.mid(mXMLbit->getcharPos(), 4);
    // qDebug() << "task ID:" << strField.toInt(0, 2);
    int pos = mXMLbit->getcharPos()+4;
    mXMLbit->setcharPos(pos);
    taskID = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 6);
    // qDebug() << "task name:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+6;
    mXMLbit->setcharPos(pos);
    taskName = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 4);
    // qDebug() << "task priority:" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+4;
    mXMLbit->setcharPos(pos);
    taskPri = strField.toInt(0, 2);

    strField = src.mid(mXMLbit->getcharPos(), 1);
    // qDebug() << "actor repeat:" << strField.toInt(0, 2);
    mXMLbit->setcharPos(mXMLbit->getcharPos()+1);
    int flagRepeatActor = strField.toInt(0, 2);
    ActorInfo* mActorInfo = new ActorInfo(mXMLbit, src);
    listActorInfo.append(*mActorInfo);
    delete mActorInfo;
    while(flagRepeatActor)
    {
        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "actor repeat:" << strField.toInt(0, 2);
        mXMLbit->setcharPos(mXMLbit->getcharPos()+1);
        flagRepeatActor = strField.toInt(0, 2);
        ActorInfo* mActorInfo = new ActorInfo(mXMLbit, src);
        listActorInfo.append(*mActorInfo);
        delete mActorInfo;
    }

    strField = src.mid(mXMLbit->getcharPos(), 1);
    // there may be multiple ActorInits for the same node, modified by zyp@20190513
    // then, the enabled flag is converted to repeat flag.
    // qDebug() << "actor init enabled(modified by repeat):" << strField.toInt(0, 2);
    pos = mXMLbit->getcharPos()+1;
    mXMLbit->setcharPos(pos);
    int flagRepeatActorInit = strField.toInt(0, 2);

    ActorInit* mActorInit = new ActorInit(mXMLbit, src);
    listActorInit.append(*mActorInit);
    delete mActorInit;

    while(flagRepeatActorInit)
    {
        strField = src.mid(mXMLbit->getcharPos(), 1);
        // qDebug() << "actor init enabled(modified by repeat):" << strField.toInt(0, 2);
        pos = mXMLbit->getcharPos()+1;
        mXMLbit->setcharPos(pos);
        flagRepeatActorInit = strField.toInt(0, 2);

        ActorInit* mActorInit = new ActorInit(mXMLbit, src);
        listActorInit.append(*mActorInit);
        delete mActorInit;
    }
}
TaskInfo:: ~TaskInfo()
{

}

int FAHbasic::BitToNumber(QString mstrlist)
{
    int isize_mcharlist = mstrlist.size();
    int sum = 0;
    if(mstrlist.at(0) == '1')
    {
        for(int i =0; i<isize_mcharlist;i++)
        {
            if(mstrlist.at(i) == '0')
            {
                sum = sum + qPow(2,isize_mcharlist-i-1);
            }
        }

        sum = -(sum+1);
    }
    if(mstrlist.at(0) == '0')
    {
        for(int i =0; i<isize_mcharlist;i++)
        {
            if(mstrlist.at(i) == '1')
            {
                sum = sum + qPow(2,isize_mcharlist-i-1);
            }
        }
    }
    return sum;

}
