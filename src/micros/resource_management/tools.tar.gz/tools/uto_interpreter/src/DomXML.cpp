﻿#include "uto_interpreter/internal/DomXML.h"
#include <QDebug>
#include <iostream>
#include <QStringList>
#include <QRegExp>

using namespace std;

bool DomXML::DomReadUTOConfigXMLFile(utobits::structUTOConfig &mstructUTOConfig, QIODevice *device)
{
    if (!domDocument.setContent(device, true))
    {
        return false;
    }

    QDomElement xmlroot = domDocument.documentElement();//dictionary
    QDomElement childxmlroot = xmlroot.firstChildElement("orderPlan");//orderPlan
    QDomElement child = childxmlroot.firstChildElement("actorIndex");//actorIndex
    QDomElement actorIndexChild = child.firstChildElement("actor");
    //read actorindex info
    while(!actorIndexChild.isNull())
    {
        strname = actorIndexChild.attribute("name");
        ivalue = actorIndexChild.attribute("value").toInt();
//        std::string str = strname.c_str();
//        std::cout<<"aaa: "<<str<<endl;
        mstructUTOConfig.actorIndexMap.insert(strname,ivalue);
        actorIndexChild = actorIndexChild.nextSiblingElement();
    }
    miter = mstructUTOConfig.actorIndexMap.find("TakeOff");
    //read transitionEventIndex info
    child = child.nextSiblingElement();
    QDomElement transitionEventIndexChild = child.firstChildElement("transitionevent");
    while(!transitionEventIndexChild.isNull())
    {
        strname = transitionEventIndexChild.attribute("name");
        ivalue = transitionEventIndexChild.attribute("value").toInt();
        mstructUTOConfig.transitionEventIndexMap.insert(strname,ivalue);
        transitionEventIndexChild = transitionEventIndexChild.nextSiblingElement();
    }

    //read paramIndex info
    child = child.nextSiblingElement();
    QDomElement paramIndexChild = child.firstChildElement("param");
    while(!paramIndexChild.isNull())
    {
        strname = paramIndexChild.attribute("name");
        ivalue = paramIndexChild.attribute("value").toInt();
        mstructUTOConfig.paramIndexMap.insert(strname,ivalue);
        paramIndexChild = paramIndexChild.nextSiblingElement();
    }

    //read regionType info
    child = child.nextSiblingElement();
    QDomElement regionTypeChild = child.firstChildElement("regiontype");
    while(!regionTypeChild.isNull())
    {
        strname = regionTypeChild.attribute("name");
        ivalue = regionTypeChild.attribute("value").toInt();
        mstructUTOConfig.regionTypeMap.insert(strname,ivalue);
        regionTypeChild = regionTypeChild.nextSiblingElement();
    }

    //read paramIndex info
    child = child.nextSiblingElement();
    QDomElement planNameChild = child.firstChildElement("planName");
    while(!planNameChild.isNull())
    {
        strname = planNameChild.attribute("name");
        ivalue = planNameChild.attribute("value").toInt();
        mstructUTOConfig.planNameIndexMap.insert(strname,ivalue);
        planNameChild = planNameChild.nextSiblingElement();
    }




    return true;

}

bool DomXML::DomReadXMLFile(QIODevice *device, utobits::Task &task, utobits::structUTOConfig &mstructUTOConfig)
{
    if (!domDocument.setContent(device, true))
    {
        return false;
    }

    QDomElement xmlroot = domDocument.documentElement();

    QDomElement child = xmlroot.firstChildElement("_P_ID");
    task.task_id = child.text().toInt();

    child = child.nextSiblingElement();
    task.task_name = child.text();

    child  = child.nextSiblingElement();
    task.task_prior = child.text().toInt();


    child  = child.nextSiblingElement();
    child  = child.nextSiblingElement();
    if(child.tagName() == "_UTOConfig")
    {
        QDomElement actorchild = child.firstChildElement();

        while(actorchild.tagName() == "actor")
        {
            utobits::Actor mActor;
            utobits::ActorArg mActorArg;
            mActor.actor_name = actorchild.attribute("name");
            parseActorInfoElement(mActor,actorchild,mActorArg);
            
            for(int i=0;i<mActor.params.size();i++)
            {
                utobits::Param tempParam;
                for(int j=0;j<mActorArg._argList.size();j++)
                {
                    if(mActor.params.at(i).param_name == mActorArg._argList.at(j)._argName)
                    {
                        tempParam.param_name = mActor.params.at(i).param_name;
                        tempParam.param_value = mActorArg._argList.at(j)._argDefaultValue;
                        mActor.params[i] = tempParam;
                    }
                }
            }
              

            actorchild  = actorchild.nextSiblingElement();
            task.utoconfig.append(mActor);



        }

        child  = child.nextSiblingElement();
    }
    if(child.tagName() == "_PlatformActorConfig")
    {
        QDomElement InitialActorchild = child.firstChildElement();
        while(InitialActorchild.tagName() == "_InitialActor")
        {
            utobits::PlatformActorConfig mPlatformActorConfig;
            mPlatformActorConfig.initialactor_name = InitialActorchild.attribute("name");
            mPlatformActorConfig.platformlist = InitialActorchild.attribute("platformlist");

            InitialActorchild = InitialActorchild.nextSiblingElement();
            task.platformactorconfig.append(mPlatformActorConfig);

        }
    }

    return true;

}



void DomXML::parseActorInfoElement(utobits::Actor &mActor,const QDomElement &element,utobits::ActorArg &mActorArg)
{
    QDomElement child = element.firstChildElement();
    while(!child.isNull())
    {
        if(child.tagName() == "arg")
        {
            utobits::ArgInfo mArgInfo;
            mArgInfo._argName = child.attribute("name");
            mArgInfo._argDefaultValue = child.attribute("default");
            mActorArg._argList.append(mArgInfo);
        }
        


        if(child.tagName() == "param")
        {
            utobits::Param mParam;
            mParam.param_name = child.attribute("name");
            mParam.param_value = child.attribute("value");

            mActor.params.append(mParam);
        }

        if(child.tagName() == "transition")
        {
            utobits::Transition mTransition;
            mTransition.transition_name = child.attribute("name");
            if(child.hasAttribute("sysNum"))
            {
                mTransition.sysnum = child.attribute("sysNum").toInt();
            }
            else
            {
                mTransition.sysnum = -1;
            }
            if(child.hasAttribute("barrierKey"))
            {
                mTransition.barrierkey = child.attribute("barrierKey").toInt();
            }
            else
            {
                mTransition.barrierkey = -1;
            }
            QDomElement transitionchild = child.firstChildElement();
            mTransition.successor = transitionchild.text();

            mActor.transitions.append(mTransition);

        }
        child  = child.nextSiblingElement();
    }
}

utobits::iTask DomXML::TaskToiTask(utobits::Task &mTask,utobits::iTask &miTask)
{
    miTask.task_id = mTask.task_id;
    miTask.task_name = pNameIndex(mTask.task_name,mstructUTOConfig);
    miTask.task_prior = mTask.task_prior;
    utobits::iParam tempiParam;
    utobits::iTransition tempiTransition;
    for(int i=0;i<mTask.utoconfig.size();i++)
    {
        utobits::iActor tempiActor;

        QString strtempActorName = mTask.utoconfig.at(i).actor_name;
        tempiActor.actor_name = actorNameIndex(strtempActorName,mstructUTOConfig);

        int isize_params = mTask.utoconfig.at(i).params.size();
        if(isize_params != 0)
        {
            for(int j=0;j<isize_params;j++)
            {
                utobits::iParam imParams;

                QString strparamname = mTask.utoconfig.at(i).params.at(j).param_name;
                QString strparamvalue = mTask.utoconfig.at(i).params.at(j).param_value;
                imParams = processParamInfo(strparamname,strparamvalue,strtempActorName);
                tempiActor.params.append(imParams);

            }
        }
        int isize_transitions = mTask.utoconfig.at(i).transitions.size();
        if(isize_transitions != 0)
        {

            utobits::Transition tmpTransition;
            for(int j=0;j<isize_transitions;j++)
            {
                utobits::iTransition imTransition;

                tmpTransition.transition_name = mTask.utoconfig.at(i).transitions.at(j).transition_name;
                tmpTransition.sysnum = mTask.utoconfig.at(i).transitions.at(j).sysnum;
                tmpTransition.barrierkey = mTask.utoconfig.at(i).transitions.at(j).barrierkey;
                tmpTransition.successor = mTask.utoconfig.at(i).transitions.at(j).successor;

                imTransition = processTransitionInfo(tmpTransition);
                tempiActor.transitions.append(imTransition);
            }

        }
        miTask.utoconfig.append(tempiActor);
    }

    for(int i=0; i<mTask.platformactorconfig.size();i++)
    {
        utobits::iPlatformActorConfig miPlatformActorConfig;
        QString strinitialactor_name = mTask.platformactorconfig.at(i).initialactor_name;
        int istrinitialactor_name = actorNameIndex(strinitialactor_name,mstructUTOConfig);
        miPlatformActorConfig.initialactor_name = istrinitialactor_name;
        QStringList platformlist = mTask.platformactorconfig.at(i).platformlist.split(",");
        QString strplatformid;
        for(int j=0;j<platformlist.count();j++)
        {
            strplatformid = platformlist.value(j);
            miPlatformActorConfig.platformlist.append(strplatformid.toInt());
        }

        miTask.platformactorconfig.append(miPlatformActorConfig);

    }
    return miTask;
}

utobits::iParam DomXML::processParamInfo(QString strName,QString strValue,QString actorName)
{
    utobits::iParam miParam;
    QString strname = strName;
    int iparamindex = paramNameIndex(strname,mstructUTOConfig);
    miParam.param_name = iparamindex;
    QString strvalue = strValue;
    QStringList paramlist;
    QString tempstrParam;
    
    paramlist = strvalue.split(" ");
    for(int i=0;i<paramlist.count();i++)
    {
        tempstrParam = paramlist.value(i);
        miParam.param_value.append(tempstrParam.toInt());
    }

    return miParam;

}

utobits::iTransition DomXML::processTransitionInfo(utobits::Transition mTransition)
{
    utobits::iTransition miTransition;
    QString strname = mTransition.transition_name;
    QString strsuccessor = mTransition.successor;

    miTransition.transition_name = transitionNameIndex(strname,mstructUTOConfig);
    miTransition.successor = actorNameIndex(strsuccessor,mstructUTOConfig);
    miTransition.sysnum = mTransition.sysnum;
    miTransition.barrierkey = mTransition.barrierkey;

    return miTransition;
}



int DomXML::pNameIndex(QString str, utobits::structUTOConfig &mUTOConfig)
{
    int index=0;
    index = mUTOConfig.planNameIndexMap[str];
    return index;
}

int DomXML::actorNameIndex(QString str, utobits::structUTOConfig &mUTOConfig)
{
    int index=0;
    index = mUTOConfig.actorIndexMap[str];
    return index;
}

int DomXML::paramNameIndex(QString str, utobits::structUTOConfig &mUTOConfig)
{
    int index=0;
    index = mUTOConfig.paramIndexMap[str];
    return index;
}

int DomXML::transitionNameIndex(QString str, utobits::structUTOConfig &mUTOConfig)
{
    int index=0;
    index = mUTOConfig.transitionEventIndexMap[str];
    return index;
}

QString DomXML::inversePNameIndex(int index, utobits::structUTOConfig &mUTOConfig)
{
    int isize_map = mUTOConfig.planNameIndexMap.size();
    QString strpName;
    if(index > isize_map)
    {
        return "";
    }
    else
    {
        strpName = mUTOConfig.transitionEventIndexMap.key(index);

    }
    return strpName;
}

QString DomXML::inverseActorNameIndex(int index, utobits::structUTOConfig &mUTOConfig)
{
    int isize_map = mUTOConfig.transitionEventIndexMap.size();
    QString strActorName;
    if(index > isize_map)
    {
        return "";
    }
    else
    {
        strActorName = mUTOConfig.transitionEventIndexMap.key(index);

    }
    return strActorName;
}

QString DomXML::inverseParamNameIndex(int index, utobits::structUTOConfig &mUTOConfig)
{
    int isize_map = mUTOConfig.transitionEventIndexMap.size();
    QString strParamName;
    if(index > isize_map)
    {
        return "";
    }
    else
    {
        strParamName = mUTOConfig.transitionEventIndexMap.key(index);

    }
    return strParamName;
}

QString DomXML::inverseTransitionNameIndex(int index, utobits::structUTOConfig &mUTOConfig)
{
    int isize_map = mUTOConfig.transitionEventIndexMap.size();
    QString strTransitionEventName;
    if(index > isize_map)
    {
        return "";
    }
    else
    {
        strTransitionEventName = mUTOConfig.transitionEventIndexMap.key(index);

    }
    return strTransitionEventName;
}

