#include <QtXml>
#include <QtCore>
#include "uto_interpreter/uto_interpreter_api.h"

UTOCodec::UTOCodec()
{
    mDomXML = new DomXML();
    mXMLbit = new XMLbit();
}

UTOCodec::~UTOCodec()
{
    delete mDomXML;
    delete mXMLbit;
}

QString UTOCodec::encodeToBits(std::string xmlFilePath, std::string utoCfgFilePath)
{
    QString strFilePath = QString::fromStdString(xmlFilePath);
    QFile file(strFilePath);

    QString strUTOConfigFilePath = QString::fromStdString(utoCfgFilePath);
    QFile utoconfigfile(strUTOConfigFilePath);

    mDomXML->DomReadUTOConfigXMLFile(mDomXML->mstructUTOConfig, &utoconfigfile);
    mDomXML->DomReadXMLFile(&file,mDomXML->mTask,mDomXML->mstructUTOConfig);
    utobits::iTask miTask = mDomXML->TaskToiTask(mDomXML->mTask,mDomXML->miTask);

    mXMLbit->encodeToBit(miTask);
    return(mXMLbit->gettaskBitString());
}

void UTOCodec::decodeFromBits(QString srcStr, utobits::UTOTask &dest)
{
    mXMLbit->decodeFromBits(srcStr, dest);
}
