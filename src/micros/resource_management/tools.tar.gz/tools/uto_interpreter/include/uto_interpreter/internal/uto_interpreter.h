#ifndef __UTO_INTERPRETER_H__
#define __UTO_INTERPRETER_H__

#include "ros/ros.h"
#include <QtCore/qobject.h>
#include "XMLConfig.h"
#include "DomXML.h"

class TaskInfo;

class XMLbit : public QObject
{
public:
    XMLbit();
    ~XMLbit();

    inline QString gettaskBitString(){return taskBitString;}
    inline int getcharLen(){return charLen;}
    inline int getcharPos(){return charPos;}
    inline void setcharPos(int newPos){charPos = newPos;}
    inline int getactorNameForDec(){return actorNameForDec;}
    inline void setactorNameForDec(int newactorNameForDec){actorNameForDec = newactorNameForDec;}
    inline int getcountParam(){return countParam;}
    inline void setcountParam(int newcountParam){countParam = newcountParam;}
    QList<char> fromByte2Bit(int src, QList<char> dest, int len);  // change varible with int into char with '0' and '1'
    QList<char> fromByte2Bit(double src, QList<char> dest, int len, double range);
    void mergeCharList(); // put the result of <listChar1, listChar2> into listChar1
    void addField(int src, int len);
    void addField(double src, int len, double range);
    void encodeToBit(utobits::iTask srcTask);
    void decodeFromBit(QString src);
    void decodeFromBits(QString src, utobits::UTOTask &dest);

private:
    // MainWindow* pMainWindow;
    QString taskBitString;
    QList<char> listChar1;
    QList<char> listChar2;
    utobits::pktHeader sHeader;
    TaskInfo* mTaskInfo;
    int actorNameForDec;
    int countParam;
    int charLen;
    int charPos;
    utobits::structUTOConfig sUTOConfig;
};

class FAHbasic
{
public:
    FAHbasic(XMLbit* m);
    ~FAHbasic();

    int BitToNumber(QString mstrlist);


    XMLbit* mXMLbit;
};

class TransitionInfo : public FAHbasic
{
public:
    TransitionInfo(XMLbit* m, QString src);
    ~TransitionInfo();

    int transition_name;
    int sysnum;
    int barrierkey;
    int successor;
};

class ActorParam : public FAHbasic
{
public:
    ActorParam(XMLbit* m, QString src);
    ActorParam(XMLbit* m, QString src, int index);
    ActorParam(XMLbit* m, int value, int index);
    ActorParam(XMLbit* m, QList<int> listValue, int index);
    ~ActorParam();



    int paramName;
    QList<int> paramValue;
};

class ActorInfo : public FAHbasic
{
public:
    ActorInfo(XMLbit* m, QString src);
    ~ActorInfo();

    void finishConstruct();
    inline QList<ActorParam> getlistActorParam(){return listActorParam;}

    int actorName;
    QList<ActorParam> listActorParam;
    QList<TransitionInfo> listTransitionInfo;
};

class ActorInit : public FAHbasic
{
public:
    ActorInit(XMLbit* m, QString src);
    ~ActorInit();

    int actorInitName;
    QList<int> listPlatID;
};

class TaskInfo : public FAHbasic
{
public:
    TaskInfo(XMLbit* m, QString src);
    ~TaskInfo();

    inline QList<ActorInfo> getlistActorInfo(){return listActorInfo;}


    int taskID;
    int taskName;
    int taskPri;
    QList<ActorInfo> listActorInfo;
    QList<ActorInit> listActorInit;
};

#endif
