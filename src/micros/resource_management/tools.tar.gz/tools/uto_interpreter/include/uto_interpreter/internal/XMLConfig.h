#ifndef XMLCONFIG_H
#define XMLCONFIG_H

#include <qmap.h>
#include <vector>

namespace utobits {

struct pktHeader
{
    int msgStandard;
    int version;
    int msgType;
};

struct iTransition
{
    int transition_name;
    int sysnum;
    int barrierkey;
    int successor;
};

struct iParam
{
    int param_name;
    QList<int> param_value;
};

struct iActor
{
    int actor_name;
    QList<iParam> params;
    QList<iTransition> transitions;
};


struct iPlatformActorConfig
{
    int initialactor_name;
    QList<int> platformlist;
};

struct iTask
{
    int task_id;
    int task_name;
    int task_prior;

    QList<iActor> utoconfig;

    QList<iPlatformActorConfig> platformactorconfig;

};

// the intput struct

struct Transition
{
    QString transition_name;
    int sysnum;
    int barrierkey;
    QString successor;
};

struct Param
{
    QString param_name;
    QString param_value;
};

struct Actor
{
    QString actor_name;
    QList<Param> params;
    QList<Transition> transitions;
};



struct PlatformActorConfig
{
    QString initialactor_name;
    QString platformlist;
};

struct Task
{
    int task_id;
    QString task_name;
    int task_prior;
    QList<Actor> utoconfig;
    QList<PlatformActorConfig> platformactorconfig;
};

// the output struct

struct UTOTransition
{
    std::string _eventName;
    std::string _nextActor;
    int _sysNum;
    short _barrierKey;
};

struct UTOActorParam
{
    std::string _key;
    std::string _value;
};

struct UTOActorNode
{
    std::string _actorName;
    std::vector<UTOActorParam> _paramList;
    std::vector<UTOTransition> _eventList;
};

struct PlatformConfig
{
    std::string _initialActor;
    std::vector<int> _platformList;
};

struct UTOTask
{
    int _taskID;
    std::string _taskName;
    int _taskPrio;

    std::vector<UTOActorNode> _utoConfig;

    std::vector<PlatformConfig> _platformConfig;

};

struct structUTOConfig
{
    QMap<QString,int> actorIndexMap;
    QMap<QString,int> transitionEventIndexMap;
    QMap<QString,int> paramIndexMap;
    QMap<QString,int> regionTypeMap;
    QMap<QString,int> planNameIndexMap;
};

struct ArgInfo
{
    QString _argName;
    QString _argDefaultValue;
};

struct ActorArg
{
    QList<ArgInfo> _argList;
};

}

#endif // XMLCONFIG_H

