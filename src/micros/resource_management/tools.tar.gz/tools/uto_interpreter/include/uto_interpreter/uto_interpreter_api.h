#ifndef __UTO_INTERPRETER_API_H__
#define __UTO_INTERPRETER_API_H__

#include <QPointer>
#include "uto_interpreter/internal/DomXML.h"
#include "uto_interpreter/internal/XMLConfig.h"
#include "uto_interpreter/internal/uto_interpreter.h"

class UTOCodec
{
public:
    UTOCodec();
    ~UTOCodec();

    QString encodeToBits(std::string xmlFilePath, std::string utoCfgFilePath);
    void decodeFromBits(QString srcStr, utobits::UTOTask &dest);

private:
    DomXML *mDomXML;
    QPointer<XMLbit> mXMLbit;
};

#endif
