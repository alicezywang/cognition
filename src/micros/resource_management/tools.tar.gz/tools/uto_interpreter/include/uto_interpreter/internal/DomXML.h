﻿#ifndef DOMXML_H
#define DOMXML_H

#include <QtXml/QDomDocument>
#include "XMLConfig.h"
#include <iterator>

class DomXML
{
public:
    utobits::Task mTask;
    utobits::iTask miTask;



    utobits::structUTOConfig mstructUTOConfig;
    QDomDocument domDocument;

    QString strname;
    int ivalue;
    QMap<QString,int>::iterator miter;

    // DomXML();

    bool DomReadXMLFile(QIODevice *device, utobits::Task &task, utobits::structUTOConfig &mstructUTOConfig);
    bool DomReadUTOConfigXMLFile(utobits::structUTOConfig &mstructUTOConfig,QIODevice *device);

    void parseActorInfoElement(utobits::Actor &mActor,const QDomElement &element,utobits::ActorArg &mActorArg);
    utobits::iTask TaskToiTask(utobits::Task &mTask, utobits::iTask &miTask);


    utobits::iTransition processTransitionInfo(utobits::Transition mTransition);
    utobits::iParam processParamInfo(QString strName,QString strValue,QString actorName);

    int pNameIndex(QString str,utobits::structUTOConfig &mstructUTOConfig);
    int actorNameIndex(QString str,utobits::structUTOConfig &mUTOConfig);
    int paramNameIndex(QString str,utobits::structUTOConfig &mUTOConfig);
    int transitionNameIndex(QString str,utobits::structUTOConfig &mUTOConfig);

    QString inversePNameIndex(int index,utobits::structUTOConfig &mUTOConfig);
    QString inverseActorNameIndex(int index,utobits::structUTOConfig &mUTOConfig);
    QString inverseParamNameIndex(int index,utobits::structUTOConfig &mUTOConfig);
    QString inverseTransitionNameIndex(int index,utobits::structUTOConfig &mUTOConfig);
};

#endif // DOMXML_H
