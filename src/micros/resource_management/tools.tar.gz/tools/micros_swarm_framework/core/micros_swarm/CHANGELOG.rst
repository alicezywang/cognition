^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package micros_swarm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.16 (2017-12-15)
-------------------
* test
* test
* test scds
* test
* fixs and tests
* test scds-based pso
* fixs
* msg queue manager improve
* Version 3.1
* Version 3.1
* Version 3.0
* fix bugs
* add rt core shutdown
* fix bugs
* fix bugs
* repair bugs
* app manager
* app manage
* scds
* scds
* scds
* scds pso
* scds_pso
* add scds-pso
* fix bugs
* update the name of comm broker
* update folder name
* update comm
* update packet parser
* repair bugs
* update swarm
* update swarm management
* repair bugs in virtual stigmergy
* update rtp core and repair bugs
* Merge branch 'meta_package'
* repair bugs
* complete opensplice dds comm
* try to integrate opensplice dds
* use plugin to implement abstract communication layer
* meta package
* Contributors: , xuefengchang

0.0.15 (2016-11-12)
-------------------

0.0.14 (2016-09-09)
-------------------

0.0.13 (2016-08-16)
-------------------

0.0.12 (2016-07-18 17:10)
-------------------------

0.0.11 (2016-07-18 15:54)
-------------------------

0.0.10 (2016-07-18 15:24)
-------------------------

0.0.9 (2016-07-07)
------------------

0.0.8 (2016-06-14)
------------------

0.0.7 (2016-05-30)
------------------

0.0.6 (2016-05-17)
------------------

0.0.5 (2016-05-13)
------------------

0.0.4 (2016-05-11 15:33)
------------------------

0.0.3 (2016-05-11 10:26)
------------------------

0.0.2 (2016-05-10)
------------------
