/**
Software License Agreement (BSD)
\file      runtime_core.cpp
\authors Xuefeng Chang <changxuefengcn@163.com>
\copyright Copyright (c) 2016, the micROS Team, HPCL (National University of Defense Technology), All rights reserved.
Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of micROS Team, HPCL, nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include "micros_swarm/runtime_core.h"
//#define PUBLISH_ROBOT_ID_DURATION 0.1
//#define PUBLISH_SWARM_LIST_DURATION 5
#include <fstream>

namespace micros_swarm{
    RuntimeCore::RuntimeCore():ci_loader_("micros_swarm", "micros_swarm::CommInterface")
    {
    }

    RuntimeCore::~RuntimeCore()
    {
        spin_thread_->interrupt();
        spin_thread_->join();
        delete spin_thread_;

        rth_.reset();
        parser_.reset();
        communicator_.reset();
        ci_loader_.unloadLibraryForClass(comm_type_);
    }
    
    void RuntimeCore::spin_msg_queue()
    {
        for(;;)
        {
            boost::shared_lock<boost::shared_mutex> lock(rth_->getOutMsgQueue()->msg_queue_mutex);
    
            if(!rth_->getOutMsgQueue()->baseMsgQueueEmpty())
            {
                //std::cout<<"before bc: yaw="<<rth_->getOutMsgQueue()->baseMsgQueueFront().yaw<<std::endl;
                communicator_->broadcast(rth_->getOutMsgQueue()->baseMsgQueueFront());
                rth_->getOutMsgQueue()->popBaseMsgQueue();
            }
            if(!rth_->getOutMsgQueue()->ncMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->ncMsgQueueFront());
                rth_->getOutMsgQueue()->popNcMsgQueue();
            }
            if(!rth_->getOutMsgQueue()->swarmMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->swarmMsgQueueFront());
                rth_->getOutMsgQueue()->popSwarmMsgQueue();
            }
	    	if(!rth_->getOutMsgQueue()->neighbourListMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->neighbourListMsgQueueFront());
                rth_->getOutMsgQueue()->popNeighbourListMsgQueue();
            }		 
            if(!rth_->getOutMsgQueue()->vstigMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->vstigMsgQueueFront());
                rth_->getOutMsgQueue()->popVstigMsgQueue();
            }
            if(!rth_->getOutMsgQueue()->bbMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->bbMsgQueueFront());
                rth_->getOutMsgQueue()->popBbMsgQueue();
            }
            if(!rth_->getOutMsgQueue()->barrierMsgQueueEmpty())
            {
                communicator_->broadcast(rth_->getOutMsgQueue()->barrierMsgQueueFront());
                rth_->getOutMsgQueue()->popBarrierMsgQueue();
            }
            if(!rth_->getOutMsgQueue()->sharedKeyValueListMsgQueueEmpty())
            {
                //std::cout<<"11111111111111"<<std::endl;
                communicator_->broadcast(rth_->getOutMsgQueue()->sharedKeyValueListMsgQueueFront());
                rth_->getOutMsgQueue()->popSharedKeyValueListMsgQueue();
            }
			
            while(rth_->getOutMsgQueue()->allOutMsgQueueEmpty())
            {
                rth_->getOutMsgQueue()->msg_queue_condition.wait(lock);
            }
        }
    }
    
    void RuntimeCore::barrier_check(const ros::TimerEvent&)
    {
        int barrier_size=rth_->getBarrierSize();
        if(barrier_size>=total_robot_numbers_-1)
        {
            std::cout<<"robot "<<rth_->getRobotID()<<" daemon node start."<<std::endl;
            barrier_timer_.stop();
        }
                
        //barrier
        int robot_id=rth_->getRobotID();
    
        swarm_msgs::CommPacket p;
        p.packet_source = robot_id;
        p.packet_version = 1;
        p.packet_type = micros_swarm::BARRIER_SYN;
        p.packet_data = "SYN";
        p.package_check_sum = 0;
        rth_->getOutMsgQueue()->pushBarrierMsgQueue(p);
        
    }
    
    void RuntimeCore::publish_robot_base(const ros::TimerEvent&)
    {
        int robot_id=rth_->getRobotID();
        
        const Base& l=rth_->getRobotBase();

        swarm_msgs::RobotBase srbb;
        
        srbb.id = robot_id;
        srbb.px = l.x;
        srbb.py = l.y;
        srbb.pz = l.z;
        srbb.vx = l.vx;
        srbb.vy = l.vy;
        srbb.vz = l.vz;
        srbb.valid = l.valid;
        srbb.theta = l.yaw;
       
        swarm_msgs::CommPacket p;
        p.packet_source = robot_id;
        p.packet_version = 1;
        p.packet_type = SINGLE_ROBOT_BROADCAST_BASE;

//        struct timeval start, end;
//        gettimeofday(&start, NULL);
        p.packet_data = serialize_ros(srbb);
//        gettimeofday(&end, NULL);
//        uint64_t time = (end.tv_sec * (unsigned int)1e6 + end.tv_usec) -
//            (start.tv_sec * (unsigned int)1e6 + start.tv_usec);
//        std::cout << "Time (microseconds): " << time << std::endl;
//        std::cout << p.packet_data.size() << std::endl;
//        std::cout << p.packet_data << std::endl;
/*        for (int i = 0; i < p.packet_data.size(); i++)
            std::cout << (int)(p.packet_data[i]) << ";";
        std::cout << std::endl;*/
        
        p.package_check_sum=0;
        
        rth_->getOutMsgQueue()->pushBaseMsgQueue(p);
    }
    
    void RuntimeCore::publish_swarm_list(const ros::TimerEvent&)
    {
        int robot_id=rth_->getRobotID();
        
        swarm_msgs::SwarmList srsl;
        srsl.robot_id = robot_id;
        srsl.swarm_list.clear();
        rth_->getSwarmList(srsl.swarm_list);
                          
        swarm_msgs::CommPacket p;
        p.packet_source = robot_id;
        p.packet_version = 1;
        p.packet_type = SINGLE_ROBOT_SWARM_LIST;
        p.packet_data = serialize_ros(srsl);
        p.package_check_sum = 0;

        rth_->getOutMsgQueue()->pushSwarmMsgQueue(p);
        
    }

   void RuntimeCore::publish_neighbour_list(const ros::TimerEvent&)
    {
        int robot_id=rth_->getRobotID();
        
        swarm_msgs::NeighborList srnl;
        srnl.robot_id = robot_id;
        srnl.neighbor_list.clear();
        rth_->getNeighbourList(srnl.neighbor_list);
        	       
        swarm_msgs::CommPacket p;
        p.packet_source=robot_id;
        p.packet_version=1;
        p.packet_type=SINGLE_ROBOT_NEIGHBOUR_LIST;
        p.packet_data=serialize_ros(srnl);
        p.package_check_sum=0;

        rth_->getOutMsgQueue()->pushNeighbourListMsgQueue(p);
        
    }

    void RuntimeCore::setParameters()
    {
    

        bool param_ok =node_handle_.getParam("/publish_robot_id_duration", publish_robot_base_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_robot_id_duration! use the default value."<<std::endl;
            publish_robot_base_duration_=0.1;
        }else{
            std::cout<<"publish_robot_id_duration: "<<publish_robot_base_duration_<<std::endl;
        }
        
        param_ok =node_handle_.getParam("/publish_swarm_list_duration", publish_swarm_list_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_swarm_list_duration! use the default value."<<std::endl;
            publish_swarm_list_duration_=5.0;
        }else{
            std::cout<<"publish_swarm_list_duration: "<<publish_swarm_list_duration_<<std::endl;
        }

        param_ok =node_handle_.getParam("/publish_neighbour_list_duration", publish_neighbour_list_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_neighbour_list_duration! use the default value."<<std::endl;
            publish_neighbour_list_duration_=5.0;
        }else{
            std::cout<<"publish_neighbour_list_duration: "<<publish_neighbour_list_duration_<<std::endl;
        }

        param_ok =node_handle_.getParam("/publish_swarm_heartbeat_local_duration", pub_swarm_heartbeat_local_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_swarm_heartbeat_local_duration! use the default value."<<std::endl;
            pub_swarm_heartbeat_local_duration_=0.1;
        }else{
            std::cout<<"publish_swarm_heartbeat_local_duration: "<<pub_swarm_heartbeat_local_duration_<<std::endl;
        }

        param_ok =node_handle_.getParam("/publish_swarm_path_local_duration", pub_swarm_path_local_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_swarm_path_local_duration! use the default value."<<std::endl;
            pub_swarm_path_local_duration_=0.1;
        }else{
            std::cout<<"publish_swarm_path_local_duration: "<<pub_swarm_path_local_duration_<<std::endl;
        }

        param_ok =node_handle_.getParam("/publish_robot_base_local_duration", pub_robot_base_local_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_robot_base_local_duration! use the default value."<<std::endl;
            pub_robot_base_local_duration_=0.1;
        }else{
            std::cout<<"publish_robot_base_local_duration: "<<pub_robot_base_local_duration_<<std::endl;
        }

        param_ok =node_handle_.getParam("/publish_neighbour_bases_local_duration", pub_neighbour_bases_local_duration_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter publish_neighbour_bases_local_duration! use the default value."<<std::endl;
            pub_neighbour_bases_local_duration_=0.1;
        }else{
            std::cout<<"publish_neighbour_bases_local_duration: "<<pub_neighbour_bases_local_duration_<<std::endl;
        }
		
			
        param_ok =node_handle_.getParam("/default_neighbor_distance", default_neighbor_distance_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter default_neighbor_distance! use the default value."<<std::endl;
            default_neighbor_distance_=50;
        }else{
            std::cout<<"default_neighbor_distance: "<<default_neighbor_distance_<<std::endl;
        }
        
        param_ok =node_handle_.getParam("/total_robot_numbers", total_robot_numbers_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter total_robot_numbers! use the default value."<<std::endl;
            total_robot_numbers_=1;
        }else{
            std::cout<<"total_robot_numbers: "<<total_robot_numbers_<<std::endl;
        }

        param_ok =node_handle_.getParam("/comm_type", comm_type_);
        if(!param_ok)
        {
            std::cout<<"could not get parameter comm_type, use the default ros_comm."<<std::endl;
            comm_type_="ros_comm/ROSComm";
        }else{
            std::cout<<"comm_type: "<<comm_type_<<std::endl;
        }

        ros::NodeHandle private_nh("~");
	    srand(time(0));
        private_nh.param("robot_id", robot_id_, 200);//rand()%1000);
        std::cout<<"robot_id: "<<robot_id_<<std::endl;
        //private_nh.param<std::string>("comm_type", comm_type_, "ros_broker/ROSBroker");
        //private_nh.param<std::string>("comm_type", comm_type_, "opensplice_dds_broker/OpenSpliceDDSBroker");
    }

	void Quaternion2Euler(double x,double y, double z, double w,double &roll, double &pitch,double &yaw) {
		//not implemented
		geometry_msgs::Quaternion q;
		q.x =x;q.y=y;q.z=z;q.w=w;
		yaw = tf::getYaw(q);
		ROS_INFO("void Quaternion2Euler only yaw implemented");
	}

	void RuntimeCore::subscribe_robot_base_local(const nav_msgs::Odometry::ConstPtr & msg) {
		Base base;
		double x,y,z,xx,yy,zz,ww;
		double vx,vy,vz,roll=0,pitch=0,yaw=0;
		x= msg->pose.pose.position.x;
		y= msg->pose.pose.position.y;
		z= msg->pose.pose.position.z;
		base.x=x;base.y=y;base.z=z;
		base.vx=msg->twist.twist.linear.x;
		base.vy=msg->twist.twist.linear.y;
		base.vz=msg->twist.twist.linear.z;
		xx=msg->pose.pose.orientation.x;
	    yy=msg->pose.pose.orientation.y;
	    zz=msg->pose.pose.orientation.z;
	    ww=msg->pose.pose.orientation.w;
		Quaternion2Euler(xx,yy,zz,ww,roll,pitch,yaw);
		base.yaw = yaw;
		base.roll = roll;
		base.pitch = pitch;
		std::cout<<"roll="<<roll<<",pitch="<<pitch<<",yaw="<<yaw<<std::endl;
		rth_->setRobotBase(base);
	}


	bool RuntimeCore::service_get_robot_id_local_cb(swarm_msgs::GetID::Request&req, 
											swarm_msgs::GetID::Response& res) {
		res.robot_id=rth_->getRobotID();
		return true;
	}

   

   //local inter-processes comm 
   //user need to deserialize the data 
   void RuntimeCore::publish_neighbour_bases_local(const ros::TimerEvent&)
    {
        long long robot_id=rth_->getRobotID();
        std::map<int, NeighborBase> data;
	 	data.clear();
		rth_->getNeighbors(data);
	 	swarm_msgs::NeighbourBases msg;
	 	msg.data=serialize(data); // NOTE[wyz]: since it is local, keep the inefficient Boost serialization ***for now***
	 	pub_neighbour_bases_local_.publish(msg);
    }	

    // local inter-processes comm
    // user need to deserialize the data
    void RuntimeCore::publish_robot_base_local(const ros::TimerEvent&)
    {
		const Base& base=rth_->getRobotBase();
		swarm_msgs::Base msg;
		msg.data=serialize(base); // NOTE[wyz]: since it is local, keep the inefficient Boost serialization ***for now***
		pub_robot_base_local_.publish(msg);
    }


	//ros msg from ground station, and bcast with UDP 
	void RuntimeCore::subscribe_swarm_path_local(const swarm_msgs::Path::ConstPtr & msg) {
		/*long long robot_id=rth_->getRobotID();
        
        swarm_msgs::Path swarm_path;
        swarm_path.points = msg->points;

        swarm_msgs::KeyValue sharedKeyValue;
        sharedKeyValue.timestamp = msg->header.stamp;
        sharedKeyValue.key = "path";
        sharedKeyValue.value = serialize_ros(swarm_path);
	                  
		swarm_msgs::CommPacket p;
		p.packet_source=robot_id;
		p.packet_version=1;
		p.packet_type=SHARED_KEY_VALUE;
		p.packet_data=serialize_ros(sharedKeyValue);
		p.package_check_sum=0;

		rth_->getOutMsgQueue()->pushSharedKeyValueListMsgQueue(p);*/
		//pub_swarm_path_local_.publish(*msg);

        swarm_msgs::Path swarm_path;
        swarm_path.points = msg->points;
        SharedKV<swarm_msgs::Path> skv;
        skv.put("path", swarm_path, msg->header.stamp);
	}
	
	void RuntimeCore::subscribe_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg) {
        formation_controller_msgs::TwistIdArray formation_twist;
        formation_twist.header = msg->header;
        formation_twist.twist_ids = msg->twist_ids;
        SharedKV<formation_controller_msgs::TwistIdArray> skv;
        skv.put("all_vels", formation_twist, msg->header.stamp);
	}
	
	void RuntimeCore::subscribe_swarm_heartbeat_local(const swarm_msgs::HB_string::ConstPtr & msg) {
		/*long long robot_id=rth_->getRobotID();

        swarm_msgs::KeyValue sharedKeyValue;
        sharedKeyValue.timestamp = msg->header.stamp;
        sharedKeyValue.key = "heartbeat";
        sharedKeyValue.value = serialize_ros(msg->heartbeat);
	                  
		swarm_msgs::CommPacket p;
		p.packet_source=robot_id;
		p.packet_version=1;
		p.packet_type=SHARED_KEY_VALUE;
		p.packet_data=serialize_ros(sharedKeyValue);
		p.package_check_sum=0;
		rth_->getOutMsgQueue()->pushSharedKeyValueListMsgQueue(p);*/
		//pub_swarm_heartbeat_local_.publish(*msg);

        /*std_msgs::Int32 heartbeat;
        heartbeat.data=msg->heartbeat;
        SharedKV<std_msgs::Int32> skv;
        skv.put("heartbeat", heartbeat, msg->header.stamp);*/

        swarm_msgs::HB_string swarm_heartbeat;
        swarm_heartbeat.hb_string = msg->hb_string;
        SharedKV<swarm_msgs::HB_string> skv;
        skv.put("heartbeat", swarm_heartbeat, msg->header.stamp);
	}
	
    /*void RuntimeCore::subscribe_skv_robot_base_local(const nav_msgs::Odometry::ConstPtr & msg) {
		Base base;
		double x,y,z,xx,yy,zz,ww;
		double vx,vy,vz,roll=0,pitch=0,yaw=0;
		x= msg->pose.pose.position.x;
		y= msg->pose.pose.position.y;
		z= msg->pose.pose.position.z;
		base.x=x;base.y=y;base.z=z;
		base.vx=msg->twist.twist.linear.x;
		base.vy=msg->twist.twist.linear.y;
		base.vz=msg->twist.twist.linear.z;
		xx=msg->pose.pose.orientation.x;
	    yy=msg->pose.pose.orientation.y;
	    zz=msg->pose.pose.orientation.z;
	    ww=msg->pose.pose.orientation.w;
		Quaternion2Euler(xx,yy,zz,ww,roll,pitch,yaw);
		base.yaw = yaw;
		base.roll = roll;
		base.pitch = pitch;
		std::cout<<"roll="<<roll<<",pitch="<<pitch<<",yaw="<<yaw<<std::endl;
		rth_->setRobotBase_skv(base);
	}

    void RuntimeCore::publish_skv_robot_base_local(const ros::TimerEvent&)
    {
		const Base& base=rth_->getRobotBase_skv();
		swarm_msgs::Base msg;
		msg.data=serialize(base); // NOTE[wyz]: since it is local, keep the inefficient Boost serialization ***for now***
		pub_skv_robot_base_local_.publish(msg);
    }*/

    void RuntimeCore::subscribe_skv_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg) {
        formation_controller_msgs::TwistIdArray formation_twist;
        formation_twist.header = msg->header;
        formation_twist.twist_ids = msg->twist_ids;
        SharedKV<formation_controller_msgs::TwistIdArray> skv;
        skv.put("skv_all_vels", formation_twist, msg->header.stamp);
	}

     void RuntimeCore::publish_skv_all_vels(const ros::TimerEvent&)    {
        formation_controller_msgs::TwistIdArray array_msg;
        geometry_msgs::Twist twist_msg;
        ros::Time twist_timestamp;
        static SharedKV<formation_controller_msgs::TwistIdArray> skv;
        if(!skv.get_new("skv_all_vels", array_msg, twist_timestamp)) return;
        array_msg.header.stamp.sec = twist_timestamp.sec;
        array_msg.header.stamp.nsec = twist_timestamp.nsec;
        pub_skv_all_vels.publish(array_msg);
        for(int i = 0;i < array_msg.twist_ids.size();i++){
            if(array_msg.twist_ids[i].id == robot_id_)
            {
                twist_msg.linear.x = array_msg.twist_ids[i].twist.linear.x;
                twist_msg.linear.y = array_msg.twist_ids[i].twist.linear.y;
                twist_msg.linear.z = array_msg.twist_ids[i].twist.linear.z;
                pub_skv_twist.publish(twist_msg);    
            }
        }
	}

    void RuntimeCore::subscribe_skv_swarm_path_local(const swarm_msgs::Path::ConstPtr & msg) {
        swarm_msgs::Path swarm_path;
        swarm_path.points = msg->points;
        SharedKV<swarm_msgs::Path> skv;
        skv.put("skv_path", swarm_path, msg->header.stamp);
	}

    void RuntimeCore::publish_skv_swarm_path_local(const ros::TimerEvent&)    {
        swarm_msgs::Path path_msg;
        ros::Time timestamp;
        static SharedKV<swarm_msgs::Path> skv;
        if(!skv.get_new("skv_path", path_msg, timestamp)) return;
        path_msg.header.stamp.sec=timestamp.sec;
        path_msg.header.stamp.nsec=timestamp.nsec;
        pub_skv_swarm_path_local_.publish(path_msg);
	}

    void RuntimeCore::subscribe_skv_image(const sensor_msgs::Image::ConstPtr & msg) {
        sensor_msgs::Image image;
        image.header = msg->header;
        image.height = msg->height;
        image.width = msg->width;
        image.encoding = msg->encoding;
        image.is_bigendian = msg->is_bigendian;
        image.step = msg->step;
        image.data = msg->data;
        SharedKV<sensor_msgs::Image> skv;
        skv.put("skv_image", image, msg->header.stamp);
	}

    void RuntimeCore::publish_skv_image(const ros::TimerEvent&)    {
        sensor_msgs::Image image_msg;
        ros::Time timestamp;
        static SharedKV<sensor_msgs::Image> skv;
        if(!skv.get_new("skv_image", image_msg, timestamp)) return;
        image_msg.header.stamp.sec=timestamp.sec;
        image_msg.header.stamp.nsec=timestamp.nsec;
        pub_skv_image_.publish(image_msg);
	}

    void RuntimeCore::subscribe_skv_rgb(const orient_softbus_msgs::TotalMovObject::ConstPtr & msg) {
        orient_softbus_msgs::TotalMovObject rgb;
        ros::Time timestamp = ros::Time::now();
        rgb.robot_name = msg->robot_name;
        rgb.persons = msg->persons;
        SharedKV<orient_softbus_msgs::TotalMovObject> skv;
        skv.put("skv_rgb", rgb, timestamp);
	}

    void RuntimeCore::publish_skv_rgb(const ros::TimerEvent&)    {
        orient_softbus_msgs::TotalMovObject rgb_msg;
        ros::Time timestamp;
        static SharedKV<orient_softbus_msgs::TotalMovObject> skv;
        if(!skv.get_new("skv_rgb", rgb_msg, timestamp)) return;
        pub_skv_rgb_.publish(rgb_msg);
	}
    void RuntimeCore::subscribe_get_image(const orient_softbus_msgs::GetImages::ConstPtr & msg) {
        orient_softbus_msgs::GetImages swarm_getImage;
        ros::Time timestamp = ros::Time::now();
        swarm_getImage.img_type = msg->img_type;
        swarm_getImage.publish_freq = msg->publish_freq;
        swarm_getImage.publish_num = msg->publish_num;
        swarm_getImage.begin_time = msg->begin_time;
        swarm_getImage.end_time = msg->end_time;
        SharedKV<orient_softbus_msgs::GetImages> skv;
        skv.put("skv_getImage", swarm_getImage, timestamp);
	}

    void RuntimeCore::publish_get_image(const ros::TimerEvent&)    {
        orient_softbus_msgs::GetImages getImage_msg;
        ros::Time timestamp;
        static SharedKV<orient_softbus_msgs::GetImages> skv;
        if(!skv.get_new("skv_getImage", getImage_msg, timestamp)) return;
        pub_skv_getImage_.publish(getImage_msg);
	}

	void RuntimeCore::publish_swarm_path_local(const ros::TimerEvent&)    {
        /*static ros::Time laststamp;
        ros::Time timestamp;
		std::string value;
		if (!rth_->getSharedKeyValue("path", timestamp, value)) return;
		
		if(laststamp.sec == timestamp.sec && laststamp.nsec == timestamp.nsec)
		    return;
		laststamp.sec = timestamp.sec;
		laststamp.nsec = timestamp.nsec;
		
        swarm_msgs::Path path_msg;
		try {
            path_msg = deserialize_ros<swarm_msgs::Path>(value);
		}
		catch(...) {
			std::cout<<"RuntimeCore::publish_swarm_path_local swarm_path deserialize error"<<std::endl;
		}
		path_msg.header.stamp.sec=timestamp.sec;
		path_msg.header.stamp.nsec=timestamp.nsec;
		//path_msg.points.clear();
		
		ros::Time now=ros::Time::now();
		//static int once=0;
		//if (once==0) {
			pub_swarm_path_local_.publish(path_msg);
	        //once=1;
		//}
		//int expire_sec=3;
		//if (timestamp.sec>now.sec-expire_sec)  pub_swarm_path_local_.publish(path_msg);*/

        swarm_msgs::Path path_msg;
        ros::Time timestamp;
        static SharedKV<swarm_msgs::Path> skv;
        if(!skv.get_new("path", path_msg, timestamp)) return;
        path_msg.header.stamp.sec=timestamp.sec;
        path_msg.header.stamp.nsec=timestamp.nsec;
        pub_swarm_path_local_.publish(path_msg);
	}
	
    void RuntimeCore::publish_all_vels(const ros::TimerEvent&)    {
        formation_controller_msgs::TwistIdArray array_msg;
        geometry_msgs::Twist twist_msg;
        ros::Time twist_timestamp;
        static SharedKV<formation_controller_msgs::TwistIdArray> skv;
        if(!skv.get_new("all_vels", array_msg, twist_timestamp)) return;
        array_msg.header.stamp.sec = twist_timestamp.sec;
        array_msg.header.stamp.nsec = twist_timestamp.nsec;
        //ros::Time begin = array_msg.header.stamp;
        //ros::Time end = ros::Time::now();
        //ros::Duration delay;
        //delay = end - begin;
        
       // static std::ofstream fout("Difference_Of_Time.txt");
        //fout<<"sec: "<<delay.sec<<";  nsec: "<<delay.nsec<<std::endl;

        //std::cout<<"difference of time: "<<"sec: "<<delay.sec<<";nsec: "<<delay.nsec<<std::endl; 
        pub_all_vels.publish(array_msg);
        //for() id ==robot_id_  publisher"velctrl/input" twist
        for(int i = 0;i < array_msg.twist_ids.size();i++){
            if(array_msg.twist_ids[i].id == robot_id_)
            {
                //id_msg.id = array_msg[i].twist_ids.id;
                twist_msg.linear.x = array_msg.twist_ids[i].twist.linear.x;
                twist_msg.linear.y = array_msg.twist_ids[i].twist.linear.y;
                twist_msg.linear.z = array_msg.twist_ids[i].twist.linear.z;
                pub_twist.publish(twist_msg);    
            }
        }
        
	}
	
	void RuntimeCore::publish_swarm_heartbeat_local(const ros::TimerEvent&)    {
        /*ros::Time timestamp;
		std::string value;
		int heartbeat;
		if (!rth_->getSharedKeyValue("heartbeat",timestamp,value)) return;
		try {
			heartbeat = deserialize_ros<int>(value);
		}
		catch (...) {
			std::cout<<"RuntimeCore::publish_swarm_heartbeat_local heartbeat deserialize error"<<std::endl;
		}
		swarm_msgs::Heartbeat heartbeat_msg;
		heartbeat_msg.header.stamp.sec=timestamp.sec;
		heartbeat_msg.header.stamp.nsec=timestamp.nsec;
		heartbeat_msg.heartbeat=heartbeat;
		ros::Time now=ros::Time::now();
		int expire_sec=3;
		if (timestamp.sec>now.sec-expire_sec)
		{
		        std::cout<<"Heartbeat sending..."<<std::endl;  
		        pub_swarm_heartbeat_local_.publish(heartbeat_msg);
		}
		else
		    std::cout<<"Heartbeat timeout,stamp="<<timestamp.sec<<",now="<<now.sec<<std::endl;*/

        swarm_msgs::HB_string heartbeat_msg;
        ros::Time timestamp;
        static SharedKV<swarm_msgs::HB_string> skv; 
        if(!skv.get_new("heartbeat", heartbeat_msg, timestamp)) return;
        heartbeat_msg.header.stamp.sec=timestamp.sec;
        heartbeat_msg.header.stamp.nsec=timestamp.nsec;
        pub_swarm_heartbeat_local_.publish(heartbeat_msg);
	}
    void RuntimeCore::subscribe_new_rosbag(const std_msgs::Int32::ConstPtr& msg){
        std_msgs::Int32 std_hb;
        std_hb.data=msg->data;
        ros::Time timestamp = ros::Time::now();
        SharedKV<std_msgs::Int32> skv;
        skv.put("rosbag_new", std_hb, timestamp);
    }
    void RuntimeCore::publish_new_rosbag(const ros::TimerEvent&){
        std_msgs::Int32 hb_msgs;
        ros::Time timestamp;
        static SharedKV<std_msgs::Int32> skv;
        if(!skv.get_new("rosbag_new",hb_msgs,timestamp)) return;
        pub_new_rosbag_local_.publish(hb_msgs);
    }



////added by Hao
    void RuntimeCore::subscribe_test_take_off(const std_msgs::Empty::ConstPtr & msg) {
        std_msgs::Empty msg_tmp;
        ros::Time timestamp = ros::Time::now();
        SharedKV<std_msgs::Empty> skv;
        skv.put("test_take_off", msg_tmp, timestamp);
	}

    void RuntimeCore::subscribe_test_landing(const std_msgs::Empty::ConstPtr & msg) {
        std_msgs::Empty msg_tmp;
        ros::Time timestamp = ros::Time::now();
        SharedKV<std_msgs::Empty> skv;
        skv.put("test_landing", msg_tmp, timestamp);
	}  

    void RuntimeCore::subscribe_test_cmd_vel(const geometry_msgs::Twist::ConstPtr & msg) {
        geometry_msgs::Twist msg_tmp = *msg;
        ros::Time timestamp = ros::Time::now();
        SharedKV<geometry_msgs::Twist> skv;
        skv.put("test_cmd_vel", msg_tmp, timestamp);
	}   

     void RuntimeCore::subscribe_test_odom(const nav_msgs::Odometry::ConstPtr & msg) {
        nav_msgs::Odometry msg_tmp = *msg;
        ros::Time timestamp = ros::Time::now();
        SharedKV<nav_msgs::Odometry> skv;
        skv.put("test_odom", msg_tmp, timestamp);
	}       

    void RuntimeCore::publish_test_take_off(const ros::TimerEvent&) {
        std_msgs::Empty msgs_;
        ros::Time timestamp;
        static SharedKV<std_msgs::Empty> skv;
        if(!skv.get_new("test_take_off",msgs_,timestamp)) return;
        test_takeoff_pub_.publish(msgs_);
    }

    void RuntimeCore::publish_test_landing(const ros::TimerEvent&) {
        std_msgs::Empty msgs_;
        ros::Time timestamp;
        static SharedKV<std_msgs::Empty> skv;
        if(!skv.get_new("test_landing",msgs_,timestamp)) return;
        test_landing_pub_.publish(msgs_);
    }

    void RuntimeCore::publish_test_cmd_vel(const ros::TimerEvent&) {
        geometry_msgs::Twist msgs_;
        ros::Time timestamp;
        static SharedKV<geometry_msgs::Twist> skv;
        if(!skv.get_new("test_cmd_vel",msgs_,timestamp)) return;
        test_cmd_vel_pub_.publish(msgs_);
    }

    void RuntimeCore::publish_test_odom(const ros::TimerEvent&) {
        nav_msgs::Odometry msgs_;
        ros::Time timestamp;
        static SharedKV<nav_msgs::Odometry> skv;
        if(!skv.get_new("test_odom",msgs_,timestamp)) return;      
        test_odom_pub_.publish(msgs_);
    }
////



    void RuntimeCore::initialize()
    {
        setParameters();
        //construct runtime platform
        rth_=Singleton<RuntimeHandle>::getSingleton(robot_id_);
        //rth_=Singleton<RuntimeHandle>::getSingleton(rand()%1000);
        rth_->setNeighborDistance(default_neighbor_distance_);
        //construct communicator
        communicator_ = ci_loader_.createInstance(comm_type_);
        Singleton<CommInterface>::makeSingleton(communicator_);
        //construct packet parser
        parser_ = Singleton<PacketParser>::getSingleton();
        //initialize the communicator
        communicator_->init(comm_type_, *parser_);
        communicator_->receive();
        //construct app manager
        app_manager_=Singleton<AppManager>::getSingleton();
        
       
	
        //--------------------------
        //local inter-process communication
        //subscribe the pose/vel inform from physics-layer drivers	
        //redirect the message /uav/${r_id}/position to /robot_base_driver (refer to local_manager.cpp)?
        sub_robot_base_local_=node_handle_.subscribe("/global_odom",1000,&RuntimeCore::subscribe_robot_base_local,this);
        pub_robot_base_local_=node_handle_.advertise<swarm_msgs::Base>("/robot_base_physics_layer",1000);
        pub_robot_base_local_timer_=node_handle_.createTimer(ros::Duration(pub_robot_base_local_duration_), &RuntimeCore::publish_robot_base_local, this);

        //publish the neighbour inform list including the ids and their base
        //redirect the message /uav/${r_id}/neighbor to /robot_neighbour_info
        pub_neighbour_bases_local_=node_handle_.advertise<swarm_msgs::NeighbourBases>("/robot_neighbour_bases",1000);
        //

        sub_swarm_heartbeat_local_=node_handle_.subscribe("/heartbeat_ground_station_string",1000,&RuntimeCore::subscribe_swarm_heartbeat_local,this);
        pub_swarm_heartbeat_local_=node_handle_.advertise<swarm_msgs::HB_string>("/swarm_heartbeat_string",1000);
        //
        sub_new_rosbag_local_=node_handle_.subscribe("/new_rosbag",1000,&RuntimeCore::subscribe_new_rosbag,this);
        pub_new_rosbag_local_=node_handle_.advertise<std_msgs::Int32>("/new_rosbag_record",1000);

        // sub_swarm_path_local_=node_handle_.subscribe("/path_ground_station",1000,&RuntimeCore::subscribe_swarm_path_local,this);
        // pub_swarm_path_local_=node_handle_.advertise<swarm_msgs::Path>("/swarm_path",1000);
        
        // sub_all_vels=node_handle_.subscribe("/all_vels",1000,&RuntimeCore::subscribe_all_vels,this);
        // pub_all_vels=node_handle_.advertise<formation_controller_msgs::TwistIdArray>("/test_all_vels",1000);
        
        // pub_twist = node_handle_.advertise<geometry_msgs::Twist>("/velctrl/input",1000);
        
        
        //service to get the local ID
        service_get_robot_id_local_=node_handle_.advertiseService("/get_robot_id",&RuntimeCore::service_get_robot_id_local_cb,this);
        //timers  durations not set
            
        pub_swarm_heartbeat_local_timer_=node_handle_.createTimer(ros::Duration(pub_swarm_heartbeat_local_duration_), &RuntimeCore::publish_swarm_heartbeat_local, this);
        //pub_swarm_path_local_timer_=node_handle_.createTimer(ros::Duration(pub_swarm_path_local_duration_), &RuntimeCore::publish_swarm_path_local, this);
        //pub_all_vels_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_all_vels, this);
        pub_neighbour_bases_local_timer_=node_handle_.createTimer(ros::Duration(pub_neighbour_bases_local_duration_), &RuntimeCore::publish_neighbour_bases_local, this);
        pub_new_rosbag_local_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_new_rosbag, this);

        //--------------------------

        //sub_skv_robot_base_local_=node_handle_.subscribe("/skv/odom",1000,&RuntimeCore::subscribe_skv_robot_base_local,this);
       // pub_skv_robot_base_local_=node_handle_.advertise<swarm_msgs::Base>("/uav/skv/odom",1000);
        //pub_skv_robot_base_local_timer_=node_handle_.createTimer(ros::Duration(pub_robot_base_local_duration_), &RuntimeCore::publish_skv_robot_base_local, this);

        sub_skv_swarm_path_local_=node_handle_.subscribe("/skv/path_ground_station",1000,&RuntimeCore::subscribe_skv_swarm_path_local,this);
        pub_skv_swarm_path_local_=node_handle_.advertise<swarm_msgs::Path>("/station/skv/path_ground_station",1000);
        
        sub_skv_all_vels=node_handle_.subscribe("/skv/all_vels",1000,&RuntimeCore::subscribe_skv_all_vels,this);
        pub_skv_all_vels=node_handle_.advertise<formation_controller_msgs::TwistIdArray>("/station/skv/all_vels",1000);

        //sub_skv_image=node_handle_.subscribe("/skv/ImagequeryResult",1000,&RuntimeCore::subscribe_skv_image,this);
        //pub_skv_image_=node_handle_.advertise<sensor_msgs::Image>("/uav/skv/ImagequeryResult",1000);

        sub_skv_rgb=node_handle_.subscribe("/skv/detected/movobjects_rgb",1000,&RuntimeCore::subscribe_skv_rgb,this);
        pub_skv_rgb_=node_handle_.advertise<orient_softbus_msgs::TotalMovObject>("/uav/skv/detected/movobjects_rgb",1000);
        
        pub_skv_twist = node_handle_.advertise<geometry_msgs::Twist>("/velctrl/input",1000);

        sub_skv_getImage=node_handle_.subscribe("/skv/observer/getImages",1000,&RuntimeCore::subscribe_get_image,this);
        pub_skv_getImage_=node_handle_.advertise<orient_softbus_msgs::GetImages>("/station/skv/observer/getImages",1000);

        pub_skv_swarm_path_local_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_swarm_path_local, this);
        pub_skv_all_vels_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_all_vels, this);
        pub_skv_image_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_image, this);
        pub_skv_rgb_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_rgb, this);
        pub_skv_getImage_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_get_image,this);


/////added by Hao
  test_takeoff_pub_ = node_handle_.advertise<std_msgs::Empty>("/takeoff", 1);
  test_takeoff_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_take_off,this);  
  test_takeoff_sub_ = node_handle_.subscribe("/test_takeoff",1000,&RuntimeCore::subscribe_test_take_off,this);  

  test_landing_pub_ = node_handle_.advertise<std_msgs::Empty>("/land", 1);
  test_landing_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_landing,this); 
  test_landing_sub_ = node_handle_.subscribe("/test_landing",1000,&RuntimeCore::subscribe_test_landing,this);  

  test_cmd_vel_pub_ = node_handle_.advertise<geometry_msgs::Twist>("/velctrl/input", 1000);
  test_cmd_vel_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_cmd_vel,this);  
  test_cmd_vel_sub_ = node_handle_.subscribe("/fixedwing/cmd_vel",1000,&RuntimeCore::subscribe_test_cmd_vel,this);  

  test_odom_pub_ = node_handle_.advertise<nav_msgs::Odometry>("/test/odom", 1000);
  test_odom_pub_timer_=node_handle_.createTimer(ros::Duration(0.2), &RuntimeCore::publish_test_odom,this); 
  test_odom_sub_ = node_handle_.subscribe("/odom",1000,&RuntimeCore::subscribe_test_odom,this);     
/////


        spin_thread_ = new boost::thread(&RuntimeCore::spin_msg_queue, this);

        publish_robot_base_timer_ = node_handle_.createTimer(ros::Duration(publish_robot_base_duration_), &RuntimeCore::publish_robot_base, this);
        //publish_swarm_list_timer_ = node_handle_.createTimer(ros::Duration(publish_swarm_list_duration_), &RuntimeCore::publish_swarm_list, this);
        //publish_neighbour_list_timer_ = node_handle_.createTimer(ros::Duration(publish_neighbour_list_duration_), &RuntimeCore::publish_neighbour_list, this); 
        //barrier_timer_=node_handle_.createTimer(ros::Duration(1), &RuntimeCore::barrier_check, this);
    }
};
