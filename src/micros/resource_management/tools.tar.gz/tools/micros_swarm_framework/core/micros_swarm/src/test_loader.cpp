/*
 * test_loader.cpp
 *
 *  Created on: Jun 12, 2018
 *      Author: Jun Cai
 */

#include <ros/ros.h>
#include <pluginlib/class_loader.h>
#include "micros_swarm/packet_parser.h"
#include "micros_swarm/comm_interface.h"


int main(int argc, char ** argv)
{
	ros::init(argc, argv, "test_loader");
	ros::NodeHandle nh;

	std::string param_name = "comm_type_";
	std::string plugin_class;


	if(!nh.getParam(param_name.c_str(), plugin_class))
	{
		ROS_ERROR("can't get param");
		return 0;
	}

	/**
	 * Define plugin loader object for loading the plugin.
	 * param1: the path of plugin package, param2:the base class of plugin class with full name
	 */
	pluginlib::ClassLoader<micros_swarm::CommInterface> test_loader("micros_swarm", "micros_swarm::CommInterface");

	try
	{
		/*Based on input param to create the corresponding plugin instance by ClassLoader*/
		boost::shared_ptr<micros_swarm::CommInterface> broker = test_loader.createInstance(plugin_class);
		boost::shared_ptr<micros_swarm::PacketParser> parser_;
		parser_ = micros_swarm::Singleton<micros_swarm::PacketParser>::getSingleton();
		broker->init(plugin_class,*parser_);
		ROS_INFO("success loading %s!",plugin_class.c_str());
		broker->receive();
	}

   /*catch exception ClassLaoder object(polygon_loader) exception*/
	catch(pluginlib::PluginlibException& ex)
	{
		ROS_ERROR("The plugin failed to load for some reason. Error: %s", ex.what());
	}

	return 0;
}


