/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai, Xuefeng Chang
 *********************************************************************/

#include "micros_swarm/runtime_core.h"

namespace micros_swarm{
    RuntimeCore::RuntimeCore():ci_loader_("micros_swarm", "micros_swarm::CommInterface") {

    	vs= micros_swarm::VirtualStigmergy(1);
    	/*vs1= micros_swarm::VirtualStigmergy<gsdf_msgs::Path>(1);
        vs2= micros_swarm::VirtualStigmergy<formation_controller_msgs::TwistIdArray>(2);
        vs3= micros_swarm::VirtualStigmergy<gsdf_msgs::HB_string>(3);
        vs4= micros_swarm::VirtualStigmergy<sensor_msgs::Image>(4);
        vs5= micros_swarm::VirtualStigmergy<orient_softbus_msgs::TotalMovObject>(5);
        vs6= micros_swarm::VirtualStigmergy<orient_softbus_msgs::GetImages>(6);
        vs7= micros_swarm::VirtualStigmergy<std_msgs::Int32>(7);*/
    }

    RuntimeCore::~RuntimeCore() {}
    
    void RuntimeCore::spin_msg_queue()
    {
        for(;;) {
            std::vector<std::vector<uint8_t> > msg_vec;
            msg_queue_manager_->spinAllOutMsgQueueOnce(msg_vec);
            for(int i = 0; i < msg_vec.size(); i++) {
                communicator_->broadcast(msg_vec[i]);
            }
        }
    }
    
    void RuntimeCore::barrier_check(const ros::TimerEvent&)
    {
        int barrier_size = rth_->getBarrierSize();
        if(barrier_size >= total_robot_numbers_-1) {
            std::cout<<"robot "<<rth_->getRobotID()<<" daemon node start."<<std::endl;
            barrier_timer_.stop();
        }
                
        //barrier
        int robot_id = rth_->getRobotID();
    
        std::string syn="SYN";
        gsdf_msgs::BarrierSyn bs;
        bs.s = syn;
        std::vector<uint8_t> bs_vec = serialize_ros(bs);
    
        gsdf_msgs::CommPacket p;
        p.header.source = robot_id;
        p.header.type = micros_swarm::BARRIER_SYN;
        p.header.data_len = bs_vec.size();
        p.header.version = 1;
        p.header.checksum = 0;
        p.content.buf = bs_vec;
        std::vector<uint8_t> msg_data = serialize_ros(p);
        msg_queue_manager_->getOutMsgQueue("barrier")->push(msg_data);
    }
    
    void RuntimeCore::publish_robot_base(const ros::TimerEvent&)
    {
        int robot_id = rth_->getRobotID();
        const Base& l = rth_->getRobotBase();
        gsdf_msgs::RobotBase rb;
        rb.id = robot_id;
        rb.px = l.x;
        rb.py = l.y;
        rb.pz = l.z;
        rb.vx = l.vx;
        rb.vy = l.vy;
        rb.vz = l.vz;
        rb.theta = 0;
        rb.valid = l.valid;
        std::vector<uint8_t> rb_vec = serialize_ros(rb);
                      
        gsdf_msgs::CommPacket p;
        p.header.source = robot_id;
        p.header.type = SINGLE_ROBOT_BROADCAST_BASE;
        p.header.data_len = rb_vec.size();
        p.header.version = 1;
        p.header.checksum = 0;
        p.content.buf = rb_vec;
        std::vector<uint8_t> msg_data = serialize_ros(p);
        //printf("pub a robot base packet, length: %d.\n",msg_data.size());
        msg_queue_manager_->getOutMsgQueue("base")->push(msg_data);
    }
    
    void RuntimeCore::publish_swarm_list(const ros::TimerEvent&)
    {
        int robot_id = rth_->getRobotID();
        std::vector<int> swarm_list;
        swarm_list.clear();
        rth_->getSwarmList(swarm_list);
        
        gsdf_msgs::SwarmList sl;
        sl.robot_id = robot_id;
        sl.swarm_list = swarm_list;
        std::vector<uint8_t> sl_vec = serialize_ros(sl);
                      
        gsdf_msgs::CommPacket p;
        p.header.source = robot_id;
        p.header.type = SINGLE_ROBOT_SWARM_LIST;
        p.header.data_len = sl_vec.size();
        p.header.version = 1;
        p.header.checksum = 0;
        p.content.buf = sl_vec;
        std::vector<uint8_t> msg_data = serialize_ros(p);
        //printf("pub a swarm list packet, length: %d.\n",msg_data.size());
        msg_queue_manager_->getOutMsgQueue("swarm")->push(msg_data);
    }
    
    void RuntimeCore::setParameters()
    {
        bool param_ok = node_handle_.getParam("/publish_robot_id_duration", publish_robot_base_duration_);
        if(!param_ok) {
            std::cout<<"could not get parameter publish_robot_id_duration! use the default value."<<std::endl;
            publish_robot_base_duration_ = 0.1;
        }
        else {
            std::cout<<"publish_robot_id_duration: "<<publish_robot_base_duration_<<std::endl;
        }
        
        param_ok = node_handle_.getParam("/publish_swarm_list_duration", publish_swarm_list_duration_);
        if(!param_ok) {
            std::cout<<"could not get parameter publish_swarm_list_duration! use the default value."<<std::endl;
            publish_swarm_list_duration_ = 5.0;
        }
        else {
            std::cout<<"publish_swarm_list_duration: "<<publish_swarm_list_duration_<<std::endl;
        }
        
        param_ok = node_handle_.getParam("/default_neighbor_distance", default_neighbor_distance_);
        if(!param_ok) {
            std::cout<<"could not get parameter default_neighbor_distance! use the default value."<<std::endl;
            default_neighbor_distance_ = 50;
        }
        else {
            std::cout<<"default_neighbor_distance: "<<default_neighbor_distance_<<std::endl;
        }
        
        param_ok = node_handle_.getParam("/total_robot_numbers", total_robot_numbers_);
        if(!param_ok) {
            std::cout<<"could not get parameter total_robot_numbers! use the default value."<<std::endl;
            total_robot_numbers_ = 1;
        }
        else {
            std::cout<<"total_robot_numbers: "<<total_robot_numbers_<<std::endl;
        }

        param_ok = node_handle_.getParam("/comm_type", comm_type_);
        if(!param_ok) {
            std::cout<<"could not get parameter comm_type, use the default ros_comm."<<std::endl;
            //comm_type_ = "ros_comm/ROSComm";
            comm_type_ = "udp_bc_broker/UDPBCBroker";
        }
        else {
            std::cout<<"comm_type: "<<comm_type_<<std::endl;
        }

        ros::NodeHandle private_nh("~");
        private_nh.param("robot_id", robot_id_, 0);
        std::cout<<"robot_id: "<<robot_id_<<std::endl;
        private_nh.param("worker_num", worker_num_, 4);
        std::cout<<"worker_num: "<<worker_num_<<std::endl;
    }
    
//////////////////////////////
	void Quaternion2Euler(double x,double y, double z, double w,double &roll, double &pitch,double &yaw) {
	//void Quaternion2Euler(float x,float y, float z, float w,float &roll, float &pitch,float &yaw) {
		//not implemented
		geometry_msgs::Quaternion q;
		q.x =x;q.y=y;q.z=z;q.w=w;
		yaw = tf::getYaw(q);
		ROS_INFO("void Quaternion2Euler only yaw implemented");
	}

	void RuntimeCore::subscribe_robot_base_local(const nav_msgs::Odometry::ConstPtr & msg) {
		Base base;
		double x,y,z,xx,yy,zz,ww;
		double vx,vy,vz,roll=0,pitch=0,yaw=0;

		x= msg->pose.pose.position.x;
		y= msg->pose.pose.position.y;
		z= msg->pose.pose.position.z;
		base.x=x;base.y=y;base.z=z;
		base.vx=msg->twist.twist.linear.x;
		base.vy=msg->twist.twist.linear.y;
		base.vz=msg->twist.twist.linear.z;
		xx=msg->pose.pose.orientation.x;
	    yy=msg->pose.pose.orientation.y;
	    zz=msg->pose.pose.orientation.z;
	    ww=msg->pose.pose.orientation.w;
		Quaternion2Euler(xx,yy,zz,ww,roll,pitch,yaw);
		base.yaw = yaw;
		base.roll = roll;
		base.pitch = pitch;
		std::cout<<"roll="<<roll<<",pitch="<<pitch<<",yaw="<<yaw<<std::endl;
		rth_->setRobotBase(base);
	}


	bool RuntimeCore::service_get_robot_id_local_cb(gsdf_msgs::GetID::Request&req,
											gsdf_msgs::GetID::Response& res) {
		res.robot_id=rth_->getRobotID();
		return true;
	}


   //local inter-processes comm
   //user need to deserialize the data
   void RuntimeCore::publish_neighbour_bases_local(const ros::TimerEvent&)
    {
        long long robot_id=rth_->getRobotID();
        std::map<int, NeighborBase> data;
	 	data.clear();
		rth_->getNeighbors(data);
		gsdf_msgs::NeighbourBases msg;
	 	//msg.data=serialize(data); // NOTE[wyz]: since it is local, keep the inefficient Boost serialization ***for now***
	 	msg.data=serialize_boost(data);
	 	pub_neighbour_bases_local_.publish(msg);
    }

    // local inter-processes comm
    // user need to deserialize the data
    void RuntimeCore::publish_robot_base_local(const ros::TimerEvent&)
    {
		const Base& base=rth_->getRobotBase();
		gsdf_msgs::Base msg;
		//msg.data=serialize(base); // NOTE[wyz]: since it is local, keep the inefficient Boost serialization ***for now***
		msg.data=serialize_boost(base);
		pub_robot_base_local_.publish(msg);
    }


	//ros msg from ground station, and bcast with UDP
	void RuntimeCore::subscribe_swarm_path_local(const gsdf_msgs::Path::ConstPtr & msg) {

		gsdf_msgs::Path swarm_path;
        swarm_path.points = msg->points;
        //SharedKV<gsdf_msgs::Path> skv;
        //micros_swarm::VirtualStigmergy<gsdf_msgs::Path> vs(1);
        //skv.put("path", swarm_path, msg->header.stamp);
        //vs1.put("path",swarm_path);
        vs.put<gsdf_msgs::Path>("path",swarm_path);
	}

	void RuntimeCore::publish_swarm_path_local(const ros::TimerEvent&)    {

		gsdf_msgs::Path path_msg;
        ros::Time timestamp;
        //static SharedKV<swarm_msgs::Path> skv;
        //if(!skv.get_new("path", path_msg, timestamp)) return;

        //path_msg=vs1.get("path");
        //if(!vs1.get_new("path", path_msg)) return;
        if(!vs.get_new<gsdf_msgs::Path>("path", path_msg)) return;
        path_msg.header.stamp.sec=timestamp.sec;
        path_msg.header.stamp.nsec=timestamp.nsec;
        pub_swarm_path_local_.publish(path_msg);
	}

    void RuntimeCore::subscribe_skv_swarm_path_local(const gsdf_msgs::Path::ConstPtr & msg) {
    	gsdf_msgs::Path swarm_path;
        swarm_path.points = msg->points;
        //SharedKV<swarm_msgs::Path> skv;
        //skv.put("skv_path", swarm_path, msg->header.stamp);
        //micros_swarm::VirtualStigmergy<gsdf_msgs::Path> vs(1);
        //vs1.put("skv_path",swarm_path);
        vs.put<gsdf_msgs::Path>("skv_path",swarm_path);
	}

    void RuntimeCore::publish_skv_swarm_path_local(const ros::TimerEvent&)    {
    	gsdf_msgs::Path path_msg;
        ros::Time timestamp;
        //static SharedKV<swarm_msgs::Path> skv;
        //if(!skv.get_new("skv_path", path_msg, timestamp)) return;

        //if(!vs1.get_new("skv_path", path_msg)) return;
        if(!vs.get_new<gsdf_msgs::Path>("skv_path", path_msg)) return;
        path_msg.header.stamp.sec=timestamp.sec;
        path_msg.header.stamp.nsec=timestamp.nsec;
        pub_skv_swarm_path_local_.publish(path_msg);
	}

	void RuntimeCore::subscribe_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg) {
        formation_controller_msgs::TwistIdArray formation_twist;
        formation_twist.header = msg->header;
        formation_twist.twist_ids = msg->twist_ids;
        //SharedKV<formation_controller_msgs::TwistIdArray> skv;
        //skv.put("all_vels", formation_twist, msg->header.stamp);
        //micros_swarm::VirtualStigmergy<formation_controller_msgs::TwistIdArray> vs(2);
        //vs2.put("all_vels",formation_twist);
        vs.put<formation_controller_msgs::TwistIdArray>("all_vels",formation_twist);
	}

    void RuntimeCore::publish_all_vels(const ros::TimerEvent&)    {
        formation_controller_msgs::TwistIdArray array_msg;
        geometry_msgs::Twist twist_msg;
        ros::Time twist_timestamp;
        //static SharedKV<formation_controller_msgs::TwistIdArray> skv;
        //if(!skv.get_new("all_vels", array_msg, twist_timestamp)) return;

        //array_msg=vs2.get("all_vels");
        //if(!vs2.get_new("all_vels", array_msg)) return;
        if(!vs.get_new<formation_controller_msgs::TwistIdArray>("all_vels", array_msg)) return;
        array_msg.header.stamp.sec = twist_timestamp.sec;
        array_msg.header.stamp.nsec = twist_timestamp.nsec;
        pub_all_vels.publish(array_msg);
        //for() id ==robot_id_  publisher"velctrl/input" twist
        for(int i = 0;i < array_msg.twist_ids.size();i++){
            if(array_msg.twist_ids[i].id == robot_id_)
            {
                //id_msg.id = array_msg[i].twist_ids.id;
                twist_msg.linear.x = array_msg.twist_ids[i].twist.linear.x;
                twist_msg.linear.y = array_msg.twist_ids[i].twist.linear.y;
                twist_msg.linear.z = array_msg.twist_ids[i].twist.linear.z;
                pub_twist.publish(twist_msg);
            }
        }

	}

    void RuntimeCore::subscribe_skv_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg) {
        formation_controller_msgs::TwistIdArray formation_twist;
        formation_twist.header = msg->header;
        formation_twist.twist_ids = msg->twist_ids;
        //SharedKV<formation_controller_msgs::TwistIdArray> skv;
        //skv.put("skv_all_vels", formation_twist, msg->header.stamp);
        //micros_swarm::VirtualStigmergy<formation_controller_msgs::TwistIdArray> vs(2);
        //vs2.put("skv_all_vels",formation_twist);
        vs.put<formation_controller_msgs::TwistIdArray>("skv_all_vels",formation_twist);
	}

    void RuntimeCore::publish_skv_all_vels(const ros::TimerEvent&)    {
        formation_controller_msgs::TwistIdArray array_msg;
        geometry_msgs::Twist twist_msg;
        ros::Time twist_timestamp;
        //static SharedKV<formation_controller_msgs::TwistIdArray> skv;
        //if(!skv.get_new("skv_all_vels", array_msg, twist_timestamp)) return;
        //array_msg=vs2.get("skv_all_vels");
        //if(!vs2.get_new("skv_all_vels", array_msg)) return;
        if(!vs.get_new<formation_controller_msgs::TwistIdArray>("skv_all_vels", array_msg)) return;

        array_msg.header.stamp.sec = twist_timestamp.sec;
        array_msg.header.stamp.nsec = twist_timestamp.nsec;
        pub_skv_all_vels.publish(array_msg);
        for(int i = 0;i < array_msg.twist_ids.size();i++){
            if(array_msg.twist_ids[i].id == robot_id_)
            {
                twist_msg.linear.x = array_msg.twist_ids[i].twist.linear.x;
                twist_msg.linear.y = array_msg.twist_ids[i].twist.linear.y;
                twist_msg.linear.z = array_msg.twist_ids[i].twist.linear.z;
                pub_skv_twist.publish(twist_msg);
            }
        }
	}

	void RuntimeCore::subscribe_swarm_heartbeat_local(const gsdf_msgs::HB_string::ConstPtr & msg) {

		gsdf_msgs::HB_string swarm_heartbeat;
        swarm_heartbeat.hb_string = msg->hb_string;
        //SharedKV<swarm_msgs::HB_string> skv;
        //skv.put("heartbeat", swarm_heartbeat, msg->header.stamp);
        //micros_swarm::VirtualStigmergy<gsdf_msgs::HB_string> vs(3);
        //vs3.put("heartbeat",swarm_heartbeat);
        vs.put<gsdf_msgs::HB_string>("heartbeat",swarm_heartbeat);
	}

	void RuntimeCore::publish_swarm_heartbeat_local(const ros::TimerEvent&)    {

		gsdf_msgs::HB_string heartbeat_msg;
        ros::Time timestamp;
        //static SharedKV<swarm_msgs::HB_string> skv;
        //if(!skv.get_new("heartbeat", heartbeat_msg, timestamp)) return;

        //heartbeat_msg=vs3.get("heartbeat");
        //if(!vs3.get_new("heartbeat", heartbeat_msg)) return;
        if(!vs.get_new<gsdf_msgs::HB_string>("heartbeat", heartbeat_msg)) return;
        heartbeat_msg.header.stamp.sec=timestamp.sec;
        heartbeat_msg.header.stamp.nsec=timestamp.nsec;
        pub_swarm_heartbeat_local_.publish(heartbeat_msg);
	}

    void RuntimeCore::subscribe_skv_image(const sensor_msgs::Image::ConstPtr & msg) {
        sensor_msgs::Image image;
        image.header = msg->header;
        image.height = msg->height;
        image.width = msg->width;
        image.encoding = msg->encoding;
        image.is_bigendian = msg->is_bigendian;
        image.step = msg->step;
        image.data = msg->data;
        //SharedKV<sensor_msgs::Image> skv;
        //skv.put("skv_image", image, msg->header.stamp);
        //micros_swarm::VirtualStigmergy<sensor_msgs::Image> vs(4);
        //vs4.put("skv_image",image);
        vs.put<sensor_msgs::Image>("skv_image",image);
	}


    void RuntimeCore::publish_skv_image(const ros::TimerEvent&)    {
        sensor_msgs::Image image_msg;
        ros::Time timestamp;
        //static SharedKV<sensor_msgs::Image> skv;
        //if(!skv.get_new("skv_image", image_msg, timestamp)) return;

        //image_msg=vs4.get("skv_image");
        //if(!vs4.get_new("skv_image", image_msg)) return;
        if(!vs.get_new<sensor_msgs::Image>("skv_image", image_msg)) return;
        image_msg.header.stamp.sec=timestamp.sec;
        image_msg.header.stamp.nsec=timestamp.nsec;
        pub_skv_image_.publish(image_msg);
	}

    void RuntimeCore::subscribe_skv_rgb(const orient_softbus_msgs::TotalMovObject::ConstPtr & msg) {
        orient_softbus_msgs::TotalMovObject rgb;
        ros::Time timestamp = ros::Time::now();
        rgb.robot_name = msg->robot_name;
        rgb.persons = msg->persons;
        //SharedKV<orient_softbus_msgs::TotalMovObject> skv;
        //skv.put("skv_rgb", rgb, timestamp);
        //micros_swarm::VirtualStigmergy<orient_softbus_msgs::TotalMovObject> vs(5);
        //vs5.put("skv_rgb",rgb);
        vs.put<orient_softbus_msgs::TotalMovObject>("skv_rgb",rgb);
	}


    void RuntimeCore::publish_skv_rgb(const ros::TimerEvent&)    {
        orient_softbus_msgs::TotalMovObject rgb_msg;
        ros::Time timestamp;
        //static SharedKV<orient_softbus_msgs::TotalMovObject> skv;
        //if(!skv.get_new("skv_rgb", rgb_msg, timestamp)) return;

        //rgb_msg=vs5.get("skv_rgb");
        //if(!vs5.get_new("skv_rgb", rgb_msg)) return;
        if(!vs.get_new<orient_softbus_msgs::TotalMovObject>("skv_rgb", rgb_msg)) return;
        pub_skv_rgb_.publish(rgb_msg);
	}


    void RuntimeCore::subscribe_get_image(const orient_softbus_msgs::GetImages::ConstPtr & msg) {
        orient_softbus_msgs::GetImages swarm_getImage;
        ros::Time timestamp = ros::Time::now();
        swarm_getImage.img_type = msg->img_type;
        swarm_getImage.publish_freq = msg->publish_freq;
        swarm_getImage.publish_num = msg->publish_num;
        swarm_getImage.begin_time = msg->begin_time;
        swarm_getImage.end_time = msg->end_time;
        //SharedKV<orient_softbus_msgs::GetImages> skv;
        //skv.put("skv_getImage", swarm_getImage, timestamp);
        //micros_swarm::VirtualStigmergy<orient_softbus_msgs::GetImages> vs(6);
        //vs6.put("skv_getImage",swarm_getImage);
        vs.put<orient_softbus_msgs::GetImages>("skv_getImage",swarm_getImage);
	}


    void RuntimeCore::publish_get_image(const ros::TimerEvent&)    {
        orient_softbus_msgs::GetImages getImage_msg;
        ros::Time timestamp;
        //static SharedKV<orient_softbus_msgs::GetImages> skv;
        //if(!skv.get_new("skv_getImage", getImage_msg, timestamp)) return;

        //getImage_msg=vs6.get("skv_getImage");
        //if(!vs6.get_new("skv_getImage", getImage_msg)) return;
        if(!vs.get_new<orient_softbus_msgs::GetImages>("skv_getImage", getImage_msg)) return;
        pub_skv_getImage_.publish(getImage_msg);
	}

    void RuntimeCore::subscribe_new_rosbag(const std_msgs::Int32::ConstPtr& msg){
        std_msgs::Int32 std_hb;
        std_hb.data=msg->data;
        //ros::Time timestamp = ros::Time::now();
        //SharedKV<std_msgs::Int32> skv;
        //skv.put("rosbag_new", std_hb, timestamp);
        //micros_swarm::VirtualStigmergy<std_msgs::Int32> vs(7);
        //vs7.put("rosbag_new",std_hb);
        vs.put<std_msgs::Int32>("rosbag_new",std_hb);
    }


    void RuntimeCore::publish_new_rosbag(const ros::TimerEvent&){
        std_msgs::Int32 hb_msgs;
        ros::Time timestamp;
        //static SharedKV<std_msgs::Int32> skv;
        //if(!skv.get_new("rosbag_new",hb_msgs,timestamp)) return;

        //hb_msgs=vs7.get("rosbag_new");
        //if(!vs7.get_new("rosbag_new", hb_msgs)) return;
        if(!vs.get_new<std_msgs::Int32>("rosbag_new", hb_msgs)) return;
        pub_new_rosbag_local_.publish(hb_msgs);
    }

/////////////////////////////////////////////

    ////added by Hao////////////////////
        void RuntimeCore::subscribe_test_take_off(const std_msgs::Empty::ConstPtr & msg) {
            std_msgs::Empty msg_tmp;
            //ros::Time timestamp = ros::Time::now();
            //SharedKV<std_msgs::Empty> skv;
            //skv.put("test_take_off", msg_tmp, timestamp);
            vs.put("test_take_off", msg_tmp);
    	}

        void RuntimeCore::subscribe_test_landing(const std_msgs::Empty::ConstPtr & msg) {
            std_msgs::Empty msg_tmp;
            //ros::Time timestamp = ros::Time::now();
            //SharedKV<std_msgs::Empty> skv;
            //skv.put("test_landing", msg_tmp, timestamp);
            vs.put("test_landing", msg_tmp);
    	}

        void RuntimeCore::subscribe_test_cmd_vel(const geometry_msgs::Twist::ConstPtr & msg) {
            geometry_msgs::Twist msg_tmp = *msg;
            //ros::Time timestamp = ros::Time::now();
            //SharedKV<geometry_msgs::Twist> skv;
            //skv.put("test_cmd_vel", msg_tmp, timestamp);
            vs.put("test_cmd_vel", msg_tmp);
    	}

         void RuntimeCore::subscribe_test_odom(const nav_msgs::Odometry::ConstPtr & msg) {
            nav_msgs::Odometry msg_tmp = *msg;
            //ros::Time timestamp = ros::Time::now();
            //SharedKV<nav_msgs::Odometry> skv;
            //skv.put("test_odom", msg_tmp, timestamp);
            vs.put("test_odom", msg_tmp);
    	}

        void RuntimeCore::publish_test_take_off(const ros::TimerEvent&) {
            std_msgs::Empty msgs_;
            //ros::Time timestamp;
            //static SharedKV<std_msgs::Empty> skv;
            //if(!skv.get_new("test_take_off",msgs_,timestamp)) return;
            if(!vs.get_new<std_msgs::Empty>("test_take_off", msgs_)) return;
            test_takeoff_pub_.publish(msgs_);
        }

        void RuntimeCore::publish_test_landing(const ros::TimerEvent&) {
            std_msgs::Empty msgs_;
            //ros::Time timestamp;
            //static SharedKV<std_msgs::Empty> skv;
            //if(!skv.get_new("test_landing",msgs_,timestamp)) return;
            if(!vs.get_new<std_msgs::Empty>("test_landing",msgs_)) return;
            test_landing_pub_.publish(msgs_);
        }

        void RuntimeCore::publish_test_cmd_vel(const ros::TimerEvent&) {
            geometry_msgs::Twist msgs_;
            //ros::Time timestamp;
            //static SharedKV<geometry_msgs::Twist> skv;
            //if(!skv.get_new("test_cmd_vel",msgs_,timestamp)) return;
            if(!vs.get_new<geometry_msgs::Twist>("test_cmd_vel",msgs_)) return;
            test_cmd_vel_pub_.publish(msgs_);
        }

        void RuntimeCore::publish_test_odom(const ros::TimerEvent&) {
            nav_msgs::Odometry msgs_;
            //ros::Time timestamp;
            //static SharedKV<nav_msgs::Odometry> skv;
            //if(!skv.get_new("test_odom",msgs_,timestamp)) return;
            if(!vs.get_new<nav_msgs::Odometry>("test_odom",msgs_)) return;
            test_odom_pub_.publish(msgs_);
        }
    ////////////////////////



    void RuntimeCore::initialize()
    {
        //srand(time(NULL) + robot_id_);
        srand(time(NULL) + (int)getpid());
        setParameters();
        //construct runtime platform
        rth_ = Singleton<RuntimeHandle>::getSingleton();
        rth_->setRobotID(robot_id_);
        rth_->setNeighborDistance(default_neighbor_distance_);
        //construct packet parser
        parser_ = Singleton<PacketParser>::getSingleton();
        //construct communicator
        communicator_ = ci_loader_.createInstance(comm_type_);
        communicator_->init(comm_type_, *parser_);
        communicator_->receive();
        //construct message queue manager
        msg_queue_manager_ = Singleton<MsgQueueManager>::getSingleton();
        msg_queue_manager_->createOutMsgQueue("base", 1000);
        msg_queue_manager_->createOutMsgQueue("swarm", 1000);
        msg_queue_manager_->createOutMsgQueue("vstig", 50000);
        msg_queue_manager_->createOutMsgQueue("bb", 10000);
        msg_queue_manager_->createOutMsgQueue("nc", 10000);
        msg_queue_manager_->createOutMsgQueue("barrier", 10000);
        msg_queue_manager_->createOutMsgQueue("scds_pso", 10000);
        //construct app manager
        app_manager_ = Singleton<AppManager>::getSingleton(worker_num_);
        //construct timers
        publish_robot_base_timer_ = node_handle_.createTimer(ros::Duration(publish_robot_base_duration_), &RuntimeCore::publish_robot_base, this);
        publish_swarm_list_timer_ = node_handle_.createTimer(ros::Duration(publish_swarm_list_duration_), &RuntimeCore::publish_swarm_list, this);
        //barrier_timer_=node_handle_.createTimer(ros::Duration(1), &RuntimeCore::barrier_check, this);


/*
        //--------------------------
        //local inter-process communication
        //subscribe the pose/vel inform from physics-layer drivers
        //redirect the message /uav/${r_id}/position to /robot_base_driver (refer to local_manager.cpp)?
        sub_robot_base_local_=node_handle_.subscribe("/odom",1000,&RuntimeCore::subscribe_robot_base_local,this);
        pub_robot_base_local_=node_handle_.advertise<gsdf_msgs::Base>("/robot_base_physics_layer",1000);
        pub_robot_base_local_timer_=node_handle_.createTimer(ros::Duration(pub_robot_base_local_duration_), &RuntimeCore::publish_robot_base_local, this);

        //publish the neighbour inform list including the ids and their base
        //redirect the message /uav/${r_id}/neighbor to /robot_neighbour_info
        pub_neighbour_bases_local_=node_handle_.advertise<gsdf_msgs::NeighbourBases>("/robot_neighbour_bases",1000);
        //

        sub_swarm_heartbeat_local_=node_handle_.subscribe("/heartbeat_ground_station_string",1000,&RuntimeCore::subscribe_swarm_heartbeat_local,this);
        pub_swarm_heartbeat_local_=node_handle_.advertise<gsdf_msgs::HB_string>("/swarm_heartbeat_string",1000);
        //
        sub_new_rosbag_local_=node_handle_.subscribe("/new_rosbag",1000,&RuntimeCore::subscribe_new_rosbag,this);
        pub_new_rosbag_local_=node_handle_.advertise<std_msgs::Int32>("/new_rosbag_record",1000);

        //service to get the local ID
        service_get_robot_id_local_=node_handle_.advertiseService("/get_robot_id",&RuntimeCore::service_get_robot_id_local_cb,this);
        //timers  durations not set

        pub_swarm_heartbeat_local_timer_=node_handle_.createTimer(ros::Duration(pub_swarm_heartbeat_local_duration_), &RuntimeCore::publish_swarm_heartbeat_local, this);

        pub_neighbour_bases_local_timer_=node_handle_.createTimer(ros::Duration(pub_neighbour_bases_local_duration_), &RuntimeCore::publish_neighbour_bases_local, this);
        pub_new_rosbag_local_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_new_rosbag, this);


        //--------------------------
        sub_skv_swarm_path_local_=node_handle_.subscribe("/skv/path_ground_station",1000,&RuntimeCore::subscribe_skv_swarm_path_local,this);
        pub_skv_swarm_path_local_=node_handle_.advertise<gsdf_msgs::Path>("/station/skv/path_ground_station",1000);

        sub_skv_all_vels=node_handle_.subscribe("/skv/all_vels",1000,&RuntimeCore::subscribe_skv_all_vels,this);
        pub_skv_all_vels=node_handle_.advertise<formation_controller_msgs::TwistIdArray>("/station/skv/all_vels",1000);

        sub_skv_rgb=node_handle_.subscribe("/skv/detected/movobjects_rgb",1000,&RuntimeCore::subscribe_skv_rgb,this);
        pub_skv_rgb_=node_handle_.advertise<orient_softbus_msgs::TotalMovObject>("/uav/skv/detected/movobjects_rgb",1000);

        pub_skv_twist = node_handle_.advertise<geometry_msgs::Twist>("/velctrl/input",1000);

        sub_skv_getImage=node_handle_.subscribe("/skv/observer/getImages",1000,&RuntimeCore::subscribe_get_image,this);
        pub_skv_getImage_=node_handle_.advertise<orient_softbus_msgs::GetImages>("/station/skv/observer/getImages",1000);

        pub_skv_swarm_path_local_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_swarm_path_local, this);
        pub_skv_all_vels_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_all_vels, this);
        pub_skv_image_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_image, this);
        pub_skv_rgb_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_skv_rgb, this);
        pub_skv_getImage_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_get_image,this);


        /////added by Hao
        test_takeoff_pub_ = node_handle_.advertise<std_msgs::Empty>("/takeoff", 1);
        test_takeoff_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_take_off,this);
        test_takeoff_sub_ = node_handle_.subscribe("/test_takeoff",1000,&RuntimeCore::subscribe_test_take_off,this);

        test_landing_pub_ = node_handle_.advertise<std_msgs::Empty>("/land", 1);
        test_landing_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_landing,this);
        test_landing_sub_ = node_handle_.subscribe("/test_landing",1000,&RuntimeCore::subscribe_test_landing,this);

        test_cmd_vel_pub_ = node_handle_.advertise<geometry_msgs::Twist>("/velctrl/input", 1000);
        test_cmd_vel_pub_timer_=node_handle_.createTimer(ros::Duration(0.1), &RuntimeCore::publish_test_cmd_vel,this);
        test_cmd_vel_sub_ = node_handle_.subscribe("/fixedwing/cmd_vel",1000,&RuntimeCore::subscribe_test_cmd_vel,this);

        test_odom_pub_ = node_handle_.advertise<nav_msgs::Odometry>("/test/odom", 1000);
        test_odom_pub_timer_=node_handle_.createTimer(ros::Duration(0.2), &RuntimeCore::publish_test_odom,this);
        test_odom_sub_ = node_handle_.subscribe("/odom",1000,&RuntimeCore::subscribe_test_odom,this);
        /////
*/
        spin_thread_ = new boost::thread(&RuntimeCore::spin_msg_queue, this);
        std::cout<<"robot "<<rth_->getRobotID()<<" daemon node start."<<std::endl;
    }

    void RuntimeCore::shutdown()
    {
        spin_thread_->interrupt();
        spin_thread_->join();
        delete spin_thread_;

        app_manager_->stop();
        Singleton<AppManager>::deleteSingleton();
        app_manager_.reset();
        Singleton<CommInterface>::deleteSingleton();
        communicator_.reset();
        ci_loader_.unloadLibraryForClass(comm_type_);
        Singleton<PacketParser>::deleteSingleton();
        parser_.reset();
        Singleton<RuntimeHandle>::deleteSingleton();
        rth_.reset();
    }
};
