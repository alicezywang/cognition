/**
Software License Agreement (BSD)
\file      runtime_core.h
\authors Xuefeng Chang <changxuefengcn@163.com>
\copyright Copyright (c) 2016, the micROS Team, HPCL (National University of Defense Technology), All rights reserved.
Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of micROS Team, HPCL, nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef RUNTIME_CORE_H_
#define RUNTIME_CORE_H_

#include <iostream>
#include <ros/ros.h>
#include <map>
#include <boost/serialization/map.hpp>
#include <pluginlib/class_loader.h>

#include "micros_swarm/singleton.h"
#include "micros_swarm/message.h"
#include "micros_swarm/runtime_handle.h"
#include "micros_swarm/comm_interface.h"
#include "micros_swarm/packet_parser.h"
#include "micros_swarm/app_manager.h"
#include "micros_swarm/shared_kv.h"

#include "swarm_msgs/Base.h"
#include "swarm_msgs/NeighbourBases.h"
#include "swarm_msgs/GetID.h"
#include "swarm_msgs/PathPoint.h"
#include "swarm_msgs/Path.h"
#include "swarm_msgs/Heartbeat.h"
#include "swarm_msgs/RobotBase.h"
#include "swarm_msgs/CommPacket.h"
#include "swarm_msgs/SwarmList.h"
#include "swarm_msgs/NeighborList.h"
#include "swarm_msgs/KeyValue.h"
#include <std_msgs/Int32.h>
#include <nav_msgs/Odometry.h>
#include "tf/tf.h"
#include "formation_controller_msgs/TwistId.h"
#include "formation_controller_msgs/TwistIdArray.h"
#include "geometry_msgs/Twist.h"
#include "sensor_msgs/Image.h"
#include "orient_softbus_msgs/TotalMovObject.h"
#include "swarm_msgs/HB_string.h"
#include "orient_softbus_msgs/GetImages.h"

#include <std_msgs/Empty.h>

namespace micros_swarm{

    class RuntimeCore
    {
    public:
        ros::NodeHandle node_handle_;
        boost::shared_ptr<RuntimeHandle> rth_;
        boost::shared_ptr<CommInterface> communicator_;
        std::string comm_type_;
        pluginlib::ClassLoader<micros_swarm::CommInterface> ci_loader_;
        boost::shared_ptr<micros_swarm::PacketParser> parser_;
        boost::shared_ptr<AppManager> app_manager_;

        ros::Timer publish_robot_base_timer_;
        ros::Timer publish_swarm_list_timer_;
	 	ros::Timer publish_neighbour_list_timer_;
        ros::Timer barrier_timer_;
        ros::Timer spin_timer_;

        double publish_robot_base_duration_;
        double publish_swarm_list_duration_;
	 	double publish_neighbour_list_duration_;
	    double default_neighbor_distance_;
	    int total_robot_numbers_;
	    int robot_id_;

    	boost::thread* spin_thread_;

	//ros communication for local inter-process communication
	ros::Subscriber sub_robot_base_local_,sub_swarm_heartbeat_local_,
				sub_swarm_path_local_,sub_all_vels,sub_skv_robot_base_local_,sub_skv_swarm_path_local_,
				sub_skv_all_vels,sub_skv_image,sub_skv_rgb,sub_new_rosbag_local_,sub_skv_getImage,
				test_takeoff_sub_, test_landing_sub_, test_cmd_vel_sub_, test_odom_sub_;
	ros::Publisher pub_robot_base_local_,pub_neighbour_bases_local_,
		pub_swarm_heartbeat_local_, pub_swarm_path_local_,pub_all_vels,pub_twist,
		pub_skv_robot_base_local_,pub_skv_swarm_path_local_,pub_skv_all_vels,pub_skv_image_,
		pub_skv_rgb_,pub_skv_twist,pub_new_rosbag_local_,pub_skv_getImage_,
		test_takeoff_pub_, test_landing_pub_, test_cmd_vel_pub_, test_odom_pub_;
	ros::ServiceServer service_get_robot_id_local_;
	ros::Timer pub_robot_base_local_timer_, pub_swarm_heartbeat_local_timer_, 
		pub_swarm_path_local_timer_, pub_neighbour_bases_local_timer_,pub_all_vels_timer_,pub_skv_robot_base_local_timer_,
		pub_skv_swarm_heartbeat_local_timer_,pub_skv_swarm_path_local_timer_, pub_skv_all_vels_timer_,
		pub_skv_image_timer_,pub_skv_rgb_timer_,pub_new_rosbag_local_timer_,pub_skv_getImage_timer_,
		test_takeoff_pub_timer_, test_landing_pub_timer_, test_cmd_vel_pub_timer_, test_odom_pub_timer_;
	double pub_robot_base_local_duration_, pub_swarm_heartbeat_local_duration_, 
		pub_swarm_path_local_duration_, pub_neighbour_bases_local_duration_;

	//global inter-node
	ros::Timer pub_swarm_heartbeat_timer_, pub_swarm_path_timer_;
	double pub_robot_base_duration_, pub_swarm_heartbeat_duration_, 
		pub_swarm_path_duration_, pub_neighbour_bases_duration_;
	

	RuntimeCore();
	~RuntimeCore();

	void initialize();
	void setParameters();
	void spin_msg_queue();
	void publish_robot_base(const ros::TimerEvent&);
	void publish_swarm_list(const ros::TimerEvent&);
	void publish_neighbour_list(const ros::TimerEvent&);
	void barrier_check(const ros::TimerEvent&);

	//inter-processes

	bool service_get_robot_id_local_cb(swarm_msgs::GetID::Request&req,swarm_msgs::GetID::Response& res);
	void publish_neighbour_bases_local(const ros::TimerEvent&);

	void subscribe_robot_base_local(const nav_msgs::Odometry::ConstPtr & msg) ;
	void publish_robot_base_local(const ros::TimerEvent&);

	void subscribe_swarm_heartbeat_local(const swarm_msgs::HB_string::ConstPtr & msg);
	void publish_swarm_heartbeat_local(const ros::TimerEvent&) ;
	
	void subscribe_swarm_path_local(const swarm_msgs::Path::ConstPtr & msg) ;
	void publish_swarm_path_local(const ros::TimerEvent&);
    
    void subscribe_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg) ;
	void publish_all_vels(const ros::TimerEvent&);

	//void subscribe_skv_robot_base_local(const nav_msgs::Odometry::ConstPtr & msg);
	//void publish_skv_robot_base_local(const ros::TimerEvent&);

	void subscribe_skv_all_vels(const formation_controller_msgs::TwistIdArray::ConstPtr & msg);
	void publish_skv_all_vels(const ros::TimerEvent&);

	void subscribe_skv_swarm_path_local(const swarm_msgs::Path::ConstPtr & msg);
	void publish_skv_swarm_path_local(const ros::TimerEvent&);

	void subscribe_skv_image(const sensor_msgs::Image::ConstPtr & msg);
	void publish_skv_image(const ros::TimerEvent&);

	void subscribe_skv_rgb(const orient_softbus_msgs::TotalMovObject::ConstPtr & msg);
	void publish_skv_rgb(const ros::TimerEvent&);
    
    void subscribe_new_rosbag(const std_msgs::Int32::ConstPtr& msg);
    void publish_new_rosbag(const ros::TimerEvent&);

	 void subscribe_get_image(const orient_softbus_msgs::GetImages::ConstPtr & msg);
	void publish_get_image(const ros::TimerEvent&);

////added by Hao
void subscribe_test_take_off(const std_msgs::Empty::ConstPtr & msg);
void subscribe_test_landing(const std_msgs::Empty::ConstPtr & msg);
void subscribe_test_cmd_vel(const geometry_msgs::Twist::ConstPtr & msg); 
void subscribe_test_odom(const nav_msgs::Odometry::ConstPtr & msg);
void publish_test_take_off(const ros::TimerEvent&);
void publish_test_landing(const ros::TimerEvent&);
void publish_test_cmd_vel(const ros::TimerEvent&);
void publish_test_odom(const ros::TimerEvent&);
////



	};
}
#endif
