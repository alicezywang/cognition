/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai
 *********************************************************************/

#include "situation_distribution/situation_distribution.h"

// Register the application
PLUGINLIB_EXPORT_CLASS(situation_distribution::SituationDistribution, micros_swarm::Application)

namespace situation_distribution{

    SituationDistribution::SituationDistribution() {
        vs=micros_swarm::VirtualStigmergy(2);
    }
    
    SituationDistribution::~SituationDistribution() {}

    void SituationDistribution::init() {}

    void SituationDistribution::stop() {}
    
    void SituationDistribution::loop_gets(const ros::TimerEvent&)
    {
    	std::string robot_id_string = "robot_10";
        //std::string robot_id_string = "robot_" + boost::lexical_cast<std::string>(get_id());

        gsdf_msgs::Enemy enemy;
        if(!vs.get_new<gsdf_msgs::Enemy>(robot_id_string,enemy))
        	return;
        std::cout<< robot_id_string << ": " <<enemy.startx<<", "<<enemy.starty<<", ";
        std::cout<<enemy.endx<<", "<<enemy.endy<<", "<<enemy.enemy_number<< std::endl;

        //sensor_msgs::Image image;
        sensor_msgs::CompressedImage image;
        //image = deserialize_ros<sensor_msgs::Image>(enemy.image);
        image = deserialize_ros<sensor_msgs::CompressedImage>(enemy.image);
        std::cout << "length:::" << enemy.image.size() << std::endl;
        /*if(pub == NULL)
        {
            ros::NodeHandle nh;
            pub = nh.advertise<sensor_msgs::Image>("/ImagequeryResult",1000);
            //pub = nh.advertise<sensor_msgs::CompressedImage>("/ImagequeryResult",1000);
            std::cout << "test advertise" << std::endl;
        }
        // cv_bridge::CvImage(std_msgs::Header(), "bgr8", imgRes).toImageMsg();
        pub.publish(image);*/

    }
    
	//void SituationDistribution::pub_callback(const sensor_msgs::Image::ConstPtr& msg)
	void SituationDistribution::pub_callback(const sensor_msgs::CompressedImage::ConstPtr& msg)
	{
		//std::cout<<"success subscribing image_raw!!!!!"<<std::endl;
		static int count=0;

	    std::vector<uint8_t> vec_data;

	    //uint8_t temp1=1;
	    //vec_data.push_back(temp1);


	    vec_data = serialize_ros(*msg);

	    gsdf_msgs::Enemy temp;

	    temp.startx=1.0;
	    temp.starty=1.0;
	    temp.endx=5.0;
	    temp.endy=5.0;
	    temp.enemy_number=get_id();

	    temp.image=vec_data;
	    //std::cout<<"image size: "<<vec_data.size()<<std::endl;

	    //std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
	    std::string robot_id_string="robot_10";

	    //向vs插入一条数据（key,value）,事件触发
	    if(count==100)
	    {
	    	std::cout<<"\n\n\ninsert or update the value of key: "<<robot_id_string<<std::endl;
	    	vs.put<gsdf_msgs::Enemy>(robot_id_string, temp);
	    	count=0;
	    }

	    vec_data.clear();
	    count++;
	}


    void SituationDistribution::start()
    {
        ros::NodeHandle nh;

        micros_swarm::Base l(0, 0, 0, 0, 0, 0, 1);
        set_base(l);

        //sub = nh.subscribe("/usb_cam/image_raw", 1, &SituationDistribution::pub_callback, this, ros::TransportHints().udp());

        //sub = nh.subscribe("/usb_cam/image_raw/compressed", 1, &SituationDistribution::pub_callback, this, ros::TransportHints().udp());
        //sub = nh.subscribe("/camera/rgb/image_raw/compressed", 1, &SituationDistribution::pub_callback, this, ros::TransportHints().udp());
        sub = nh.subscribe("/ImagequeryResult", 1, &SituationDistribution::pub_callback, this, ros::TransportHints().udp());
        timer = nh.createTimer(ros::Duration(2), &SituationDistribution::loop_gets, this);

    }
};

