#include <iostream>
#include <ros/ros.h>


#include "fastrtps_broker/Fastrtps_Packet.h"

#include <fastrtps/Domain.h>
#include <fastrtps/utils/eClock.h>
#include <fastrtps/log/Log.h>

#include <sensor_msgs/Image.h>
#include <sensor_msgs/CompressedImage.h>

#include "fastrtps_broker/Fastrtps_PacketSubscriber.h"

using namespace eprosima;
using namespace eprosima::fastrtps;

ros::Publisher pub;
//sensor_msgs::Image image;
sensor_msgs::CompressedImage image;

// deserializer using ROS.
template<class T>
T deserialize_ros(const std::vector<uint8_t>& vec)
{
    T t;
    uint32_t serial_size = vec.size();
    std::vector<uint8_t> buffer(serial_size);
    std::copy(vec.begin(), vec.begin() + serial_size, buffer.begin());
    ros::serialization::IStream istream(buffer.data(), serial_size);
    ros::serialization::Serializer<T>::read(istream, t);
    return t;
}
/*void RTPS_callback(std::vector<char> msg)
{
    std::string str_temp;
    str_temp = std::string(reinterpret_cast<char*>(&msg[0]),msg.size());
    image = deserialize_ros<sensor_msgs::Image>(str_temp);
    //image = deserialize_ros<sensor_msgs::CompressedImage>(str_temp);
    std::cout << "length:::" << str_temp.size() << std::endl;
    if(pub == NULL)
    {
        ros::NodeHandle nh;
        pub = nh.advertise<sensor_msgs::Image>("/ImagequeryResult",1000);
        //pub = nh.advertise<sensor_msgs::CompressedImage>("/ImagequeryResult",1000);
        std::cout << "test advertise" << std::endl;
    }
    // cv_bridge::CvImage(std_msgs::Header(), "bgr8", imgRes).toImageMsg();
    pub.publish(image);
}*/

void RTPS_callback(std::vector<uint8_t> msg)
{
    //std::string str_temp;
    //str_temp = std::string(reinterpret_cast<char*>(&msg[0]),msg.size());
    //image = deserialize_ros<sensor_msgs::Image>(msg);
    image = deserialize_ros<sensor_msgs::CompressedImage>(msg);
    std::cout << "length:::" << msg.size() << std::endl;
    if(pub == NULL)
    {
        ros::NodeHandle nh;
        //pub = nh.advertise<sensor_msgs::Image>("/ImagequeryResult",1000);
        pub = nh.advertise<sensor_msgs::CompressedImage>("/ImagequeryResult",1000);
        std::cout << "test advertise" << std::endl;
    }
    // cv_bridge::CvImage(std_msgs::Header(), "bgr8", imgRes).toImageMsg();
    pub.publish(image);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Receiver");
    std::cout << "sub started" <<std::endl;

    Fastrtps_PacketSubscriber RTPS_Subscriber;
    //if(RTPS_Subscriber.init())
    if(RTPS_Subscriber.init("fastrtps_image_topic"))
    {
    	RTPS_Subscriber.receive(&RTPS_callback);//回调函数
    	/*while(ros::ok())
        {
    		RTPS_Subscriber.receive(&RTPS_callback);//回调函数
        }*/
    }
    ros::spin();
    Domain::stopAll();
    Log::Reset();
    return 0;
}
