#include <iostream>
#include <ros/ros.h>

#include "fastrtps_broker/Fastrtps_PacketPublisher.h"
#include "fastrtps_broker/Fastrtps_Packet.h"

#include <fastrtps/Domain.h>
#include <fastrtps/utils/eClock.h>
#include <fastrtps/log/Log.h>

#include <sensor_msgs/Image.h>
#include <sensor_msgs/CompressedImage.h>

using namespace eprosima;
using namespace eprosima::fastrtps;


Fastrtps_PacketPublisher RTPS_Publisher;

template<class T>
std::vector<uint8_t> serialize_ros(T t)
{
    std::vector<uint8_t> vec;
    uint32_t serial_size = ros::serialization::serializationLength(t);
    boost::shared_array<uint8_t> buffer(new uint8_t[serial_size]);
    ros::serialization::OStream ostream(buffer.get(), serial_size);
    ros::serialization::serialize(ostream, t);
    vec.resize(serial_size);
    std::copy(buffer.get(), buffer.get() + serial_size, vec.begin());
    return vec;
}
/*void pub_callback(const sensor_msgs::Image::ConstPtr& msg)
{
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
        cv_ptr = cv_bridge::toCvCopy(msg,sensor_msgs::image_encodings::RGB8);
    }   
    catch (cv_bridge::Exception& e)
    {
        ROS_ERROR("cv_bridge exception: %s", e.what());
        return;
    }
    std::string encoding;
    encoding = "jpg";
    cv::imencode("."+encoding,cv_ptr->image,RTPS_Publisher.buf);
    std::cout << "length:::" << RTPS_Publisher.buf.size() << std::endl;
    if(!RTPS_Publisher.RTPS_send())
    eClock::my_sleep(25);
}
*/

/*void pub_callback(const sensor_msgs::Image::ConstPtr& msg)
{
	std::cout<<"success subscribing image_raw!!!!!"<<std::endl;
    sensor_msgs::Image image;
    image.header = msg->header;
    image.height = msg->height;
    image.width =  msg->width;
    image.encoding = msg->encoding;
    image.is_bigendian = msg->is_bigendian;
    image.step = msg->step;
    image.data = msg->data;
    std::string str1;
    str1 = serialize_ros(image);//ros序列化
    std::cout << str1.size() << std::endl;
    std::vector<char> vec_data(str1.c_str(), str1.c_str()+str1.size());
    //将通过ros订阅的消息类型转换成Fast-RTPS所能发送的vector<uchar>
    //for(auto e : vec_data)
    //{
    //    RTPS_Publisher.buf.push_back(static_cast<uchar>(e));
    //}
    //std::cout << "length:::" << RTPS_Publisher.buf.size() << std::endl;
    if(!RTPS_Publisher.DDS_pub(vec_data))//发送消息
    eClock::my_sleep(25);
    vec_data.clear();
    str1.clear();
}*/

//void pub_callback(const sensor_msgs::Image::ConstPtr& msg)
void pub_callback(const sensor_msgs::CompressedImage::ConstPtr& msg)
{
	static int count=0;
	if(count==400)
	{
		std::cout<<"success subscribing image_raw!!!!!"<<std::endl;

		std::vector<uint8_t> vec_data;

		vec_data = serialize_ros(*msg);

		if(!RTPS_Publisher.DDS_pub(vec_data))//发送消息
			eClock::my_sleep(25);
		vec_data.clear();
		count=0;
	}
    count++;
    //str1.clear();
}

int main(int argc, char **argv)
{
    std::cout << "pub started" << std::endl;
    ros::init(argc,argv,"sub_pub_camera_img_new");
    //RTPS_Publisher.init();
    RTPS_Publisher.init("fastrtps_image_topic");
    ros::NodeHandle nh;

    //ros::Subscriber sub = nh.subscribe("/uav0/image_raw",1,pub_callback);
    //ros::Subscriber sub = nh.subscribe("/mytopic",1,pub_callback);
    //ros::Subscriber sub = nh.subscribe("/usb_cam/image_raw",1,pub_callback);
    ros::Subscriber sub = nh.subscribe("/usb_cam/image_raw/compressed",1,pub_callback);
    //ros::Subscriber sub = nh.subscribe("/camera/rgb/image_raw/compressed",1,pub_callback);
    //ros::Subscriber sub = nh.subscribe("/camera/rgb/image_raw",1,pub_callback);
    ros::spin();
    Domain::stopAll();
    Log::Reset();
    return 0;
}

