
/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai
 *********************************************************************/

#include "rtidds_broker/RTIDDS_PacketPublisher.h"

/* Delete all entities */
int RTIDDS_PacketPublisher::publisher_shutdown(
    DDSDomainParticipant *participant)
{
    DDS_ReturnCode_t retcode;
    int status = 0;

    if (participant != NULL) {
        retcode = participant->delete_contained_entities();
        if (retcode != DDS_RETCODE_OK) {
            printf("delete_contained_entities error %d\n", retcode);
            status = -1;
        }

        retcode = DDSTheParticipantFactory->delete_participant(participant);
        if (retcode != DDS_RETCODE_OK) {
            printf("delete_participant error %d\n", retcode);
            status = -1;
        }
    }

    /* RTI Connext provides finalize_instance() method on
           domain participant factory for people who want to release memory used
           by the participant factory. Uncomment the following block of code for
           clean destruction of the singleton. */
    /*

        retcode = DDSDomainParticipantFactory::finalize_instance();
    if (retcode != DDS_RETCODE_OK) {
        printf("finalize_instance error %d\n", retcode);
        status = -1;
    }
    */

    return status;
}

RTIDDS_PacketPublisher::RTIDDS_PacketPublisher() :
	participant(NULL),
	publisher(NULL),
	topic(NULL),
	writer(NULL),
	RTIDDS_Packet_writer(NULL),
	instance(NULL),
	instance_handle(DDS_HANDLE_NIL)
{}

RTIDDS_PacketPublisher::~RTIDDS_PacketPublisher() {

	publisher_shutdown(participant);
}


bool RTIDDS_PacketPublisher::init()
{
	domainId=0;
    const char *type_name = NULL;
    //int count = 0;
    //DDS_Duration_t send_period = {4,0};

    /* To customize participant QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    participant = DDSTheParticipantFactory->create_participant(
            domainId, DDS_PARTICIPANT_QOS_DEFAULT,
            NULL /* listener */, DDS_STATUS_MASK_NONE);
    if (participant == NULL) {
        printf("create_participant error\n");
        publisher_shutdown(participant);
        return false;
    }

    /* To customize publisher QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    publisher = participant->create_publisher(
            DDS_PUBLISHER_QOS_DEFAULT, NULL /* listener */, DDS_STATUS_MASK_NONE);
    if (publisher == NULL) {
        printf("create_publisher error\n");
        publisher_shutdown(participant);
        return false;
    }

    /* Register type before creating topic */
    type_name = RTIDDS_PacketTypeSupport::get_type_name();
    retcode = RTIDDS_PacketTypeSupport::register_type(
            participant, type_name);
    if (retcode != DDS_RETCODE_OK) {
        printf("register_type error %d\n", retcode);
        publisher_shutdown(participant);
        return false;
    }

    /* To customize topic QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    topic = participant->create_topic(
            "Example RTIDDS_Packet",
            type_name, DDS_TOPIC_QOS_DEFAULT, NULL /* listener */,
            DDS_STATUS_MASK_NONE);
    if (topic == NULL) {
        printf("create_topic error\n");
        publisher_shutdown(participant);
        return false;
    }

    /* To customize data writer QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    writer = publisher->create_datawriter(
            topic, DDS_DATAWRITER_QOS_DEFAULT, NULL /* listener */,
            DDS_STATUS_MASK_NONE);
    if (writer == NULL) {
        printf("create_datawriter error\n");
        publisher_shutdown(participant);
        return false;
    }
    RTIDDS_Packet_writer = RTIDDS_PacketDataWriter::narrow(writer);
    if (RTIDDS_Packet_writer == NULL) {
        printf("DataWriter narrow error\n");
        publisher_shutdown(participant);
        return false;
    }

    /* Create data sample for writing */
    instance = RTIDDS_PacketTypeSupport::create_data();
    if (instance == NULL) {
        printf("RTIDDS_PacketTypeSupport::create_data error\n");
        publisher_shutdown(participant);
        return false;
    }

    return true;

}

bool RTIDDS_PacketPublisher::DDS_pub(const std::vector<uint8_t>& msg_data)
{

	//instance->data=&msg_data;
	//DDS_Octet * payload_buffer           = NULL;
	DDS_Octet * data_buffer           = NULL;
	data_buffer = DDS_OctetSeq_get_contiguous_buffer(&instance->data);

    /* Fill up the buffer with some valid data:
     * The content of the payload buffer is a progressive series of incremental
     * numbers, starting from 0.
     */

	//printf("cj: pub a packet, length: %d.\n",msg_data.size());

    for (int i = 0; i < msg_data.size(); ++i) {
        data_buffer[i] = msg_data[i];
    }

    //very important
    instance->data._length=msg_data.size();

    retcode = RTIDDS_Packet_writer->write(*instance, instance_handle);

    //printf("cj: pub a packet.\n");

    if (retcode != DDS_RETCODE_OK) {
        printf("write error %d\n", retcode);
        return false;
    }

    /* Delete data sample */
    /*retcode = RTIDDS_PacketTypeSupport::delete_data(instance);
    if (retcode != DDS_RETCODE_OK) {
        printf("RTIDDS_PacketTypeSupport::delete_data error %d\n", retcode);
        return false;
    }*/

    return true;
}

void RTIDDS_PacketPublisher::run()
{

    int count = 0;
    int sample_count=0;
    DDS_Duration_t send_period = {4,0};

	/* Initialize your structure here */

	for (count=0; (sample_count == 0) || (count < sample_count); ++count) {

	        printf("Writing RTIDDS_Packet, count %d\n", count);

	        /* Modify the data to be sent here */
	        DDS_Octet * data_buffer           = NULL;
	        data_buffer = DDS_OctetSeq_get_contiguous_buffer(&instance->data);

	        for (int i = 0; i < 6; ++i) {
	        	data_buffer[i] = (i & 0xff);
	        }

	        //instance->data._contiguous_buffer="123456";
	        instance->data._length=6;

	        retcode = RTIDDS_Packet_writer->write(*instance, instance_handle);
	        if (retcode != DDS_RETCODE_OK) {
	            printf("write error %d\n", retcode);
	        }

	        NDDSUtility::sleep(send_period);
	    }

}

