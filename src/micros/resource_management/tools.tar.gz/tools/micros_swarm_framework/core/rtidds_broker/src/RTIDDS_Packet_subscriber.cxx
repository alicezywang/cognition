/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai
 *********************************************************************/

#include "rtidds_broker/RTIDDS_PacketSubscriber.h"

boost::function<void(const std::vector<uint8_t>&)> RTIDDS_PacketSubscriber::callback_;

RTIDDS_PacketSubscriber::RTIDDS_PacketSubscriber() :
	participant(NULL),
	subscriber(NULL),
	topic(NULL),
	reader_listener(NULL),
	reader(NULL)
{}

RTIDDS_PacketSubscriber::~RTIDDS_PacketSubscriber() {

	subscriber_shutdown(participant);
	delete reader_listener;
}

/*void process_data(const RTIDDS_Packet * const instance) {

	DDS_Octet * data_buffer           = NULL;
	std::vector<uint8_t> msg_data;
    data_buffer = DDS_OctetSeq_get_contiguous_buffer(&instance->data);
    for (int j = 0; j <DDS_OctetSeq_get_length(&instance->data) ; ++j) {
    	data_buffer[j] = msg_data[j];
    }
    printf("cj: add callback here!!\n");
    callback_(msg_data);
}*/


void RTIDDS_PacketSubscriber::RTIDDS_PacketListener::on_data_available(DDSDataReader* reader)
{
	//printf("cj: receive a packet!\n");
    RTIDDS_PacketDataReader *RTIDDS_Packet_reader = NULL;
    RTIDDS_PacketSeq data_seq;
    DDS_SampleInfoSeq info_seq;
    DDS_ReturnCode_t retcode;
    int i;

    RTIDDS_Packet_reader = RTIDDS_PacketDataReader::narrow(reader);

    if (RTIDDS_Packet_reader == NULL) {
        printf("DataReader narrow error\n");
        return;
    }

    retcode = RTIDDS_Packet_reader->take(
            data_seq,
			info_seq,
			DDS_LENGTH_UNLIMITED,
            DDS_ANY_SAMPLE_STATE,
			DDS_ANY_VIEW_STATE,
			DDS_ANY_INSTANCE_STATE);

    if (retcode == DDS_RETCODE_NO_DATA) {
        return;
    } else if (retcode != DDS_RETCODE_OK) {
        printf("take error %d\n", retcode);
        return;
    }

    //printf("cj: receive a packet!\n");
    //printf("cj: receive a packet seq, length: %d.\n",data_seq.length());

    /*for (i = 0; i < data_seq.length(); ++i) {
        if (info_seq[i].valid_data) {
            //RTIDDS_PacketTypeSupport::print_data(&data_seq[i]);
            RTIDDS_PacketTypeSupport::print_data(RTIDDS_PacketSeq_get_reference(&data_seq, i));
        }
    }*/


    for (i = 0; i < RTIDDS_PacketSeq_get_length(&data_seq); ++i) {
    	//printf("cj: receive a packet seq, length: %d.\n",RTIDDS_PacketSeq_get_length(&data_seq));
    	if (DDS_SampleInfoSeq_get_reference(&info_seq, i)->valid_data) {
    		////Process the data
    	    std::vector<uint8_t> msg_data;
    		DDS_Octet * data_buffer           = NULL;
    		RTIDDS_Packet *instance           = NULL;
    		instance=RTIDDS_PacketSeq_get_reference(&data_seq, i);

    		//instance=RTIDDS_PacketSeq_get_reference(&data_seq, 0);

    		if(instance==NULL)
    		{
    			printf("instance is null.");
    		}

            data_buffer = DDS_OctetSeq_get_contiguous_buffer(&instance->data);

            //printf("cj: receive a packet, length: %d.\n",DDS_OctetSeq_get_length(&instance->data));
            for (int j = 0; j <DDS_OctetSeq_get_length(&instance->data) ; ++j) {
            	//data_buffer[j] = msg_data[j];
            	msg_data.push_back(data_buffer[j]);
            }
            //printf("cj: add callback here!!\n");
            //printf("cj: receive a packet, length: %d.\n",msg_data.size());
            RTIDDS_PacketSubscriber::callback_(msg_data);
    	}
    }

    retcode = RTIDDS_Packet_reader->return_loan(data_seq, info_seq);
    if (retcode != DDS_RETCODE_OK) {
        printf("return loan error %d\n", retcode);
    }
}

void RTIDDS_PacketSubscriber::RTIDDS_PacketListener::on_subscription_matched(
        DDSDataReader* /*reader*/,
        const DDS_SubscriptionMatchedStatus& /*status*/) {

	printf("subscription matched.\n");
}

/* Delete all entities */
int RTIDDS_PacketSubscriber::subscriber_shutdown(DDSDomainParticipant *participant)
{
    DDS_ReturnCode_t retcode;
    int status = 0;

    if (participant != NULL) {
        retcode = participant->delete_contained_entities();
        if (retcode != DDS_RETCODE_OK) {
            printf("delete_contained_entities error %d\n", retcode);
            status = -1;
        }

        retcode = DDSTheParticipantFactory->delete_participant(participant);
        if (retcode != DDS_RETCODE_OK) {
            printf("delete_participant error %d\n", retcode);
            status = -1;
        }
    }

    /* RTI Connext provides the finalize_instance() method on
           domain participant factory for people who want to release memory used
           by the participant factory. Uncomment the following block of code for
           clean destruction of the singleton. */
    /*
       
        retcode = DDSDomainParticipantFactory::finalize_instance();
    if (retcode != DDS_RETCODE_OK) {
        printf("finalize_instance error %d\n", retcode);
        status = -1;
    }
    */
    return status;
}

bool RTIDDS_PacketSubscriber::init()
{
	domainId=0;
    const char *type_name = NULL;
    //int count = 0;
    //DDS_Duration_t receive_period = {4,0};
    //int status = 0;

    /* To customize the participant QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    participant = DDSTheParticipantFactory->create_participant(
            domainId, DDS_PARTICIPANT_QOS_DEFAULT,
            NULL /* listener */, DDS_STATUS_MASK_NONE);
    if (participant == NULL) {
        printf("create_participant error\n");
        subscriber_shutdown(participant);
        return false;
    }

    /* To customize the subscriber QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    subscriber = participant->create_subscriber(
            DDS_SUBSCRIBER_QOS_DEFAULT, NULL /* listener */, DDS_STATUS_MASK_NONE);
    if (subscriber == NULL) {
        printf("create_subscriber error\n");
        subscriber_shutdown(participant);
        return false;
    }

    /* Register the type before creating the topic */
    type_name = RTIDDS_PacketTypeSupport::get_type_name();
    retcode = RTIDDS_PacketTypeSupport::register_type(
            participant, type_name);
    if (retcode != DDS_RETCODE_OK) {
        printf("register_type error %d\n", retcode);
        subscriber_shutdown(participant);
        return false;
    }

    /* To customize the topic QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    topic = participant->create_topic(
            "Example RTIDDS_Packet",
            type_name, DDS_TOPIC_QOS_DEFAULT, NULL /* listener */,
            DDS_STATUS_MASK_NONE);
    if (topic == NULL) {
        printf("create_topic error\n");
        subscriber_shutdown(participant);
        return false;
    }

    /* Create a data reader listener */
    reader_listener = new RTIDDS_PacketListener();

    /* To customize the data reader QoS, use
           the configuration file USER_QOS_PROFILES.xml */
    reader = subscriber->create_datareader(
            topic, DDS_DATAREADER_QOS_DEFAULT, reader_listener,
            DDS_STATUS_MASK_ALL);
    if (reader == NULL) {
        printf("create_datareader error\n");
        subscriber_shutdown(participant);
        delete reader_listener;
        return false;
    }

    return true;
}

void RTIDDS_PacketSubscriber::receive(boost::function<void(const std::vector<uint8_t>&)> callBack)
{
	//m_listener.callback_ = callBack;
	callback_ = callBack;
}

void RTIDDS_PacketSubscriber::run()
{
    int count = 0;
    DDS_Duration_t receive_period = {4,0};
    int sample_count = 0;
    for (count=0; (sample_count == 0) || (count < sample_count); ++count) {

        printf("RTIDDS_Packet subscriber sleeping for %d sec...\n",
                       receive_period.sec);

        NDDSUtility::sleep(receive_period);
    }
}
