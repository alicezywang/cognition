

/*
  WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

  This file was generated from RTIDDS_Packet.idl using "rtiddsgen".
  The rtiddsgen tool is part of the RTI Connext distribution.
  For more information, type 'rtiddsgen -help' at a command shell
  or consult the RTI Connext manual.
*/

#ifndef RTIDDS_Packet_319329935_h
#define RTIDDS_Packet_319329935_h

#ifndef NDDS_STANDALONE_TYPE
    #ifdef __cplusplus
        #ifndef ndds_cpp_h
            #include "ndds/ndds_cpp.h"
        #endif
    #else
        #ifndef ndds_c_h
            #include "ndds/ndds_c.h"
        #endif
    #endif
#else
    #include "ndds_standalone_type.h"
#endif

#ifdef __cplusplus
extern "C" {
    #endif
            
    extern const char *RTIDDS_PacketTYPENAME;

    #ifdef __cplusplus
}
#endif

#ifdef __cplusplus
struct RTIDDS_PacketSeq;
#ifndef NDDS_STANDALONE_TYPE
    class RTIDDS_PacketTypeSupport;
class RTIDDS_PacketDataWriter;
class RTIDDS_PacketDataReader;
#endif
#endif

class RTIDDS_Packet 
{
    public:
    #ifdef __cplusplus
        typedef struct RTIDDS_PacketSeq Seq;
    #ifndef NDDS_STANDALONE_TYPE
        typedef RTIDDS_PacketTypeSupport TypeSupport;
    typedef RTIDDS_PacketDataWriter DataWriter;
    typedef RTIDDS_PacketDataReader DataReader;
    #endif
        
    #endif

           DDS_OctetSeq  data ;
};
#if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
  /* If the code is building on Windows, start exporting symbols.
   */
#undef NDDSUSERDllExport
  #define NDDSUSERDllExport __declspec(dllexport)
#endif

NDDSUSERDllExport DDS_TypeCode* RTIDDS_Packet_get_typecode(void); /* Type code */

DDS_SEQUENCE(RTIDDS_PacketSeq, RTIDDS_Packet);                                        

NDDSUSERDllExport
RTIBool RTIDDS_Packet_initialize(
        RTIDDS_Packet* self);

NDDSUSERDllExport
RTIBool RTIDDS_Packet_initialize_ex(
        RTIDDS_Packet* self,RTIBool allocatePointers,RTIBool allocateMemory);

NDDSUSERDllExport
RTIBool RTIDDS_Packet_initialize_w_params(
        RTIDDS_Packet* self,
        const struct DDS_TypeAllocationParams_t * allocParams);        

NDDSUSERDllExport
void RTIDDS_Packet_finalize(
        RTIDDS_Packet* self);

NDDSUSERDllExport
void RTIDDS_Packet_finalize_ex(
        RTIDDS_Packet* self,RTIBool deletePointers);

NDDSUSERDllExport
void RTIDDS_Packet_finalize_w_params(
        RTIDDS_Packet* self,
        const struct DDS_TypeDeallocationParams_t * deallocParams);

NDDSUSERDllExport
void RTIDDS_Packet_finalize_optional_members(
        RTIDDS_Packet* self, RTIBool deletePointers);  

NDDSUSERDllExport
RTIBool RTIDDS_Packet_copy(
        RTIDDS_Packet* dst,
        const RTIDDS_Packet* src);

#if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
  /* If the code is building on Windows, stop exporting symbols.
   */
#undef NDDSUSERDllExport
  #define NDDSUSERDllExport
  #endif

#endif /* RTIDDS_Packet */

