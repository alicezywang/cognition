

/*
  WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

  This file was generated from RTIDDS_Packet.idl using "rtiddsgen".
  The rtiddsgen tool is part of the RTI Connext distribution.
  For more information, type 'rtiddsgen -help' at a command shell
  or consult the RTI Connext manual.
*/

#ifndef RTIDDS_PacketPlugin_319329935_h
#define RTIDDS_PacketPlugin_319329935_h

#include "RTIDDS_Packet.h"

struct RTICdrStream;

#ifndef pres_typePlugin_h
#include "pres/pres_typePlugin.h"
#endif

#if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
/* If the code is building on Windows, start exporting symbols.
*/
#undef NDDSUSERDllExport
#define NDDSUSERDllExport __declspec(dllexport)
#endif

#ifdef __cplusplus
extern "C" {
    #endif

     
    #define RTIDDS_PacketPlugin_get_sample PRESTypePluginDefaultEndpointData_getSample 
    #define RTIDDS_PacketPlugin_get_buffer PRESTypePluginDefaultEndpointData_getBuffer 
    #define RTIDDS_PacketPlugin_return_buffer PRESTypePluginDefaultEndpointData_returnBuffer 

     
     
    #define RTIDDS_PacketPlugin_create_sample PRESTypePluginDefaultEndpointData_createSample 
    #define RTIDDS_PacketPlugin_destroy_sample PRESTypePluginDefaultEndpointData_deleteSample 

    /* --------------------------------------------------------------------------------------
        Support functions:
    * -------------------------------------------------------------------------------------- */

    NDDSUSERDllExport extern RTIDDS_Packet*
    RTIDDS_PacketPluginSupport_create_data_w_params(
        const struct DDS_TypeAllocationParams_t * alloc_params);

    NDDSUSERDllExport extern RTIDDS_Packet*
    RTIDDS_PacketPluginSupport_create_data_ex(RTIBool allocate_pointers);

    NDDSUSERDllExport extern RTIDDS_Packet*
    RTIDDS_PacketPluginSupport_create_data(void);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPluginSupport_copy_data(
        RTIDDS_Packet *out,
        const RTIDDS_Packet *in);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPluginSupport_destroy_data_w_params(
        RTIDDS_Packet *sample,
        const struct DDS_TypeDeallocationParams_t * dealloc_params);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPluginSupport_destroy_data_ex(
        RTIDDS_Packet *sample,RTIBool deallocate_pointers);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPluginSupport_destroy_data(
        RTIDDS_Packet *sample);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPluginSupport_print_data(
        const RTIDDS_Packet *sample,
        const char *desc,
        unsigned int indent);

    /* ----------------------------------------------------------------------------
        Callback functions:
    * ---------------------------------------------------------------------------- */

    NDDSUSERDllExport extern PRESTypePluginParticipantData 
    RTIDDS_PacketPlugin_on_participant_attached(
        void *registration_data, 
        const struct PRESTypePluginParticipantInfo *participant_info,
        RTIBool top_level_registration, 
        void *container_plugin_context,
        RTICdrTypeCode *typeCode);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPlugin_on_participant_detached(
        PRESTypePluginParticipantData participant_data);

    NDDSUSERDllExport extern PRESTypePluginEndpointData 
    RTIDDS_PacketPlugin_on_endpoint_attached(
        PRESTypePluginParticipantData participant_data,
        const struct PRESTypePluginEndpointInfo *endpoint_info,
        RTIBool top_level_registration, 
        void *container_plugin_context);

    NDDSUSERDllExport extern void 
    RTIDDS_PacketPlugin_on_endpoint_detached(
        PRESTypePluginEndpointData endpoint_data);

    NDDSUSERDllExport extern void    
    RTIDDS_PacketPlugin_return_sample(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet *sample,
        void *handle);    

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_copy_sample(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet *out,
        const RTIDDS_Packet *in);

    /* ----------------------------------------------------------------------------
        (De)Serialize functions:
    * ------------------------------------------------------------------------- */

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_serialize(
        PRESTypePluginEndpointData endpoint_data,
        const RTIDDS_Packet *sample,
        struct RTICdrStream *stream, 
        RTIBool serialize_encapsulation,
        RTIEncapsulationId encapsulation_id,
        RTIBool serialize_sample, 
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_deserialize_sample(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet *sample, 
        struct RTICdrStream *stream,
        RTIBool deserialize_encapsulation,
        RTIBool deserialize_sample, 
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_deserialize(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet **sample, 
        RTIBool * drop_sample,
        struct RTICdrStream *stream,
        RTIBool deserialize_encapsulation,
        RTIBool deserialize_sample, 
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool
    RTIDDS_PacketPlugin_skip(
        PRESTypePluginEndpointData endpoint_data,
        struct RTICdrStream *stream, 
        RTIBool skip_encapsulation,  
        RTIBool skip_sample, 
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern unsigned int 
    RTIDDS_PacketPlugin_get_serialized_sample_max_size(
        PRESTypePluginEndpointData endpoint_data,
        RTIBool include_encapsulation,
        RTIEncapsulationId encapsulation_id,
        unsigned int current_alignment);

    NDDSUSERDllExport extern unsigned int 
    RTIDDS_PacketPlugin_get_serialized_sample_min_size(
        PRESTypePluginEndpointData endpoint_data,
        RTIBool include_encapsulation,
        RTIEncapsulationId encapsulation_id,
        unsigned int current_alignment);

    NDDSUSERDllExport extern unsigned int
    RTIDDS_PacketPlugin_get_serialized_sample_size(
        PRESTypePluginEndpointData endpoint_data,
        RTIBool include_encapsulation,
        RTIEncapsulationId encapsulation_id,
        unsigned int current_alignment,
        const RTIDDS_Packet * sample);

    /* --------------------------------------------------------------------------------------
        Key Management functions:
    * -------------------------------------------------------------------------------------- */
    NDDSUSERDllExport extern PRESTypePluginKeyKind 
    RTIDDS_PacketPlugin_get_key_kind(void);

    NDDSUSERDllExport extern unsigned int 
    RTIDDS_PacketPlugin_get_serialized_key_max_size(
        PRESTypePluginEndpointData endpoint_data,
        RTIBool include_encapsulation,
        RTIEncapsulationId encapsulation_id,
        unsigned int current_alignment);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_serialize_key(
        PRESTypePluginEndpointData endpoint_data,
        const RTIDDS_Packet *sample,
        struct RTICdrStream *stream,
        RTIBool serialize_encapsulation,
        RTIEncapsulationId encapsulation_id,
        RTIBool serialize_key,
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_deserialize_key_sample(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet * sample,
        struct RTICdrStream *stream,
        RTIBool deserialize_encapsulation,
        RTIBool deserialize_key,
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool 
    RTIDDS_PacketPlugin_deserialize_key(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet ** sample,
        RTIBool * drop_sample,
        struct RTICdrStream *stream,
        RTIBool deserialize_encapsulation,
        RTIBool deserialize_key,
        void *endpoint_plugin_qos);

    NDDSUSERDllExport extern RTIBool
    RTIDDS_PacketPlugin_serialized_sample_to_key(
        PRESTypePluginEndpointData endpoint_data,
        RTIDDS_Packet *sample,
        struct RTICdrStream *stream, 
        RTIBool deserialize_encapsulation,  
        RTIBool deserialize_key, 
        void *endpoint_plugin_qos);

    /* Plugin Functions */
    NDDSUSERDllExport extern struct PRESTypePlugin*
    RTIDDS_PacketPlugin_new(void);

    NDDSUSERDllExport extern void
    RTIDDS_PacketPlugin_delete(struct PRESTypePlugin *);

    #ifdef __cplusplus
}
#endif

#if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
/* If the code is building on Windows, stop exporting symbols.
*/
#undef NDDSUSERDllExport
#define NDDSUSERDllExport
#endif

#endif /* RTIDDS_PacketPlugin_319329935_h */

