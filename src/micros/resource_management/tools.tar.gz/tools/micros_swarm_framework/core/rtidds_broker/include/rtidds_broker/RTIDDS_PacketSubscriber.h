/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai
 *********************************************************************/

//#include <stdio.h>
//#include <stdlib.h>
#ifdef RTI_VX653
#include <vThreadsData.h>
#endif
#include "RTIDDS_Packet.h"
#include "RTIDDS_PacketSupport.h"
#include "ndds/ndds_cpp.h"

#include <stdint.h>
#include <vector>

#include <boost/function.hpp>
#include <boost/bind.hpp>

class RTIDDS_PacketSubscriber
{
public:
	RTIDDS_PacketSubscriber();
	virtual ~RTIDDS_PacketSubscriber();
	bool init();
	void run();
	void receive(boost::function<void(const std::vector<uint8_t>&)> callBack);
	static int subscriber_shutdown(DDSDomainParticipant *participant);

private:

	class RTIDDS_PacketListener : public DDSDataReaderListener {
	    public:
	    virtual void on_requested_deadline_missed(
	            DDSDataReader* /*reader*/,
	            const DDS_RequestedDeadlineMissedStatus& /*status*/) {}

	    virtual void on_requested_incompatible_qos(
	            DDSDataReader* /*reader*/,
	            const DDS_RequestedIncompatibleQosStatus& /*status*/) {}

	    virtual void on_sample_rejected(
	            DDSDataReader* /*reader*/,
	            const DDS_SampleRejectedStatus& /*status*/) {}

	    virtual void on_liveliness_changed(
	            DDSDataReader* /*reader*/,
	            const DDS_LivelinessChangedStatus& /*status*/) {}

	    virtual void on_sample_lost(
	            DDSDataReader* /*reader*/,
	            const DDS_SampleLostStatus& /*status*/) {}

	    virtual void on_subscription_matched(
	            DDSDataReader* /*reader*/,
	            const DDS_SubscriptionMatchedStatus& /*status*/);

	    virtual void on_data_available(DDSDataReader* reader);

	}m_listener;

	int domainId;
    DDSDomainParticipant *participant;
    DDSSubscriber *subscriber;
    DDSTopic *topic;
    RTIDDS_PacketListener *reader_listener;
    DDSDataReader *reader;
    DDS_ReturnCode_t retcode;

    //boost::function<void(const std::vector<uint8_t>&)> callback_;
    static boost::function<void(const std::vector<uint8_t>&)> callback_;
};

