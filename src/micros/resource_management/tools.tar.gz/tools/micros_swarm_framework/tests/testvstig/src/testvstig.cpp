/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Authors: Jun Cai, Xuefeng Chang
 *********************************************************************/

#include "testvstig/testvstig.h"

// Register the application
PLUGINLIB_EXPORT_CLASS(testvstig::TestVstig, micros_swarm::Application)

namespace testvstig{

    TestVstig::TestVstig() {
        vs=micros_swarm::VirtualStigmergy(2);
    }
    
    TestVstig::~TestVstig() {}

    void TestVstig::init() {}

    void TestVstig::stop() {}
    
    void TestVstig::loop_puts(const ros::TimerEvent&)
    {
        std::string robot_id_string = "robot_"+boost::lexical_cast<std::string>(get_id());
        static int count = 1;
        std_msgs::Int32 pval;
        pval.data = get_id() + count;
        vs.puts<std_msgs::Int32>(robot_id_string, pval);
        count++;
        std::cout<<robot_id_string<<": "<<vs.size()<<std::endl;
        //vs.print();
        /*static bool flag = true;
        if(flag) {
            if(vs.size() == 60) {
                std::cout<<get_id()<<" get all tuple"<<std::endl;
                flag = false;
            }
        }*/
    }

    void TestVstig::loop_gets(const ros::TimerEvent&)
    {
        //for(int j = 0; j < 5; j++) {
            std::string robot_id_string = "robot_" + boost::lexical_cast<std::string>(get_id());
            //std_msgs::Int32 gval = vs.gets<std_msgs::Int32>(robot_id_string);
            //std::cout << robot_id_string << ": " << vs.size() << ", " << gval.data << std::endl;
            //vs.print();
            //std_msgs::Header gheader = vs2.gets(robot_id_string);
            //std::cout<< robot_id_string << ": " <<gheader.frame_id<<", "<<gheader.seq<<", "<<gheader.stamp<< std::endl;
        //}
            gsdf_msgs::Enemy enemy;
            if(!vs.get_new<gsdf_msgs::Enemy>(robot_id_string,enemy))
            	return;
            std::cout<< robot_id_string << ": " <<enemy.startx<<", "<<enemy.starty<<", ";
            std::cout<<enemy.endx<<", "<<enemy.endy<<", "<<enemy.enemy_number<< std::endl;
            //std::cout<<"image size: "<<enemy.image.size()<<std::endl;
            /*int j=0;
            for(int i=0;i<enemy.image.size();i++){
            	std::cout<<enemy.image[i];
            	j++;
            	if(j==200)
            	{
            		std::cout<<std::endl;
            		j=0;
            	}
            }*/
            //std::cout<<"bbbbbbbbbbbbbbbbbb"<<std::endl;
            sensor_msgs::Image image;
            image = deserialize_ros<sensor_msgs::Image>(enemy.image);
            //image = deserialize_ros<sensor_msgs::CompressedImage>(msg);
            std::cout << "length:::" << enemy.image.size() << std::endl;
            if(pub == NULL)
            {
                ros::NodeHandle nh;
                pub = nh.advertise<sensor_msgs::Image>("/ImagequeryResult",1000);
                //pub = nh.advertise<sensor_msgs::CompressedImage>("/ImagequeryResult",1000);
                std::cout << "test advertise" << std::endl;
            }
            // cv_bridge::CvImage(std_msgs::Header(), "bgr8", imgRes).toImageMsg();
            pub.publish(image);
    }

    void TestVstig::loop_put(const ros::TimerEvent&)
    {
        std::string robot_id_string = "robot_"+boost::lexical_cast<std::string>(get_id());
        static int count = 1;
        std_msgs::Int32 pval;
        pval.data = get_id() + count;
        vs.put<std_msgs::Int32>(robot_id_string, pval);
        count++;
        std::cout<<robot_id_string<<": "<<vs.size()<<std::endl;
        vs.print();
    }

    void TestVstig::loop_get(const ros::TimerEvent&)
    {
        //for(int j = 0; j < 5; j++) {
            std::string robot_id_string = "robot_" + boost::lexical_cast<std::string>(get_id());
            std_msgs::Int32 gval = vs.get<std_msgs::Int32>(robot_id_string);
            std::cout << robot_id_string << ": " << vs.size() << ", " << gval.data << std::endl;
        //}
    }

    void TestVstig::not_loop_put(const ros::TimerEvent&)
    {
        static int count = 1;
        std_msgs::Int32 pval;
        pval.data = get_id() + count;

        std::string cur_string="robot_"+boost::lexical_cast<std::string>(get_id())+"/"+boost::lexical_cast<std::string>(count);
        std::string front_string="robot_"+boost::lexical_cast<std::string>(get_id())+"/"+boost::lexical_cast<std::string>(count-1);
        vs.put<std_msgs::Int32>(cur_string, pval);
        //vs.remove(front_string);

        std::cout<<cur_string<<": "<<vs.size()<<std::endl;
        count++;
    }

    void TestVstig::not_loop_get(const ros::TimerEvent&)
    {
        //for(int j = 0; j < 5; j++) {
            int i = micros_swarm::random_int(0, 2047);
            std::string cur_string = "tuple/" + boost::lexical_cast<std::string>(i);
            std_msgs::Int32 gval = vs.get<std_msgs::Int32>(cur_string);
            std::cout << cur_string << ": " << vs.size() << ", " << gval.data << std::endl;
        //}
    }

    void TestVstig::baseCallback(const nav_msgs::Odometry& lmsg)
    {
        static int msg_count = 0;
        float x=lmsg.pose.pose.position.x;
        float y=lmsg.pose.pose.position.y;

        float vx=lmsg.twist.twist.linear.x;
        float vy=lmsg.twist.twist.linear.y;

        micros_swarm::Base l(x, y, 0, vx, vy, 0, 1);
        set_base(l);

        msg_count++;
        if(msg_count >= 20) {
            std::cout<<"shutdown sub"<<std::endl;
            sub.shutdown();
        }
        //std::cout<<"<<<"<<x<<", "<<y<<">>>"<<std::endl;
    }
    
	void TestVstig::pub_callback(const sensor_msgs::Image::ConstPtr& msg)
	//void pub_callback(const sensor_msgs::CompressedImage::ConstPtr& msg)
	{
		//std::cout<<"success subscribing image_raw!!!!!"<<std::endl;
		static int count=0;

	    std::vector<uint8_t> vec_data;

	    vec_data = serialize_ros(*msg);

	    gsdf_msgs::Enemy temp;

	    temp.startx=1.0;
	    temp.starty=1.0;
	    temp.endx=5.0;
	    temp.endy=5.0;
	    temp.enemy_number=get_id();

	    temp.image=vec_data;
	    //std::cout<<"image size: "<<vec_data.size()<<std::endl;

	    //std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
	    std::string robot_id_string="robot_10";

	    //向vs插入一条数据（key,value）
	    if(count==100)
	    {
	    	std::cout<<"insert or update the value of key: "<<robot_id_string<<std::endl;
	    	vs.put<gsdf_msgs::Enemy>(robot_id_string, temp);
	    	count=0;
	    }

	    vec_data.clear();
	    count++;
	}


    void TestVstig::start()
    {
        ros::NodeHandle nh;

        sub = nh.subscribe("base_pose_ground_truth", 1000, &TestVstig::baseCallback, this, ros::TransportHints().udp());
        //sub = nh.subscribe("/usb_cam/image_raw", 1, &TestVstig::pub_callback, this, ros::TransportHints().udp());
        //ros::Duration(1).sleep();
        //test virtual stigmergy
        //创建vs,vs的id号为２
        //vs=micros_swarm::VirtualStigmergy<std_msgs::Int32>(1);
        //template<class Type>
        std_msgs::Int32 val;
        val.data = get_id();

        std::string robot_id_string="robot_10";
        vs.put<std_msgs::Int32>(robot_id_string, val);

        static int count=0;
        while(!vs.get_or_query<std_msgs::Int32>(robot_id_string,val)){
        	count++;
        	usleep(1000000);
        }

        std::cout<<"after "<<count<<" query, get the key-value:"<<robot_id_string<<", "<<val.data<<std::endl;



        /*vs2=micros_swarm::VirtualStigmergy<std_msgs::Header>(2);
        std_msgs::Header header;
        header.frame_id="robot_"+boost::lexical_cast<std::string>(get_id());
        header.seq=0;
        ros::Time timestamp = ros::Time::now();
        header.stamp=timestamp;*/


        /*
         * loop write and read
         */
        //SCDS puts
        //std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
        //vs.puts(robot_id_string, val);
        //timer = nh.createTimer(ros::Duration(0.1), &TestVstig::loop_puts, this);

        //SCDS gets
        //std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
        //向vs插入一条数据（key,value）
        //vs.put<gsdf_msgs::Enemy>(robot_id_string, temp);
        //vs.put<std_msgs::Int32>(robot_id_string, val);
        //vs2.put(robot_id_string, header);
        //timer = nh.createTimer(ros::Duration(0.1), &TestVstig::loop_gets, this);
        //timer = nh.createTimer(ros::Duration(5), &TestVstig::loop_gets, this);

        //Vstig put
        //std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
        //vs.put(robot_id_string, val);
        //timer = nh.createTimer(ros::Duration(1), &TestVstig::loop_put, this);

        //Vstig get
        /*std::string robot_id_string="robot_"+boost::lexical_cast<std::string>(get_id());
        vs.put(robot_id_string, val);
        timer = nh.createTimer(ros::Duration(0.1), &TestVstig::loop_get, this);*/

        /*
         * not loop write and read
         */
        //put
        /*std::string cur_string="robot_"+boost::lexical_cast<std::string>(get_id())+"/"+boost::lexical_cast<std::string>(0);
        vs.put(cur_string, val);
        timer = nh.createTimer(ros::Duration(0.5), &TestVstig::not_loop_put, this);*/

        //get
        /*for(int i = 0; i < 2048; i++){
            std::string cur_string="tuple/"+boost::lexical_cast<std::string>(i);
            std_msgs::Int32 pval;
            pval.data = i;
            vs.put(cur_string, pval);
        }
        ros::Duration(20).sleep();
        timer = nh.createTimer(ros::Duration(0.1), &TestVstig::not_loop_get, this);*/
    }
};

